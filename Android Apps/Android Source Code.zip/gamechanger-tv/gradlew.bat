@echo off
echo This project includes gradle-wrapper.properties. If gradlew is required, re-generate wrapper from Android Studio or run: gradle wrapper
exit /b 1
