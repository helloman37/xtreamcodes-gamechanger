# GameChanger TV - keep rules for release shrink

# Retrofit / OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn retrofit2.**
-keepattributes Signature,InnerClasses,EnclosingMethod,RuntimeVisibleAnnotations,RuntimeVisibleParameterAnnotations

# Gson (used by Retrofit converter)
-dontwarn com.google.gson.**

# ExoPlayer
-dontwarn com.google.android.exoplayer2.**

# VLC
-dontwarn org.videolan.**

# Compose / Kotlin metadata
-keepattributes *Annotation*
