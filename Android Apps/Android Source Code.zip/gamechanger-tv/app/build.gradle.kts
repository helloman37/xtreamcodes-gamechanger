plugins {
    id("org.jetbrains.kotlin.plugin.compose")
id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.gamechanger.iptv"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.gamechanger.iptv"
        minSdk = 23
        targetSdk = 35
        versionCode = 149
        versionName = "149"
    }

compileOptions {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
}


kotlin {
    jvmToolchain(17)
}


buildFeatures {
        compose = true
        // Required for BuildConfig.VERSION_CODE / VERSION_NAME usage in code
        buildConfig = true
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
            isShrinkResources = false
        }


    // Split by ABI so each APK only contains one architecture's native libs (huge size win).
    // Fire TV / Android TV / onn: ARM (arm64-v8a, sometimes armeabi-v7a).
    splits {
        abi {
            isEnable = true
            reset()
            include("armeabi-v7a", "arm64-v8a")
            isUniversalApk = false
        }
    }


        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }

        jniLibs {
            pickFirsts += setOf("**/libc++_shared.so")
        }
    }
}

dependencies {

    // UI - Jetpack Compose for TV (Cinematic Toolkit)
    implementation("androidx.tv:tv-foundation:1.0.0-alpha10")
    implementation("androidx.tv:tv-material:1.0.0-alpha10")

    // Video Engine (4K Streaming)
    implementation("com.google.android.exoplayer:exoplayer:2.19.1")
    // Needed for HLS (.m3u8) playback
    implementation("com.google.android.exoplayer:exoplayer-hls:2.19.1")
    implementation("com.google.android.exoplayer:extension-leanback:2.19.1")

    // VLC engine (in-app fallback for Live TV)
    implementation("org.videolan.android:libvlc-all:3.6.5")

    // Networking & API (Xtream + TMDB)
    implementation("com.squareup.retrofit2:retrofit:2.9.0")
    implementation("com.squareup.retrofit2:converter-gson:2.9.0")

    // Image Handling
    implementation("io.coil-kt:coil-compose:2.4.0")
    implementation("io.coil-kt:coil:2.4.0") // needed for custom ImageLoader/OkHttp
    // Core Compose
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("org.conscrypt:conscrypt-android:2.5.2")
    debugImplementation("androidx.compose.ui:ui-tooling")
}

tasks.register<Delete>("cleanBadGeneratedDuplicates") {
    delete(fileTree("src") {
        include("**/*(*).*")
    })
}

tasks.matching {
    it.name in setOf(
        "preBuild",
        "compileDebugKotlin",
        "compileReleaseKotlin",
        "mergeDebugResources",
        "packageDebugResources",
        "mergeReleaseResources",
        "packageReleaseResources"
    )
}.configureEach {
    dependsOn("cleanBadGeneratedDuplicates")
}