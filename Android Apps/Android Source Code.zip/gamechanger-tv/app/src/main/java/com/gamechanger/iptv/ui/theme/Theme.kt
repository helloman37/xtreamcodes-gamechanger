package com.gamechanger.iptv.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable  
fun GameChangerTheme(content: @Composable () -> Unit) {  
    val colorScheme = darkColorScheme(  
        primary = CyanGlow,  
        background = DarkBackground,  
        surface = SurfaceDark,  
        onSurface = Color.White  
    )  

    MaterialTheme(  
        colorScheme = colorScheme,  
        typography = Typography,  
        content = content  
    )  
}  
