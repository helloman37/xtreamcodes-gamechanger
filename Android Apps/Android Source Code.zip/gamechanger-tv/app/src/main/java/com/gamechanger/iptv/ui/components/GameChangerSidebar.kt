package com.gamechanger.iptv.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.gamechanger.iptv.R

enum class SidebarRoute {
    HOME, MOVIES, SERIES, LIVE_TV, SEARCH, SETTINGS
}

/**
 * Icon-only sidebar (TV-first): top "X" mark + stacked icons with cyan left indicator
 * and a soft blue selection block, matching the provided mockup proportions.
 */
@Composable
fun GameChangerSidebar(
    selected: SidebarRoute,
    onSelect: (SidebarRoute) -> Unit,
    modifier: Modifier = Modifier
) {
    val glass = Brush.verticalGradient(
        colors = listOf(Color(0x22000000), Color(0x44000000), Color(0x22000000))
    )

    Column(
        modifier = modifier
            .fillMaxHeight()
            .width(88.dp)
            .background(glass),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(18.dp))

        // Top "X" mark (logo placeholder)
        Box(
            modifier = Modifier
                .size(52.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0x1600FFFF)),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.ic_gamechanger_logo),
                contentDescription = "Logo",
                modifier = Modifier.size(42.dp),
                contentScale = ContentScale.Fit
            )
        }

        Spacer(Modifier.height(26.dp))

        SidebarItem(
            isSelected = selected == SidebarRoute.HOME,
            onClick = { onSelect(SidebarRoute.HOME) }
        ) {
            Icon(Icons.Default.Home, contentDescription = "Home", tint = it, modifier = Modifier.size(26.dp))
        }

        Spacer(Modifier.height(18.dp))

        SidebarItem(
            isSelected = selected == SidebarRoute.MOVIES,
            onClick = { onSelect(SidebarRoute.MOVIES) }
        ) {
            Icon(Icons.Default.Movie, contentDescription = "Movies", tint = it, modifier = Modifier.size(26.dp))
        }

        Spacer(Modifier.height(18.dp))

        SidebarItem(
            isSelected = selected == SidebarRoute.SERIES,
            onClick = { onSelect(SidebarRoute.SERIES) }
        ) {
            Icon(Icons.Default.Tv, contentDescription = "Series", tint = it, modifier = Modifier.size(26.dp))
        }

        Spacer(Modifier.height(18.dp))

        SidebarItem(
            isSelected = selected == SidebarRoute.LIVE_TV,
            onClick = { onSelect(SidebarRoute.LIVE_TV) }
        ) {
            Icon(Icons.Default.LiveTv, contentDescription = "Live TV", tint = it, modifier = Modifier.size(26.dp))
        }

        Spacer(Modifier.height(18.dp))

        SidebarItem(
            isSelected = selected == SidebarRoute.SEARCH,
            onClick = { onSelect(SidebarRoute.SEARCH) }
        ) {
            Icon(Icons.Default.Search, contentDescription = "Search", tint = it, modifier = Modifier.size(26.dp))
        }

        Spacer(Modifier.height(18.dp))

        SidebarItem(
            isSelected = selected == SidebarRoute.SETTINGS,
            onClick = { onSelect(SidebarRoute.SETTINGS) }
        ) {
            Icon(Icons.Default.Settings, contentDescription = "Settings", tint = it, modifier = Modifier.size(26.dp))
        }
    }
}

@Composable
private fun SidebarItem(
    isSelected: Boolean,
    onClick: () -> Unit,
    content: @Composable (tint: Color) -> Unit
) {
    var isFocused by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    val interactionSource = androidx.compose.runtime.remember { MutableInteractionSource() }
    val active = isSelected || isFocused
    val tint = if (active) Color.White else Color(0xAAFFFFFF)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(54.dp)
            .onFocusChanged { isFocused = it.isFocused }
            .focusable(interactionSource = interactionSource)
            .clickable(
                interactionSource = interactionSource,
                indication = null
            ) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        if (active) {
            // Soft blue selection/focus block
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 10.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isSelected) Color(0x3300AEEF) else Color(0x2200AEEF))
            )
            // Cyan left indicator bar
            Box(
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .padding(start = 6.dp)
                    .width(4.dp)
                    .height(28.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color(0xFF00FFFF))
            )
        }

        content(tint)
    }
}
