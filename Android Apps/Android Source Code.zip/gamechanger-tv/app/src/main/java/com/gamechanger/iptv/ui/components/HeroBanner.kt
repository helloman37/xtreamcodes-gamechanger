package com.gamechanger.iptv.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import com.gamechanger.iptv.ui.components.TvPillButton
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.ui.draw.scale
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.gamechanger.iptv.ui.theme.AccentGradient
import com.gamechanger.iptv.ui.theme.ElectricBlue

@Composable  
fun HeroBanner(title: String, info: String, backdrop: String) {  
    Box(modifier = Modifier.fillMaxWidth().height(420.dp)) {  
        AsyncImage(model = backdrop, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)  
        Box(modifier = Modifier.fillMaxSize().background(AccentGradient))  
        Column(modifier = Modifier.align(Alignment.BottomStart).padding(48.dp)) {  
            Text(title, style = TextStyle(fontSize = 48.sp, fontWeight = FontWeight.Bold, color = Color.White))  
            Text(info, color = ElectricBlue)  
            Spacer(Modifier.height(16.dp))  
            TvPillButton(
                text = "WATCH NOW",
                onClick = {},
                modifier = Modifier
            )
        }  
    }  
}  


@Composable
fun HeroBanner(heroMovie: com.gamechanger.iptv.ui.model.Movie) {
    HeroBanner(
        title = heroMovie.title,
        info = heroMovie.year,
        backdrop = if (heroMovie.backdropUrl.isNotBlank()) heroMovie.backdropUrl else heroMovie.posterUrl
    )
}
