package com.gamechanger.iptv.ui.components

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.gamechanger.iptv.ui.model.Category
import com.gamechanger.iptv.ui.theme.CyanGlow
import com.gamechanger.iptv.ui.theme.TranslucentBlack
import androidx.compose.ui.graphics.Color

@Composable
fun CinemaRow(category: Category) {
    Column(modifier = Modifier.fillMaxWidth().padding(top = 16.dp)) {
        Text(
            text = category.title.uppercase(),
            color = CyanGlow,
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
        )

        LazyRow(contentPadding = PaddingValues(horizontal = 20.dp)) {
            items(category.items) { movie ->
                var hasFocus by remember { mutableStateOf(false) }

                Card(
                    modifier = Modifier
                        .padding(horizontal = 6.dp, vertical = 6.dp)
                        .height(160.dp)
                        .onFocusChanged { hasFocus = it.isFocused }
                        .border(
                            width = if (hasFocus) 2.dp else 0.dp,
                            color = if (hasFocus) CyanGlow else Color.Transparent,
                            shape = RoundedCornerShape(12.dp)
                        )
                        .scale(if (hasFocus) 1.06f else 1f),
                    colors = CardDefaults.cardColors(containerColor = TranslucentBlack),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        AsyncImage(
                            model = if (movie.posterUrl.isNotBlank()) movie.posterUrl else movie.backdropUrl,
                            contentDescription = movie.title,
                            modifier = Modifier
                                .height(110.dp)
                                .fillMaxWidth()
                        )
                        Text(
                            text = movie.title,
                            color = Color.White,
                            style = MaterialTheme.typography.labelMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                }
            }
        }
    }
}
