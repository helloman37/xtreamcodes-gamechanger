package com.gamechanger.iptv.ui.theme  

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color  

val DarkBackground = Color(0xFF0A0A0A) // Deep Netflix Black  
val SurfaceDark = Color(0xFF1A1A1A)  
val CyanGlow = Color(0xFF00FFFF) // Your Signature Cyan  
val CyanVariant = Color(0xFF008B8B)  
val TranslucentBlack = Color(0x44000000)  
val GlassWhite = Color(0x1AFFFFFF) // For translucent card overlays  

// Compatibility aliases (so existing screens/components compile without changing the theme)
val PureBlack = DarkBackground
val GameChangerCyan = CyanGlow
val ElectricBlue = CyanGlow
val DeepBlack = DarkBackground
val TitleWhite = Color.White

val AccentGradient = Brush.verticalGradient(listOf(Color.Transparent, DarkBackground))
