package com.gamechanger.iptv.api

import retrofit2.http.GET

data class UpdateManifest(
    val versionCode: Int,
    val apkUrl: String,
    val changelog: String? = null
)

interface UpdateApiService {
    @GET("update.json")
    suspend fun getUpdateManifest(): UpdateManifest
}
