package com.gamechanger.iptv.util

import android.content.Context
import android.util.Log
import android.webkit.CookieManager
import android.webkit.WebStorage
import android.webkit.WebView
import java.io.File

object CacheCleaner {

    fun clearAppCache(context: Context) {
        tryDeleteDirContents(context.cacheDir)
        tryDeleteDirContents(context.codeCacheDir)
        context.externalCacheDir?.let { tryDeleteDirContents(it) }
    }

    fun clearWebViewGlobalStorage() {
        try {
            val cm = CookieManager.getInstance()
            cm.setAcceptCookie(true)
            cm.removeAllCookies(null)
            cm.flush()
        } catch (t: Throwable) {
            Log.w("CacheCleaner", "Cookie clear failed: ${t.message}")
        }

        try {
            WebStorage.getInstance().deleteAllData()
        } catch (t: Throwable) {
            Log.w("CacheCleaner", "WebStorage clear failed: ${t.message}")
        }
    }

    fun clearWebViewInstance(webView: WebView) {
        try {
            webView.clearCache(true)
            webView.clearHistory()
            webView.clearFormData()
            webView.clearSslPreferences()
        } catch (t: Throwable) {
            Log.w("CacheCleaner", "WebView clear failed: ${t.message}")
        }
    }

    private fun tryDeleteDirContents(dir: File?) {
        if (dir == null) return
        runCatching {
            dir.listFiles()?.forEach { it.deleteRecursively() }
        }.onFailure {
            Log.w("CacheCleaner", "Cache dir clear failed: ${dir.absolutePath} (${it.message})")
        }
    }
}
