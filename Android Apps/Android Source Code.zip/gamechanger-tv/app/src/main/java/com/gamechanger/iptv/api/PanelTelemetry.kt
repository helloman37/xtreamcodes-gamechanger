package com.gamechanger.iptv.api

import android.content.Context
import android.os.Build
import android.provider.Settings
import com.gamechanger.iptv.BuildConfig
import com.gamechanger.iptv.ui.model.Channel
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.TimeUnit

/**
 * Lightweight “phone-home” telemetry for YOUR panel.
 *
 * Endpoint is expected at: {serverUrl}/app_activity.php
 * Payload is JSON, content-type application/json.
 *
 * Safe-by-default: best-effort, short timeouts, never throws to UI.
 */
object PanelTelemetry {

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(5, TimeUnit.SECONDS)
            .readTimeout(6, TimeUnit.SECONDS)
            .writeTimeout(6, TimeUnit.SECONDS)
            .callTimeout(8, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }

    private val sessionId: String = UUID.randomUUID().toString()

    private fun endpoint(baseUrl: String): String {
        val root = baseUrl.trimEnd('/')
        return "$root/app_activity.php"
    }

    private fun deviceId(context: Context): String {
        return runCatching {
            Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
        }.getOrNull().orEmpty()
    }

    private fun baseEnvelope(context: Context, username: String, event: String): JSONObject {
        return JSONObject().apply {
            put("event", event)
            put("username", username)
            put("device_id", deviceId(context))
            put("session_id", sessionId)
            put("ts", System.currentTimeMillis())
            put("app_version", BuildConfig.VERSION_NAME)
            put("app_version_code", BuildConfig.VERSION_CODE)
            put("sdk", Build.VERSION.SDK_INT)
            put("device", "${Build.MANUFACTURER} ${Build.MODEL}")
        }
    }

    private fun channelObj(ch: Channel, streamUrl: String? = null): JSONObject {
        return JSONObject().apply {
            put("stream_id", ch.streamId)
            put("name", ch.name)
            put("logo", ch.logoUrl)
            put("category_id", ch.categoryId)

            // Prefer explicit URL passed from caller, otherwise whatever the Channel currently holds.
            val u = streamUrl ?: ch.streamUrl
            if (!u.isNullOrBlank()) put("url", u)
        }
    }

    private fun postJson(url: String, body: JSONObject) {
        runCatching {
            val req = Request.Builder()
                .url(url)
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()
            client.newCall(req).execute().use { /* ignore */ }
        }
    }

    /** Call when user successfully logs in */
    fun fireLogin(context: Context, serverUrl: String, username: String) {
        if (username.isBlank() || serverUrl.isBlank()) return
        val payload = baseEnvelope(context, username, "login")
        postJson(endpoint(serverUrl), payload)
    }

    /** Call when a live channel begins playing / is tuned */
    fun fireLiveTune(
        context: Context,
        serverUrl: String,
        username: String,
        channel: Channel,
        streamUrl: String?
    ) {
        if (username.isBlank() || serverUrl.isBlank()) return
        val payload = baseEnvelope(context, username, "live_tune")
        payload.put("channel", channelObj(channel, streamUrl))
        postJson(endpoint(serverUrl), payload)
    }

    /** Periodic “still watching” while player is open */
    fun fireLiveHeartbeat(
        context: Context,
        serverUrl: String,
        username: String,
        channel: Channel
    ) {
        if (username.isBlank() || serverUrl.isBlank()) return
        val payload = baseEnvelope(context, username, "live_heartbeat")
        payload.put("channel", channelObj(channel))
        postJson(endpoint(serverUrl), payload)
    }

    /** Optional: fire when leaving live player */
    fun fireLiveStop(
        context: Context,
        serverUrl: String,
        username: String,
        channel: Channel
    ) {
        if (username.isBlank() || serverUrl.isBlank()) return
        val payload = baseEnvelope(context, username, "live_stop")
        payload.put("channel", channelObj(channel))
        postJson(endpoint(serverUrl), payload)
    }
}
