package com.gamechanger.iptv.ui.components

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.gamechanger.iptv.ui.model.Movie

@Composable
fun HorizontalMovieRow(
    title: String,
    movies: List<Movie>,
    onMovieClick: (Movie) -> Unit,
    modifier: Modifier = Modifier
) {
    SectionTitle(text = title)

    LazyRow(
        modifier = modifier,
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
    ) {
        items(
            items = movies,
            key = { m -> "${m.title}_${m.posterUrl}_${m.backdropUrl}" }
        ) { movie ->
            MediaCard(
                title = movie.title,
                poster = movie.posterUrl,
                onClick = { onMovieClick(movie) }
            )
        }
    }
}
