package com.gamechanger.iptv.api

import android.util.Log
import com.gamechanger.iptv.ui.model.Channel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.InputStream
import java.io.BufferedInputStream
import java.net.URLEncoder
import java.util.Locale
import java.util.zip.GZIPInputStream
import com.gamechanger.iptv.util.TimeSync

data class EpgProgram(
    val title: String,
    val startMs: Long,
    val stopMs: Long
)

data class EpgNowNext(
    val current: EpgProgram? = null,
    val next: EpgProgram? = null,
    val matchedXmltvId: String? = null
)

data class EpgFetchResult(
    val sourceUrl: String,
    val nowNextByStreamId: Map<String, EpgNowNext>
)

object EpgXmltv {

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
        .writeTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
        .callTimeout(45, java.util.concurrent.TimeUnit.SECONDS)
        .build()

    fun buildXmltvUrlCandidates(baseUrl: String, username: String, password: String): List<String> {
        val root = baseUrl.trim().trimEnd('/')
        val u = urlEncode(username)
        val p = urlEncode(password)
        val path = "/xmltv.php?username=$u&password=$p"

        val candidates = LinkedHashSet<String>()
        if (root.isNotBlank()) {
            candidates += root + path

            // If the login/base URL is https but xmltv is only served over http (common), try both.
            if (root.startsWith("https://", ignoreCase = true)) {
                candidates += "http://" + root.removePrefix("https://") + path
            } else if (root.startsWith("http://", ignoreCase = true)) {
                candidates += "https://" + root.removePrefix("http://") + path
            }
        }
        return candidates.toList()
    }

    suspend fun fetchNowNextForChannels(
        baseUrl: String,
        username: String,
        password: String,
        channels: List<Channel>,
        nowMs: Long = TimeSync.nowMs()
    ): EpgFetchResult = fetchNowNextForChannelsFromUrls(
        urls = buildXmltvUrlCandidates(baseUrl, username, password),
        channels = channels,
        nowMs = nowMs
    )

    suspend fun fetchNowNextForChannelsFromUrls(
        urls: List<String>,
        channels: List<Channel>,
        nowMs: Long = TimeSync.nowMs()
    ): EpgFetchResult = withContext(Dispatchers.IO) {

        val candidates = urls.filter { it.isNotBlank() }
        var lastError: Throwable? = null
        val errors = ArrayList<String>(candidates.size)

        for (url in candidates) {
            try {
                val req = Request.Builder().url(url).get().build()
                client.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) {
                        throw IllegalStateException("HTTP ${resp.code}")
                    }
                    val body = resp.body ?: throw IllegalStateException("Empty body")
                    body.byteStream().use { raw ->
                        val input = BomStrippingInputStream(maybeGunzip(raw))
                        input.use { stream ->
                            val map = parseNowNext(stream, channels, nowMs)
                            return@withContext EpgFetchResult(sourceUrl = url, nowNextByStreamId = map)
                        }
                    }
                }
            } catch (t: Throwable) {
                lastError = t
                val msg = (t.message ?: "error")
                Log.w("EPG", "EPG candidate failed: ${t.javaClass.simpleName}: $msg", t)
                errors.add("${t.javaClass.simpleName}: $msg")
            }
        }

        val combined = if (errors.isNotEmpty()) errors.joinToString(" | ") else (lastError?.message ?: "EPG fetch failed")

        // Don't surface endpoints/errors to the UI; keep details in Logcat.
        Log.w("EPG", "EPG fetch failed. Details: $combined")
        throw IllegalStateException("EPG unavailable", lastError)
    }



    private class BomStrippingInputStream(private val src: InputStream) : InputStream() {
        private val push = ArrayDeque<Int>(4)

        override fun read(): Int {
            if (push.isNotEmpty()) return push.removeFirst()

            val b0 = src.read()
            if (b0 == -1) return -1

            // Strip UTF-8 BOM sequence (EF BB BF) even if it appears mid-stream.
            if (b0 == 0xEF) {
                val b1 = src.read()
                if (b1 == -1) return 0xEF
                if (b1 == 0xBB) {
                    val b2 = src.read()
                    if (b2 == -1) {
                        push.addLast(0xBB)
                        return 0xEF
                    }
                    if (b2 == 0xBF) {
                        // Skip BOM bytes and continue.
                        return read()
                    }
                    push.addLast(0xBB)
                    push.addLast(b2)
                    return 0xEF
                }
                push.addLast(b1)
                return 0xEF
            }

            return b0
        }

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (len == 0) return 0
            var i = 0
            while (i < len) {
                val r = read()
                if (r == -1) return if (i == 0) -1 else i
                b[off + i] = r.toByte()
                i++
            }
            return i
        }

        override fun close() {
            src.close()
        }
    }
    private fun maybeGunzip(input: InputStream): InputStream {
        val bis = BufferedInputStream(input)
        return try {
            bis.mark(2)
            val b1 = bis.read()
            val b2 = bis.read()
            bis.reset()
            if (b1 == 0x1f && b2 == 0x8b) {
                GZIPInputStream(bis)
            } else {
                bis
            }
        } catch (_: Throwable) {
            bis
        }
    }

    private fun parseNowNext(
        input: InputStream,
        channels: List<Channel>,
        nowMs: Long
    ): Map<String, EpgNowNext> {
        val parser = XmlPullParserFactory.newInstance().newPullParser().apply {
            setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
            setInput(input, null)
        }

        // display-name(normalized) -> xmltv channel id
        val nameToId = HashMap<String, String>(4096)

        // xmltv channel ids as they appear in <channel id="...">
        val allChannelIds = HashSet<String>(4096)

        // streamId -> xmltv channel id
        var wantedIdsByStreamId: Map<String, String>? = null
        var wantedStreamIdsByXmltvId: Map<String, List<String>>? = null
        var wantedIds: Set<String>? = null

        val out = HashMap<String, EpgNowNext>(channels.size.coerceAtLeast(16))
        channels.forEach { c ->
            if (c.streamId.isNotBlank()) out[c.streamId] = EpgNowNext()
        }

        var currentChannelId: String? = null

        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG) {
                when (parser.name) {
                    "channel" -> {
                        val id = parser.getAttributeValue(null, "id")?.trim()
                        currentChannelId = id
                        if (!id.isNullOrBlank()) allChannelIds.add(id)
                    }
                    "display-name" -> {
                        val id = currentChannelId
                        if (!id.isNullOrBlank()) {
                            val dn = safeNextText(parser).trim()
                            if (dn.isNotBlank()) {
                                val key = normalizeName(dn)
                                if (key.isNotBlank() && !nameToId.containsKey(key)) {
                                    nameToId[key] = id
                                }
                            }
                        }
                    }
                    "programme" -> {
                        if (wantedIdsByStreamId == null) {
                            val mapped = HashMap<String, String>(channels.size)
                            for (c in channels) {
                                val sid = c.streamId
                                if (sid.isBlank()) continue
                                val byName = nameToId[normalizeName(c.name)]
                                val id = when {
                                    !byName.isNullOrBlank() -> byName
                                    sid.isNotBlank() && allChannelIds.contains(sid) -> sid
                                    else -> null
                                }
                                if (!id.isNullOrBlank()) mapped[sid] = id
                            }
                            wantedIdsByStreamId = mapped
                            wantedIds = mapped.values.toSet()
                            wantedStreamIdsByXmltvId = mapped.entries.groupBy({ it.value }, { it.key })
                        }

                        val chId = parser.getAttributeValue(null, "channel")?.trim().orEmpty()
                        val wantedSet = wantedIds
                        if (wantedSet == null || !wantedSet.contains(chId)) {
                            skipTag(parser)
                        } else {
                            val startRaw = parser.getAttributeValue(null, "start")?.trim().orEmpty()
                            val stopRaw = parser.getAttributeValue(null, "stop")?.trim().orEmpty()
                            val startMs = parseXmltvTimeToMs(startRaw)
                            val stopMs = parseXmltvTimeToMs(stopRaw)
                            var title = ""

                            var inner = parser.next()
                            while (!(inner == XmlPullParser.END_TAG && parser.name == "programme")) {
                                if (inner == XmlPullParser.START_TAG) {
                                    if (parser.name == "title") {
                                        title = safeNextText(parser).trim()
                                    } else {
                                        // ignore other tags
                                    }
                                }
                                inner = parser.next()
                            }

                            if (title.isNotBlank() && startMs > 0L && stopMs > 0L) {
                                val prog = EpgProgram(title = title, startMs = startMs, stopMs = stopMs)
                                val streamIds = wantedStreamIdsByXmltvId?.get(chId).orEmpty()
                                for (sid in streamIds) {
                                    val prev = out[sid] ?: EpgNowNext()
                                    val updated = updateNowNext(prev, prog, nowMs, chId)
                                    out[sid] = updated
                                }
                            }
                        }
                    }
                }
            } else if (event == XmlPullParser.END_TAG) {
                if (parser.name == "channel") {
                    currentChannelId = null
                }
            }
            event = parser.next()
        }

        return out
    }

    private fun updateNowNext(prev: EpgNowNext, prog: EpgProgram, nowMs: Long, xmltvId: String): EpgNowNext {
        val current = prev.current
        val next = prev.next

        val isCurrent = prog.startMs <= nowMs && prog.stopMs > nowMs
        val isFuture = prog.startMs > nowMs

        var newCurrent = current
        var newNext = next

        if (isCurrent) {
            if (newCurrent == null || prog.stopMs > newCurrent.stopMs) {
                newCurrent = prog
            }
        } else if (isFuture) {
            if (newNext == null || prog.startMs < newNext.startMs) {
                newNext = prog
            }
        }

        return prev.copy(current = newCurrent, next = newNext, matchedXmltvId = prev.matchedXmltvId ?: xmltvId)
    }

    private fun skipTag(parser: XmlPullParser) {
        var depth = 1
        while (depth != 0) {
            when (parser.next()) {
                XmlPullParser.END_TAG -> depth--
                XmlPullParser.START_TAG -> depth++
            }
        }
    }

    private fun safeNextText(parser: XmlPullParser): String {
        return try {
            parser.nextText()
        } catch (_: Throwable) {
            ""
        }
    }

    private fun urlEncode(s: String): String {
        return try {
            URLEncoder.encode(s, "UTF-8")
        } catch (_: Throwable) {
            s
        }
    }

    private fun normalizeName(s: String): String {
        val up = s.trim().uppercase(Locale.US)
        if (up.isBlank()) return ""

        val sb = StringBuilder(up.length)
        for (ch in up) {
            when {
                ch.isLetterOrDigit() -> sb.append(ch)
                ch == '&' -> sb.append('A').append('N').append('D')
                else -> sb.append(' ')
            }
        }
        return sb.toString().trim().replace(Regex("\\s+"), " ")
    }

    
    private fun parseXmltvTimeToMs(raw: String): Long {
        val s = raw.trim()
        if (s.length < 14) return 0L
        return try {
            val datePart = s.substring(0,14)
            val tzPart = s.substring(14).trim()

            val year = datePart.substring(0,4).toInt()
            val mon = datePart.substring(4,6).toInt()
            val day = datePart.substring(6,8).toInt()
            val hr = datePart.substring(8,10).toInt()
            val min = datePart.substring(10,12).toInt()
            val sec = datePart.substring(12,14).toInt()

            val ldt = java.time.LocalDateTime.of(year,mon,day,hr,min,sec)

            if (tzPart.isBlank()) {
                return ldt.atZone(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
            }

            val sign = if (tzPart.startsWith("-")) -1 else 1
            val cleaned = tzPart.removePrefix("+").removePrefix("-")
            val hh = cleaned.substring(0,2).toIntOrNull() ?: 0
            val mm = cleaned.substring(2,4).toIntOrNull() ?: 0
            val offset = java.time.ZoneOffset.ofHoursMinutes(sign*hh, sign*mm)

            return ldt.atOffset(offset).toInstant().toEpochMilli()
        } catch (_: Throwable) {
            0L
        }
    }
}