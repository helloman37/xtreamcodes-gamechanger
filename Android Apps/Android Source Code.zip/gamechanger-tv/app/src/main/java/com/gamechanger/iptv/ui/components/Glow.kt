package com.gamechanger.iptv.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.foundation.Canvas

/**
 * Simple GPU-only glow that avoids nativeCanvas (keeps compatibility across Compose versions).
 */
@Composable
fun Glow(
    modifier: Modifier = Modifier,
    path: Path,
    color: Color,
    glowRadius: Float = 18f,
    strokeWidth: Float = 3f
) {
    Canvas(modifier = modifier) {
        drawGlowPath(path = path, color = color, glowRadius = glowRadius, strokeWidth = strokeWidth)
    }
}

private fun DrawScope.drawGlowPath(
    path: Path,
    color: Color,
    glowRadius: Float,
    strokeWidth: Float
) {
    // Outer soft strokes
    val steps = 6
    for (i in steps downTo 1) {
        val t = i / steps.toFloat()
        val w = strokeWidth + glowRadius * t
        drawPath(
            path = path,
            color = color.copy(alpha = 0.10f * t),
            style = Stroke(width = w)
        )
    }
    // Crisp inner stroke
    drawPath(
        path = path,
        color = color.copy(alpha = 0.85f),
        style = Stroke(width = strokeWidth)
    )
}
