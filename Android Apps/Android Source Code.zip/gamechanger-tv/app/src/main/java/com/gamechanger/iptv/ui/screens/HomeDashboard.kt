package com.gamechanger.iptv.ui.screens

import android.util.Log
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.compose.SubcomposeAsyncImage
import com.gamechanger.iptv.api.ApiClient
import com.gamechanger.iptv.api.EpgXmltv
import com.gamechanger.iptv.api.Keys
import com.gamechanger.iptv.api.TmdbGenre
import com.gamechanger.iptv.api.TmdbImages
import com.gamechanger.iptv.api.TmdbMovieResult
import com.gamechanger.iptv.R
import com.gamechanger.iptv.ui.model.Category
import com.gamechanger.iptv.ui.model.Channel
import com.gamechanger.iptv.ui.model.LiveCategory
import com.gamechanger.iptv.ui.model.Movie
import com.gamechanger.iptv.ui.theme.CyanGlow
import com.gamechanger.iptv.ui.components.MockupChannelCard
import com.gamechanger.iptv.util.TimeSync
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import java.util.Locale
import java.util.Date
import java.text.SimpleDateFormat
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.platform.LocalContext
import com.gamechanger.iptv.util.EpgDbHelper
import com.gamechanger.iptv.util.ContinueWatchingEntry

// -----------------------------------------------------------------------------
//  THE MASTER "GAME CHANGER" ARCHITECTURAL OVERHAUL (11 FIX)
//  Followed 1:1 from the blueprint doc.
// -----------------------------------------------------------------------------

private val HARDCODED_EPG_URLS = listOf(
    "who.what.who",
    "who.what.who"
)

enum class SidebarSection { HOME, MOVIES, SERIES, LIVE, SEARCH, MY_STUFF, SETTINGS }

enum class LiveTab { CHANNELS, GUIDE }

private enum class SearchTab { ALL, MOVIES, SERIES }

private data class SubscriptionUi(
    val loading: Boolean = true,
    val status: String = "",
    val expires: String = "",
    val daysLeft: String = "",
    val message: String? = null
)

private fun TmdbMovieResult.toUiMovie(): Movie {
    val titleText = (title ?: name ?: "Untitled").trim()
    val yearText = (release_date ?: first_air_date)?.take(4)?.trim().orEmpty()
    val media = if (title.isNullOrBlank()) "tv" else "movie"

    return Movie(
        id = id ?: 0,
        title = titleText.ifBlank { "Untitled" },
        overview = overview?.trim().orEmpty(),
        posterUrl = TmdbImages.posterW500(poster_path),
        backdropUrl = TmdbImages.backdropW780(backdrop_path),
        year = yearText,
        rating = vote_average ?: 0.0,
        mediaType = media
    )
}

@Composable
private fun FocusFallbackTarget(requester: FocusRequester) {
    Box(
        modifier = Modifier
            .size(1.dp)
            .alpha(0f)
            .focusRequester(requester)
            .focusable()
    )
}

@Composable
fun HomeDashboard(
    trending: List<Movie>,
    popular: List<Movie>,
    topRated: List<Movie>,
    latest: List<Movie>,
    recommended: List<Movie>,
    seriesTrending: List<Movie>,
    seriesPopular: List<Movie>,
    seriesTopRated: List<Movie>,
    seriesOnTheAir: List<Movie>,
    liveCategories: List<LiveCategory>,
    liveChannels: List<Channel>,
    continueWatching: List<ContinueWatchingEntry>,
    recentLiveChannels: List<Channel>,
    favoriteMovies: List<Movie>,
    favoriteLiveChannels: List<Channel>,
    serverUrl: String,
    username: String,
    password: String,
    sectionState: androidx.compose.runtime.MutableState<SidebarSection>,
    liveTabState: androidx.compose.runtime.MutableState<LiveTab>,
    selectedLiveCategoryIdState: androidx.compose.runtime.MutableState<String>,
    lastWatchedLiveStreamId: String?,
    onRequestLiveChannels: () -> Unit,
    onMovieClick: (Movie) -> Unit,
    onContinueWatchingClick: (ContinueWatchingEntry) -> Unit,
    onChannelClick: (Channel) -> Unit,
    isChannelFavorite: (Channel) -> Boolean,
    onToggleChannelFavorite: (Channel) -> Unit,
    onClearContinueWatching: () -> Unit,
    onClearRecentChannels: () -> Unit,
    onClearFavorites: () -> Unit,
    onLogout: () -> Unit,
    modifier: Modifier
) {
    val heroMovie =
        (trending + popular + topRated + latest + recommended + seriesTrending + seriesPopular + seriesTopRated + seriesOnTheAir)
            .firstOrNull { it.backdropUrl.isNotBlank() }
            ?: (trending + popular + topRated + latest + recommended + seriesTrending + seriesPopular + seriesTopRated + seriesOnTheAir)
                .firstOrNull()
            ?: Movie(title = "Game Changer", backdropUrl = "", posterUrl = "")

    val categories = listOfNotNull(
        if (trending.isNotEmpty()) Category("Trending Movies", trending) else null,
        if (popular.isNotEmpty()) Category("Popular Movies", popular) else null,
        if (topRated.isNotEmpty()) Category("Top Rated Movies", topRated) else null,
        if (latest.isNotEmpty()) Category("Latest Movies", latest) else null,
        if (recommended.isNotEmpty()) Category("Recommended", recommended) else null,
        if (seriesTrending.isNotEmpty()) Category("Trending Series", seriesTrending) else null,
        if (seriesPopular.isNotEmpty()) Category("Popular Series", seriesPopular) else null,
        if (seriesTopRated.isNotEmpty()) Category("Top Rated Series", seriesTopRated) else null,
        if (seriesOnTheAir.isNotEmpty()) Category("On The Air", seriesOnTheAir) else null,
    )

    GameChangerMasterRoot(
        heroMovie = heroMovie,
        categories = categories,
        liveCategories = liveCategories,
        liveChannels = liveChannels,
        continueWatching = continueWatching,
        recentLiveChannels = recentLiveChannels,
        favoriteMovies = favoriteMovies,
        favoriteLiveChannels = favoriteLiveChannels,
        serverUrl = serverUrl,
        username = username,
        password = password,
        sectionState = sectionState,
        liveTabState = liveTabState,
        selectedLiveCategoryIdState = selectedLiveCategoryIdState,
        lastWatchedLiveStreamId = lastWatchedLiveStreamId,
        onRequestLiveChannels = onRequestLiveChannels,
        onMovieClick = onMovieClick,
        onContinueWatchingClick = onContinueWatchingClick,
        onChannelClick = onChannelClick,
        isChannelFavorite = isChannelFavorite,
        onToggleChannelFavorite = onToggleChannelFavorite,
        onClearContinueWatching = onClearContinueWatching,
        onClearRecentChannels = onClearRecentChannels,
        onClearFavorites = onClearFavorites,
        onLogout = onLogout,
        modifier = modifier
    )
}

/**
 * 1. THE CINEMATIC "LAYERED" ROOT
 *
 * 🛑 THE #1 RULE: STOP USING ROW AS THE ROOT
 * Use Box stacking so the art is UNDER the sidebar.
 */
@Composable
fun GameChangerMasterRoot(
    heroMovie: Movie,
    categories: List<Category>,
    liveCategories: List<LiveCategory>,
    liveChannels: List<Channel>,
    continueWatching: List<ContinueWatchingEntry>,
    recentLiveChannels: List<Channel>,
    favoriteMovies: List<Movie>,
    favoriteLiveChannels: List<Channel>,
    serverUrl: String,
    username: String,
    password: String,
    sectionState: androidx.compose.runtime.MutableState<SidebarSection>,
    liveTabState: androidx.compose.runtime.MutableState<LiveTab>,
    selectedLiveCategoryIdState: androidx.compose.runtime.MutableState<String>,
    lastWatchedLiveStreamId: String?,
    onRequestLiveChannels: () -> Unit,
    onMovieClick: (Movie) -> Unit,
    onContinueWatchingClick: (ContinueWatchingEntry) -> Unit,
    onChannelClick: (Channel) -> Unit,
    isChannelFavorite: (Channel) -> Boolean,
    onToggleChannelFavorite: (Channel) -> Unit,
    onClearContinueWatching: () -> Unit,
    onClearRecentChannels: () -> Unit,
    onClearFavorites: () -> Unit,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier
) {
    // ROOT BOX - Everything stacks here
    Box(modifier = modifier.fillMaxSize().background(Color.Black)) {

        val section = sectionState.value

        // Auto-refresh Live TV categories/channels from the panel while LIVE is selected
        LaunchedEffect(section) {
            if (section == SidebarSection.LIVE) {
                onRequestLiveChannels()
                while (true) {
                    delay(120_000)
                    onRequestLiveChannels()
                }
            }
        }

        var currentHero by remember(heroMovie) { mutableStateOf(heroMovie) }

        // Movie Genres (TMDB)
        val movieGenres by produceState(initialValue = emptyList<TmdbGenre>()) {
            value = try {
                withContext(Dispatchers.IO) {
                    ApiClient.tmdb()
                        .movieGenres(Keys.TMDB_API_KEY)
                        .genres
                        .sortedBy { it.name.lowercase(Locale.US) }
                }
            } catch (_: Throwable) {
                emptyList()
            }
        }

        var selectedMovieGenreId by remember { mutableStateOf<Int?>(null) }
        var selectedSeriesYear by remember { mutableStateOf<Int?>(null) }

        LaunchedEffect(movieGenres) {
            if (selectedMovieGenreId == null && movieGenres.isNotEmpty()) {
                selectedMovieGenreId = movieGenres.first().id
            }
        }

        val genreMovies by produceState(initialValue = emptyList<Movie>(), selectedMovieGenreId) {
            val gid = selectedMovieGenreId
            value = if (gid == null) {
                emptyList()
            } else {
                try {
                    withContext(Dispatchers.IO) {
                        val items = coroutineScope {
                            (1..4).map { page ->
                                async {
                                    ApiClient.tmdb()
                                        .discoverMovies(Keys.TMDB_API_KEY, gid, page = page)
                                        .results
                                }
                            }.awaitAll().flatten()
                        }
                            .map { it.toUiMovie() }
                            .filter { it.title.isNotBlank() && (it.posterUrl.isNotBlank() || it.backdropUrl.isNotBlank()) }
                            .distinctBy { "${it.mediaType}_${it.id}_${it.title}_${it.year}" }

                        mixMoviesYearRange(items, startYear = 2012, endYear = 2026, maxItems = 60)
                    }
                } catch (_: Throwable) {
                    emptyList()
                }
            }
        }

        val yearSeries by produceState(initialValue = emptyList<Movie>(), selectedSeriesYear) {
            val y = selectedSeriesYear
            value = if (y == null) {
                emptyList()
            } else {
                try {
                    withContext(Dispatchers.IO) {
                        val items = coroutineScope {
                            (1..6).map { page ->
                                async {
                                    ApiClient.tmdb()
                                        .discoverSeries(Keys.TMDB_API_KEY, year = y, page = page)
                                        .results
                                }
                            }.awaitAll().flatten()
                        }
                            .map { it.toUiMovie() }
                            .filter { it.title.isNotBlank() && (it.posterUrl.isNotBlank() || it.backdropUrl.isNotBlank()) }
                            .filter { it.year.toIntOrNull() == y }
                            .distinctBy { "${it.mediaType}_${it.id}_${it.title}_${it.year}" }

                        items.take(80)
                    }
                } catch (_: Throwable) {
                    emptyList()
                }
            }
        }

        LaunchedEffect(section, selectedMovieGenreId, genreMovies, categories) {
            if (section != SidebarSection.MOVIES) return@LaunchedEffect
            if (genreMovies.isNotEmpty()) {
                currentHero = genreMovies.first()
                return@LaunchedEffect
            }
            val fallback = categories
                .firstOrNull { it.title.contains("Movies") || it.title == "Recommended" }
                ?.items
                ?.firstOrNull()
            if (fallback != null) currentHero = fallback
        }

        LaunchedEffect(section, selectedSeriesYear, yearSeries, categories) {
            if (section != SidebarSection.SERIES) return@LaunchedEffect
            if (selectedSeriesYear != null) {
                if (yearSeries.isNotEmpty()) currentHero = yearSeries.first()
                return@LaunchedEffect
            }
            val fallback = categories
                .firstOrNull { it.title.contains("Series") || it.title == "On The Air" }
                ?.items
                ?.firstOrNull()
            if (fallback != null) currentHero = fallback
        }

        // LAYER 1: THE BACKDROP (Wide Landscape)
        val isLiveTv = section == SidebarSection.LIVE
        val isSearch = section == SidebarSection.SEARCH
        val isSettings = section == SidebarSection.SETTINGS
        val isMyStuff = section == SidebarSection.MY_STUFF

        val heroPoster = currentHero.posterUrl
        val heroModel = currentHero.backdropUrl.ifBlank { heroPoster }

        if (isLiveTv || isSearch || isSettings || isMyStuff) {
            val bgRes = when (section) {
                SidebarSection.LIVE -> R.drawable.bg_live_tv_xtream
                SidebarSection.SEARCH -> R.drawable.bg_search_xtream
                SidebarSection.MY_STUFF -> R.drawable.bg_settings_xtream
                SidebarSection.SETTINGS -> R.drawable.bg_settings_xtream
                else -> R.drawable.bg_live_tv_xtream
            }
            Image(
                painter = painterResource(id = bgRes),
                contentDescription = null,
                modifier = Modifier
                    .fillMaxSize()
                    .alpha(0.98f),
                contentScale = ContentScale.Crop
            )
        } else {
            SubcomposeAsyncImage(
                model = heroModel,
                contentDescription = null,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(600.dp) // Covers top half
                    .alpha(0.88f),
                contentScale = ContentScale.Crop,
                error = {
                    if (heroPoster.isNotBlank() && heroModel != heroPoster) {
                        AsyncImage(
                            model = heroPoster,
                            contentDescription = null,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(600.dp)
                                .alpha(0.88f),
                            contentScale = ContentScale.Crop
                        )
                    }
                }
            )
        }

        // LAYER 2: THE DEEP VOID GRADIENT (The 'Fade')
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
            colors = listOf(
                Color.Transparent, // Top is clear
                Color(0x77000000), // Start of the fade
                Color(0xDD000000), // Heavy shadow
                Color.Black,       // SOLID BLACK FLOOR (Pure darkness)
                Color.Black        // Extra padding to ensure pure black for rows
            ),
            startY = 200f, // Fade starts higher up for a smoother dissolve
            endY = 900f
        )
                )
        )


        // LAYER 2.5: HERO SCRIM (Bottom-left clarity, leaves left rail untouched)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(start = 88.dp)
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color(0xAA000000),
                            Color.Transparent
                        ),
                        start = Offset(0f, 980f),
                        end = Offset(820f, 260f)
                    )
                )
        )

        // LAYER 3: THE UI CONTENT
        Row(modifier = Modifier.fillMaxSize()) {

            // SIDEBAR (Icons Only!)
            Column(
                modifier = Modifier
                    .width(88.dp)
                    .fillMaxHeight()
                    .background(Color(0x44000000)) // Glassy/Semi-Clear
                    .border(1.dp, Color(0x22FFFFFF))
                    .padding(vertical = 40.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // X LOGO (Top)
                Image(
                    painter = painterResource(id = R.drawable.ic_gamechanger_logo),
                    contentDescription = "Logo",
                    modifier = Modifier
                        .size(64.dp)
                        .shadow(28.dp, spotColor = Color(0xFF00FFFF), ambientColor = Color(0x6600FFFF)),
                    contentScale = ContentScale.Fit
                )
Spacer(Modifier.height(58.dp))

                // Symbols ONLY, no text labels
                SidebarIcon(Icons.Default.Home, isSelected = section == SidebarSection.HOME, onClick = { sectionState.value = SidebarSection.HOME })
                SidebarIcon(Icons.Default.Movie, isSelected = section == SidebarSection.MOVIES, onClick = { sectionState.value = SidebarSection.MOVIES })
                SidebarIcon(Icons.Default.VideoLibrary, isSelected = section == SidebarSection.SERIES, onClick = { sectionState.value = SidebarSection.SERIES })
                SidebarIcon(Icons.Default.LiveTv, isSelected = section == SidebarSection.LIVE, onClick = { sectionState.value = SidebarSection.LIVE })
                SidebarIcon(Icons.Default.Search, isSelected = section == SidebarSection.SEARCH, onClick = { sectionState.value = SidebarSection.SEARCH })
                SidebarIcon(Icons.Default.Bookmark, isSelected = section == SidebarSection.MY_STUFF, onClick = { sectionState.value = SidebarSection.MY_STUFF })

                Spacer(Modifier.weight(1f))

                SidebarIcon(Icons.Default.Settings, isSelected = section == SidebarSection.SETTINGS, onClick = { sectionState.value = SidebarSection.SETTINGS })
            }

            // CONTENT AREA
            Column(modifier = Modifier.weight(1f).padding(start = 48.dp, top = if (section == SidebarSection.SEARCH) 40.dp else 52.dp)) {
                // BRANDING
                val isStaticBrand = section == SidebarSection.LIVE || section == SidebarSection.SEARCH || section == SidebarSection.MY_STUFF || section == SidebarSection.SETTINGS
                val heroTitle = when (section) {
                    SidebarSection.LIVE -> "Live TV"
                    SidebarSection.SEARCH -> ""
                    SidebarSection.MY_STUFF -> "My Lists"
                    SidebarSection.SETTINGS -> "Settings"
                    else -> currentHero.title
                }
                val heroSubtitle = if (isStaticBrand) "" else run {
                    val ratingText = if (currentHero.rating > 0.0) {
                        "★ ${String.format(Locale.US, "%.1f", currentHero.rating)}"
                    } else {
                        ""
                    }
                    listOfNotNull(
                        currentHero.year.takeIf { it.isNotBlank() },
                        ratingText.takeIf { it.isNotBlank() }
                    ).joinToString(" • ")
                }

                val heroTitleFontSize = when {
                    heroTitle.length >= 42 -> 40.sp
                    heroTitle.length >= 30 -> 46.sp
                    heroTitle.length >= 20 -> 54.sp
                    else -> MaterialTheme.typography.displayMedium.fontSize
                }
                val heroTitleLineHeight = when {
                    heroTitle.length >= 42 -> 42.sp
                    heroTitle.length >= 30 -> 48.sp
                    heroTitle.length >= 20 -> 56.sp
                    else -> MaterialTheme.typography.displayMedium.lineHeight
                }

                if (heroTitle.isNotBlank()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.82f)
                            .height(104.dp),
                        contentAlignment = Alignment.TopStart
                    ) {
                        Text(
                            text = heroTitle,
                            fontWeight = FontWeight.Black,
                            fontSize = heroTitleFontSize,
                            lineHeight = heroTitleLineHeight,
                            letterSpacing = 0.5.sp,
                            color = Color.White,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                if (heroSubtitle.isNotBlank()) {
                    Text(
                        text = heroSubtitle,
                        color = Color(0xEFFFFFFF),
                        modifier = Modifier
                            .padding(top = 6.dp)
                            .background(Color(0x33000000), RoundedCornerShape(10.dp))
                            .padding(horizontal = 9.dp, vertical = 3.dp)
                    )
                }

                // Tighten hero-to-row spacing so full cards stay visible on shorter displays.
                Spacer(Modifier.height(when (section) {
                    SidebarSection.LIVE -> 24.dp
                    SidebarSection.SEARCH -> 20.dp
                    SidebarSection.SETTINGS -> 44.dp
                    else -> 44.dp
                }))

                // MINI ROWS (140x210 Cards)
                val visibleCategoriesRaw = when (section) {
                    SidebarSection.HOME -> categories
                    SidebarSection.MOVIES -> categories.filter { !it.title.contains("Series") && it.title != "On The Air" }
                    SidebarSection.SERIES -> categories.filter { it.title.contains("Series") || it.title == "On The Air" }
                    else -> emptyList()
                }

                val visibleCategories = if (section == SidebarSection.SERIES && selectedSeriesYear != null) {
                    val y = selectedSeriesYear
                    if (y == null) {
                        visibleCategoriesRaw
                    } else {
                        yearSeries.takeIf { it.isNotEmpty() }?.let { items ->
                            listOf(Category("Series $y", items))
                        } ?: emptyList()
                    }
                } else {
                    visibleCategoriesRaw
                }

                when (section) {
                    SidebarSection.LIVE -> {
                        Text(
                            text = "Live TV",
                            color = Color.White,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(Modifier.height(16.dp))

                        var liveTab by liveTabState
                        var manualRefreshTick by remember { mutableStateOf(0) }
                        var channelSearchQuery by remember { mutableStateOf("") }
                        
                        val channelsTabRequester = remember { FocusRequester() }
                        val guideTabRequester = remember { FocusRequester() }
                        val refreshTabRequester = remember { FocusRequester() }
                        val searchRequester = remember { FocusRequester() }
                        val firstGridRequester = remember { FocusRequester() }
                        val firstEpgRequester = remember { FocusRequester() }
                        
                        val channelsInteraction = remember { MutableInteractionSource() }
                        val guideInteraction = remember { MutableInteractionSource() }
                        val refreshInteraction = remember { MutableInteractionSource() }
                        val searchInteraction = remember { MutableInteractionSource() }
                        
                        val channelsFocused by channelsInteraction.collectIsFocusedAsState()
                        val guideFocused by guideInteraction.collectIsFocusedAsState()
                        val refreshFocused by refreshInteraction.collectIsFocusedAsState()
                        val searchFocused by searchInteraction.collectIsFocusedAsState()
                        
                        // Ensure a predictable starting focus on TV remotes.
                        LaunchedEffect(Unit) {
                            withFrameNanos { }
                            runCatching { channelsTabRequester.requestFocus() }
                        }
                        
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Card(
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .focusRequester(channelsTabRequester)
                                    .focusProperties {
                                        right = guideTabRequester
                                        down = if (liveTab == LiveTab.CHANNELS) firstGridRequester else firstEpgRequester
                                    }
                                    .shadow(if (channelsFocused) 10.dp else 0.dp, RoundedCornerShape(14.dp), clip = false)
                                    .focusable(interactionSource = channelsInteraction)
                                    .clickable(
                                        interactionSource = channelsInteraction,
                                        indication = null
                                    ) { liveTabState.value = LiveTab.CHANNELS }
                                    .border(
                                        width = if (channelsFocused) 3.dp else 1.dp,
                                        color = if (channelsFocused) CyanGlow else Color(0x33FFFFFF),
                                        shape = RoundedCornerShape(14.dp)
                                    ),
                                colors = CardDefaults.cardColors(
                                    containerColor = when {
                                        channelsFocused -> Color(0x26FFFFFF)
                                        liveTab == LiveTab.CHANNELS -> Color(0x1AFFFFFF)
                                        else -> Color(0x14000000)
                                    }
                                )
                            ) {
                                Text(
                                    text = "Channels",
                                    color = if (channelsFocused) CyanGlow else Color.White,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = if (liveTab == LiveTab.CHANNELS) FontWeight.SemiBold else FontWeight.Normal,
                                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp)
                                )
                            }
                        
                            Card(
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .focusRequester(guideTabRequester)
                                    .focusProperties {
                                        left = channelsTabRequester
                                        right = refreshTabRequester
                                        down = firstEpgRequester
                                    }
                                    .shadow(if (guideFocused) 10.dp else 0.dp, RoundedCornerShape(14.dp), clip = false)
                                    .focusable(interactionSource = guideInteraction)
                                    .clickable(
                                        interactionSource = guideInteraction,
                                        indication = null
                                    ) { liveTabState.value = LiveTab.GUIDE }
                                    .border(
                                        width = if (guideFocused) 3.dp else 1.dp,
                                        color = if (guideFocused) CyanGlow else Color(0x33FFFFFF),
                                        shape = RoundedCornerShape(14.dp)
                                    ),
                                colors = CardDefaults.cardColors(
                                    containerColor = when {
                                        guideFocused -> Color(0x26FFFFFF)
                                        liveTab == LiveTab.GUIDE -> Color(0x1AFFFFFF)
                                        else -> Color(0x14000000)
                                    }
                                )
                            ) {
                                Text(
                                    text = "Guide",
                                    color = if (guideFocused) CyanGlow else Color.White,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = if (liveTab == LiveTab.GUIDE) FontWeight.SemiBold else FontWeight.Normal,
                                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp)
                                )
                            }
                        
                            Card(
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .focusRequester(refreshTabRequester)
                                    .focusProperties {
                                        left = guideTabRequester
                                        right = searchRequester
                                        down = if (liveTab == LiveTab.CHANNELS) firstGridRequester else firstEpgRequester
                                    }
                                    .shadow(if (refreshFocused) 10.dp else 0.dp, RoundedCornerShape(14.dp), clip = false)
                                    .focusable(interactionSource = refreshInteraction)
                                    .clickable(
                                        interactionSource = refreshInteraction,
                                        indication = null
                                    ) {
                                        onRequestLiveChannels()
                                        manualRefreshTick++
                                    }
                                    .border(
                                        width = if (refreshFocused) 3.dp else 1.dp,
                                        color = if (refreshFocused) CyanGlow else Color(0x33FFFFFF),
                                        shape = RoundedCornerShape(14.dp)
                                    ),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (refreshFocused) Color(0x26FFFFFF) else Color(0x14000000)
                                )
                            ) {
                                Text(
                                    text = "Refresh",
                                    color = if (refreshFocused) CyanGlow else Color.White,
                                    style = MaterialTheme.typography.titleSmall,
                                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp)
                                )
                            }


                            Spacer(Modifier.weight(1f))

                            OutlinedTextField(
                                value = channelSearchQuery,
                                onValueChange = { channelSearchQuery = it },
                                singleLine = true,
                                placeholder = { Text("Search channels", color = Color(0xFF7A7A7A)) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Filled.Search,
                                        contentDescription = null,
                                        tint = if (searchFocused) CyanGlow else Color(0xCCFFFFFF)
                                    )
                                },
                                trailingIcon = {
                                    if (channelSearchQuery.isNotBlank()) {
                                        Icon(
                                            imageVector = Icons.Filled.Close,
                                            contentDescription = null,
                                            tint = if (searchFocused) CyanGlow else Color(0xCCFFFFFF),
                                            modifier = Modifier
                                                .clickable(
                                                    interactionSource = remember { MutableInteractionSource() },
                                                    indication = null
                                                ) { channelSearchQuery = "" }
                                                .padding(6.dp)
                                        )
                                    }
                                },
                                shape = RoundedCornerShape(14.dp),
                                interactionSource = searchInteraction,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = CyanGlow,
                                    unfocusedBorderColor = Color(0x33FFFFFF),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    cursorColor = CyanGlow,
                                    focusedContainerColor = Color(0x14000000),
                                    unfocusedContainerColor = Color(0x14000000)
                                ),
                                modifier = Modifier
                                    .widthIn(min = 360.dp, max = 560.dp)
                                    .focusRequester(searchRequester)
                                    .focusProperties {
                                        left = refreshTabRequester
                                        down = if (liveTab == LiveTab.CHANNELS) firstGridRequester else firstEpgRequester
                                    }
                            )
                        }

                        Spacer(Modifier.height(16.dp))

                        if (liveChannels.isEmpty()) {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                FocusFallbackTarget(firstGridRequester)
                                FocusFallbackTarget(firstEpgRequester)
                                Text("Loading…", color = Color.Gray)
                            }
                        } else {
                            var selectedLiveCategoryId by selectedLiveCategoryIdState

                            var focusedLiveCategoryId by remember { mutableStateOf<String?>(null) }

                            // Keep categories EXACTLY as the panel returns them (no sorting / no extra items).
                            LaunchedEffect(liveCategories) {
                                if (selectedLiveCategoryId.isBlank() && liveCategories.isNotEmpty()) {
                                    selectedLiveCategoryId = liveCategories.first().id
                                }
                            }

                            val categoryList = liveCategories

                            val filteredChannels = remember(selectedLiveCategoryId, liveChannels, channelSearchQuery) {
                                val base = if (selectedLiveCategoryId.isBlank()) liveChannels
                                else liveChannels.filter { it.categoryId == selectedLiveCategoryId }

                                val q = channelSearchQuery.trim().lowercase(Locale.getDefault())
                                if (q.isBlank()) base
                                else base.filter { c ->
                                    c.name.lowercase(Locale.getDefault()).contains(q) ||
                                        c.groupTitle.lowercase(Locale.getDefault()).contains(q)
                                }
                            }
                            val preferredLiveChannelIndex = remember(lastWatchedLiveStreamId, filteredChannels) {
                                val target = lastWatchedLiveStreamId
                                if (target.isNullOrBlank()) 0 else filteredChannels.indexOfFirst { it.streamId == target }.takeIf { it >= 0 } ?: 0
                            }
                            val gridState = rememberLazyGridState()
                            LaunchedEffect(selectedLiveCategoryId, channelSearchQuery, preferredLiveChannelIndex, filteredChannels.size) {
                                if (filteredChannels.isNotEmpty()) {
                                    runCatching { gridState.scrollToItem(preferredLiveChannelIndex.coerceIn(0, filteredChannels.lastIndex)) }
                                }
                            }

                            val needsGridFallbackTarget = filteredChannels.isEmpty()
                            val needsEpgFallbackTarget = filteredChannels.isEmpty()

                            // Soft panel so text/buttons are readable on the hero backdrop
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 420.dp)
                                    .background(Color(0x26000000), RoundedCornerShape(18.dp))
                                    .padding(18.dp)
                            ) {
                                Row(modifier = Modifier.fillMaxSize()) {
                                    if (needsGridFallbackTarget) FocusFallbackTarget(firstGridRequester)
                                    if (needsEpgFallbackTarget) FocusFallbackTarget(firstEpgRequester)
                                    // CATEGORY RAIL (left)
                                    LazyColumn(
                                        modifier = Modifier
                                            .width(260.dp)
                                            .fillMaxHeight(),
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        items(categoryList, key = { it.id }) { cat ->
                                            val selected = cat.id == selectedLiveCategoryId
                                            val focused = focusedLiveCategoryId == cat.id
                                            val active = selected || focused
                                            val interaction = remember { MutableInteractionSource() }

                                            Card(
                                                shape = RoundedCornerShape(14.dp),
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .onFocusChanged { if (it.isFocused) focusedLiveCategoryId = cat.id }
                                                    .onPreviewKeyEvent { e ->
                                                        if (e.type == KeyEventType.KeyUp && e.key == Key.DirectionRight) {
                                                            channelsTabRequester.requestFocus()
                                                            true
                                                        } else {
                                                            false
                                                        }
                                                    }
                                                    .focusable(interactionSource = interaction)
                                                    .clickable(interactionSource = interaction, indication = null) {
                                                        selectedLiveCategoryId = cat.id
                                                    }
                                                    .border(
                                                        width = if (active) 3.dp else 1.dp,
                                                        color = if (active) CyanGlow else Color(0x33FFFFFF),
                                                        shape = RoundedCornerShape(14.dp)
                                                    ),
                                                colors = CardDefaults.cardColors(
                                                    containerColor = if (active) Color(0x26FFFFFF) else Color(0x14000000)
                                                )
                                            ) {
                                                Text(
                                                    text = cat.name,
                                                    color = if (active) CyanGlow else Color.White,
                                                    style = MaterialTheme.typography.titleSmall,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp)
                                                )
                                            }
                                        }
                                    }

                                    Spacer(Modifier.width(18.dp))

                                    if (liveTab == LiveTab.CHANNELS) {
                                        LazyVerticalGrid(
                                            columns = GridCells.Fixed(6),
                                            state = gridState,
                                            modifier = Modifier
                                                .fillMaxHeight()
                                                .weight(1f),
                                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                                            verticalArrangement = Arrangement.spacedBy(14.dp),
                                            contentPadding = PaddingValues(4.dp)
                                        ) {
                                            itemsIndexed(filteredChannels, key = { _, ch -> ch.streamId.ifBlank { ch.name } }) { idx, channel ->
                                                MockupChannelCard(
                                                    channel = channel,
                                                    isSelected = !lastWatchedLiveStreamId.isNullOrBlank() && channel.streamId == lastWatchedLiveStreamId,
                                                    onClick = { onChannelClick(channel) },
                                                    modifier = if (idx == preferredLiveChannelIndex) Modifier.focusRequester(firstGridRequester) else Modifier
                                                )
                                            }
                                        }
                                    } else {
                                        data class EpgUiState(
                                            val loading: Boolean = false,
                                            val error: String? = null,
                                            val sourceUrl: String = "",
                                            val data: Map<String, com.gamechanger.iptv.api.EpgNowNext> = emptyMap()
                                        )

                                        val appCtx = LocalContext.current.applicationContext
                                        var epgNowTickMs by remember(liveTab, selectedLiveCategoryId) { mutableLongStateOf(TimeSync.nowMs()) }

                                        LaunchedEffect(liveTab, selectedLiveCategoryId, filteredChannels.size) {
                                            if (liveTab != LiveTab.GUIDE) return@LaunchedEffect
                                            while (true) {
                                                epgNowTickMs = TimeSync.nowMs()
                                                delay(30_000)
                                            }
                                        }

                                        val epgUi by produceState(
                                            initialValue = EpgUiState(),
                                            liveTab,
                                            selectedLiveCategoryId,
                                            serverUrl,
                                            username,
                                            password,
                                            filteredChannels.size,
                                            manualRefreshTick,
                                            epgNowTickMs
                                        ) {
                                            if (liveTab != LiveTab.GUIDE) {
                                                value = EpgUiState()
                                                return@produceState
                                            }

                                            val streamIds = filteredChannels.map { it.streamId }.filter { it.isNotBlank() }

                                            // Load cached EPG from app DB first (instant display), then refresh network if needed.
                                            val (cachedAt, cachedMap) = try {
                                                withContext(Dispatchers.IO) {
                                                    EpgDbHelper(appCtx).readNowNext(streamIds, nowMs = epgNowTickMs)
                                                }
                                            } catch (_: Throwable) {
                                                0L to emptyMap()
                                            }

                                            val now = epgNowTickMs
                                            val stale = cachedAt <= 0L || (now - cachedAt) > 10L * 60_000L
                                            val depleted = cachedMap.isNotEmpty() && cachedMap.values.count { it.current == null } >= kotlin.math.max(3, cachedMap.size / 2)
                                            val shouldFetch = manualRefreshTick > 0 || cachedMap.isEmpty() || stale || depleted

                                            if (!shouldFetch) {
                                                value = EpgUiState(loading = false, data = cachedMap)
                                                return@produceState
                                            }

                                            value = if (cachedMap.isNotEmpty()) {
                                                EpgUiState(loading = true, data = cachedMap)
                                            } else {
                                                EpgUiState(loading = true)
                                            }

                                            value = try {
                                                val res = EpgXmltv.fetchNowNextForChannelsFromUrls(
                                                    urls = HARDCODED_EPG_URLS,
                                                    channels = filteredChannels
                                                )
                                                runCatching {
                                                    withContext(Dispatchers.IO) {
                                                        EpgDbHelper(appCtx).writeNowNext(res.nowNextByStreamId)
                                                    }
                                                }
                                                EpgUiState(
                                                    loading = false,
                                                    data = res.nowNextByStreamId
                                                )
                                            } catch (t: Throwable) {
                                                Log.e("EPG", "EPG load failed", t)
                                                if (cachedMap.isNotEmpty()) {
                                                    EpgUiState(
                                                        loading = false,
                                                        data = cachedMap
                                                    )
                                                } else {
                                                    EpgUiState(
                                                        loading = false,
                                                        error = "EPG unavailable",
                                                        data = emptyMap()
                                                    )
                                                }
                                            }
                                        }

                                        val timeFmt = remember { SimpleDateFormat("h:mm a", Locale.US) }

                                        Column(
                                            modifier = Modifier
                                                .fillMaxHeight()
                                                .weight(1f)
                                        ) {
                                            Text(
                                                text = "EPG Guide",
                                                color = Color.White,
                                                style = MaterialTheme.typography.titleLarge,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                            Spacer(Modifier.height(8.dp))

                                            val epgErr = epgUi.error

                                            if (epgUi.loading) {
                                                Text("Loading…", color = Color.Gray)
                                                Spacer(Modifier.height(12.dp))
                                            } else if (!epgErr.isNullOrBlank()) {
                                                Text(epgErr, color = Color.Gray)
                                                Spacer(Modifier.height(12.dp))
                                            }

                                            LazyColumn(
                                                modifier = Modifier.fillMaxSize(),
                                                verticalArrangement = Arrangement.spacedBy(10.dp)
                                            ) {
                                                itemsIndexed(filteredChannels, key = { _, ch -> ch.streamId.ifBlank { ch.name } }) { idx, ch ->
                                                    val nn = epgUi.data[ch.streamId]
                                                    val cur = nn?.current
                                                    val nxt = nn?.next
                                                    val interaction = remember { MutableInteractionSource() }
                                                    val isFocused by interaction.collectIsFocusedAsState()

                                                    Card(
                                                        shape = RoundedCornerShape(14.dp),
                                                        modifier = (if (idx == preferredLiveChannelIndex) Modifier.focusRequester(firstEpgRequester) else Modifier)
                                                            .fillMaxWidth()
                                                            .shadow(if (isFocused) 10.dp else 0.dp, RoundedCornerShape(14.dp), clip = false)
                                                            .onPreviewKeyEvent { e ->
                                                                if (e.type == KeyEventType.KeyUp && (
                                                                        e.key == Key.Enter ||
                                                                            e.key == Key.NumPadEnter ||
                                                                            e.key == Key.DirectionCenter
                                                                    )
                                                                ) {
                                                                    onChannelClick(ch)
                                                                    true
                                                                } else {
                                                                    false
                                                                }
                                                            }
                                                            .focusable(interactionSource = interaction)
                                                            .clickable(
                                                                interactionSource = interaction,
                                                                indication = null
                                                            ) { onChannelClick(ch) }
                                                            .border(
                                                                width = if (isFocused) 2.dp else 1.dp,
                                                                color = if (isFocused) CyanGlow else Color(0x22FFFFFF),
                                                                shape = RoundedCornerShape(14.dp)
                                                            ),
                                                        colors = CardDefaults.cardColors(containerColor = if (isFocused) Color(0x2400E5FF) else Color(0x14000000))
                                                    ) {
                                                        Column(Modifier.padding(horizontal = 14.dp, vertical = 12.dp)) {
                                                            Text(
                                                                text = ch.name,
                                                                color = Color.White,
                                                                style = MaterialTheme.typography.titleSmall,
                                                                maxLines = 1,
                                                                overflow = TextOverflow.Ellipsis
                                                            )

                                                            Spacer(Modifier.height(4.dp))

                                                            Text(
                                                                text = if (cur != null) {
                                                                    "Now: ${cur.title} (${timeFmt.format(Date(cur.startMs))} - ${timeFmt.format(Date(cur.stopMs))})"
                                                                } else {
                                                                    "Now: —"
                                                                },
                                                                color = Color.Gray,
                                                                style = MaterialTheme.typography.bodySmall,
                                                                maxLines = 1,
                                                                overflow = TextOverflow.Ellipsis
                                                            )
                                                            Text(
                                                                text = if (nxt != null) {
                                                                    "Next: ${nxt.title} (${timeFmt.format(Date(nxt.startMs))})"
                                                                } else {
                                                                    "Next: —"
                                                                },
                                                                color = Color.Gray,
                                                                style = MaterialTheme.typography.bodySmall,
                                                                maxLines = 1,
                                                                overflow = TextOverflow.Ellipsis
                                                            )
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    SidebarSection.MY_STUFF -> {
                        val myContinueWatching = continueWatching.take(20)
                        val myRecentLive = recentLiveChannels.take(18)
                        val myFavoriteMovies = favoriteMovies.take(20)
                        val myFavoriteLive = favoriteLiveChannels.take(18)

                        if (
                            myContinueWatching.isEmpty() &&
                            myRecentLive.isEmpty() &&
                            myFavoriteMovies.isEmpty() &&
                            myFavoriteLive.isEmpty()
                        ) {
                            Card(
                                shape = RoundedCornerShape(18.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0x16000000)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(18.dp))
                            ) {
                                Text(
                                    text = "Nothing saved yet",
                                    color = Color.White,
                                    style = MaterialTheme.typography.titleMedium,
                                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 20.dp)
                                )
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                verticalArrangement = Arrangement.spacedBy(24.dp)
                            ) {
                                if (myContinueWatching.isNotEmpty()) {
                                    item {
                                        ShelfSectionHeader("Continue Watching")
                                        ContinueWatchingShelfRow(
                                            entries = myContinueWatching,
                                            onClick = onContinueWatchingClick,
                                            onMovieFocused = { currentHero = it }
                                        )
                                    }
                                }

                                if (myRecentLive.isNotEmpty()) {
                                    item {
                                        ShelfSectionHeader("Recent Live Channels")
                                        ChannelShelfRow(
                                            channels = myRecentLive,
                                            selectedStreamId = lastWatchedLiveStreamId,
                                            onClick = onChannelClick
                                        )
                                    }
                                }

                                if (myFavoriteMovies.isNotEmpty() || myFavoriteLive.isNotEmpty()) {
                                    item {
                                        ShelfSectionHeader("Favorites")
                                        Column(
                                            verticalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            if (myFavoriteMovies.isNotEmpty()) {
                                                Text(
                                                    text = "Movies",
                                                    color = Color(0xCCFFFFFF),
                                                    style = MaterialTheme.typography.titleMedium,
                                                    fontWeight = FontWeight.SemiBold,
                                                    modifier = Modifier.padding(bottom = 8.dp)
                                                )
                                                CinemaCatalogRow(
                                                    category = Category("Favorite Movies", myFavoriteMovies),
                                                    onMovieClick = onMovieClick,
                                                    onMovieFocused = { currentHero = it }
                                                )
                                            }

                                            if (myFavoriteLive.isNotEmpty()) {
                                                if (myFavoriteMovies.isNotEmpty()) {
                                                    Spacer(Modifier.height(4.dp))
                                                }
                                                Text(
                                                    text = "Live Channels",
                                                    color = Color(0xCCFFFFFF),
                                                    style = MaterialTheme.typography.titleMedium,
                                                    fontWeight = FontWeight.SemiBold,
                                                    modifier = Modifier.padding(bottom = 8.dp)
                                                )
                                                ChannelShelfRow(
                                                    channels = myFavoriteLive,
                                                    selectedStreamId = lastWatchedLiveStreamId,
                                                    onClick = onChannelClick
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    SidebarSection.SEARCH -> {
                        var searchTab by remember { mutableStateOf(SearchTab.ALL) }
                        var searchQuery by remember { mutableStateOf("") }
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            label = { Text("Search movies / TV", color = Color(0xFF7A7A7A)) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().widthIn(max = 900.dp)
                        )

                        Spacer(Modifier.height(12.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            CategoryPill(text = "All", selected = searchTab == SearchTab.ALL, onClick = { searchTab = SearchTab.ALL })
                            CategoryPill(text = "Movies", selected = searchTab == SearchTab.MOVIES, onClick = { searchTab = SearchTab.MOVIES })
                            CategoryPill(text = "TV Shows", selected = searchTab == SearchTab.SERIES, onClick = { searchTab = SearchTab.SERIES })
                        }

                        data class SearchUi(val loading: Boolean = false, val items: List<Movie> = emptyList())

                        val searchUi by produceState(
                            initialValue = SearchUi(),
                            searchQuery,
                            searchTab
                        ) {
                            val q = searchQuery.trim()
                            if (q.length < 2) {
                                value = SearchUi(loading = false, items = emptyList())
                                return@produceState
                            }

                            value = SearchUi(loading = true, items = emptyList())

                            value = try {
                                withContext(Dispatchers.IO) {
                                    val api = ApiClient.tmdb()
                                    val out = when (searchTab) {
                                        SearchTab.MOVIES -> {
                                            val r1 = api.searchMovie(Keys.TMDB_API_KEY, q, page = 1).results
                                            val r2 = api.searchMovie(Keys.TMDB_API_KEY, q, page = 2).results
                                            (r1 + r2)
                                        }
                                        SearchTab.SERIES -> {
                                            val r1 = api.searchSeries(Keys.TMDB_API_KEY, q, page = 1).results
                                            val r2 = api.searchSeries(Keys.TMDB_API_KEY, q, page = 2).results
                                            (r1 + r2)
                                        }
                                        SearchTab.ALL -> {
                                            coroutineScope {
                                                val m = async { api.searchMovie(Keys.TMDB_API_KEY, q, page = 1).results }
                                                val t = async { api.searchSeries(Keys.TMDB_API_KEY, q, page = 1).results }
                                                (m.await() + t.await())
                                            }
                                        }
                                    }

                                    val items = out
                                        .map { it.toUiMovie() }
                                        .filter { it.title.isNotBlank() && (it.posterUrl.isNotBlank() || it.backdropUrl.isNotBlank()) }
                                        .distinctBy { "${it.mediaType}_${it.id}_${it.title}_${it.year}" }
                                        .take(120)

                                    SearchUi(loading = false, items = items)
                                }
                            } catch (_: Throwable) {
                                SearchUi(loading = false, items = emptyList())
                            }
                        }

                        Spacer(Modifier.height(14.dp))

                        if (searchUi.loading) {
                            Text("Searching…", color = Color.Gray)
                        } else if (searchQuery.trim().length >= 2 && searchUi.items.isEmpty()) {
                            Text("No results", color = Color.Gray)
                        }

                        Spacer(Modifier.height(10.dp))

                        var focusedSearchId by remember(searchQuery, searchTab) { mutableStateOf<Int?>(null) }

                        LazyVerticalGrid(
                            columns = GridCells.Fixed(5),
                            modifier = Modifier.fillMaxWidth().weight(1f),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            contentPadding = PaddingValues(bottom = 160.dp, top = 4.dp)
                        ) {
                            items(searchUi.items, key = { "${it.mediaType}_${it.id}" }) { m ->
                                RadiantMoviePoster(
                                    movie = m,
                                    dim = focusedSearchId != null && focusedSearchId != m.id,
                                    onClick = { onMovieClick(m) },
                                    onFocused = {
                                        focusedSearchId = m.id
                                        currentHero = m
                                    },
                                    posterWidth = 190.dp,
                                    posterHeight = 282.dp
                                )
                            }
                        }

                    }
                    SidebarSection.SETTINGS -> {
                        Text(
                            text = "Settings",
                            color = Color.White,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(Modifier.height(16.dp))
                        var subUi by remember { mutableStateOf(SubscriptionUi()) }

                        LaunchedEffect(section, serverUrl, username, password) {
                            if (section != SidebarSection.SETTINGS) return@LaunchedEffect
                            subUi = SubscriptionUi(loading = true)

                            val ui = withContext(Dispatchers.IO) {
                                try {
                                    val api = ApiClient.xtream(serverUrl)
                                    val resp = api.getAccountInfo(username, password)
                                    val body = if (resp.isSuccessful) {
                                        resp.body() ?: api.getAccountInfoAction(username, password).body()
                                    } else {
                                        api.getAccountInfoAction(username, password).body()
                                    }

                                    val info = body?.user_info

                                    fun s(v: Any?): String? = (v as? String)?.trim()
                                    fun l(v: Any?): Long? = when (v) {
                                        is Number -> v.toLong()
                                        is String -> v.trim().toLongOrNull()
                                        else -> null
                                    }
                                    fun b(v: Any?): Boolean? = when (v) {
                                        is Boolean -> v
                                        is Number -> v.toInt() != 0
                                        is String -> {
                                            val t = v.trim().lowercase()
                                            t == "1" || t == "true" || t == "yes"
                                        }
                                        else -> null
                                    }

                                    val statusRaw = s(info?.get("status"))?.lowercase()?.trim().orEmpty()
                                    val banned = b(info?.get("is_banned")) ?: b(info?.get("banned")) ?: b(info?.get("ban")) ?: false
                                    val expSec = l(info?.get("exp_date")) ?: l(info?.get("exp"))
                                    val nowSec = System.currentTimeMillis() / 1000L

                                    val statusLabel = when {
                                        banned -> "Banned"
                                        expSec != null && expSec > 0 && nowSec >= expSec -> "Expired"
                                        statusRaw.isNotBlank() && statusRaw != "active" -> statusRaw.replaceFirstChar { it.titlecase() }
                                        else -> "Active"
                                    }

                                    val expiresLabel = when {
                                        expSec == null || expSec <= 0 -> "Never"
                                        else -> {
                                            val df = SimpleDateFormat("MMM d, yyyy h:mm a", Locale.US)
                                            df.format(Date(expSec * 1000L))
                                        }
                                    }

                                    val daysLeftLabel = when {
                                        expSec == null || expSec <= 0 -> ""
                                        expSec != null && nowSec >= expSec -> ""
                                        else -> {
                                            val days = ((expSec - nowSec) / 86400.0).toInt()
                                            if (days < 0) "" else "$days days"
                                        }
                                    }

                                    SubscriptionUi(
                                        loading = false,
                                        status = statusLabel,
                                        expires = expiresLabel,
                                        daysLeft = daysLeftLabel,
                                        message = null
                                    )
                                } catch (_: Throwable) {
                                    SubscriptionUi(
                                        loading = false,
                                        status = "",
                                        expires = "",
                                        daysLeft = "",
                                        message = "Unable to check subscription right now"
                                    )
                                }
                            }

                            subUi = ui
                        }

                        Card(
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0x16000000)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(18.dp))
                        ) {
                            Column(modifier = Modifier.padding(18.dp)) {
                                Text(
                                    text = "Subscription",
                                    color = Color.White,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 16.sp
                                )
                                Spacer(Modifier.height(10.dp))

                                if (subUi.loading) {
                                    Text("Checking…", color = Color.Gray)
                                } else if (subUi.message != null) {
                                    Text(subUi.message!!, color = Color.Gray)
                                } else {
                                    Row(horizontalArrangement = Arrangement.spacedBy(22.dp)) {
                                        Column {
                                            Text("Status", color = Color.Gray, fontSize = 12.sp)
                                            Text(subUi.status, color = Color.White, fontWeight = FontWeight.SemiBold)
                                        }
                                        Column {
                                            Text("Expires", color = Color.Gray, fontSize = 12.sp)
                                            Text(subUi.expires, color = Color.White, fontWeight = FontWeight.SemiBold)
                                        }
                                        if (subUi.daysLeft.isNotBlank()) {
                                            Column {
                                                Text("Remaining", color = Color.Gray, fontSize = 12.sp)
                                                Text(subUi.daysLeft, color = Color.White, fontWeight = FontWeight.SemiBold)
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(Modifier.height(18.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            SettingsActionCard(
                                text = "Clear Continue Watching",
                                onClick = onClearContinueWatching,
                                modifier = Modifier.weight(1f)
                            )
                            SettingsActionCard(
                                text = "Clear Recent Live",
                                onClick = onClearRecentChannels,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Spacer(Modifier.height(12.dp))

                        SettingsActionCard(
                            text = "Clear Favorites",
                            onClick = onClearFavorites,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(Modifier.height(18.dp))

                        var logoutFocused by remember { mutableStateOf(false) }
                        Card(
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .focusable()
                                .onFocusChanged { logoutFocused = it.isFocused }
                                .clickable(
                                    interactionSource = remember { MutableInteractionSource() },
                                    indication = null
                                ) { onLogout() }
                                .border(
                                    width = if (logoutFocused) 3.dp else 1.dp,
                                    color = if (logoutFocused) CyanGlow else Color(0x33FFFFFF),
                                    shape = RoundedCornerShape(14.dp)
                                ),
                            colors = CardDefaults.cardColors(
                                containerColor = if (logoutFocused) Color(0x26FFFFFF) else Color(0x14000000)
                            )
                        ) {
                            Text(
                                text = "Log Out",
                                color = if (logoutFocused) CyanGlow else Color.White,
                                style = MaterialTheme.typography.titleSmall,
                                modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp)
                            )
                        }
                    }
else -> {
                        when (section) {
                            SidebarSection.MOVIES -> {
                                val movieCategories = categories.filter { !it.title.contains("Series") && it.title != "On The Air" }
                                val selectedGenreName = movieGenres.firstOrNull { it.id == selectedMovieGenreId }?.name ?: "Genres"
                                var moviesActiveCategoryTitle by remember(section, selectedGenreName, genreMovies, movieCategories) {
                                    mutableStateOf(
                                        when {
                                            genreMovies.isNotEmpty() -> selectedGenreName
                                            movieCategories.isNotEmpty() -> movieCategories.first().title
                                            else -> ""
                                        }
                                    )
                                }

                                LaunchedEffect(selectedGenreName, genreMovies, movieCategories) {
                                    val titles = buildList {
                                        if (genreMovies.isNotEmpty()) add(selectedGenreName)
                                        addAll(movieCategories.map { it.title })
                                    }
                                    if (moviesActiveCategoryTitle !in titles) {
                                        moviesActiveCategoryTitle = titles.firstOrNull().orEmpty()
                                    }
                                }

                                LazyColumn(verticalArrangement = Arrangement.spacedBy(24.dp)) {
                                    // GENRE STRIP (scrollable LTR)
                                    item {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "Genres",
                                                color = Color.White,
                                                style = MaterialTheme.typography.titleLarge,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                            Spacer(Modifier.width(20.dp))
                                            LazyRow(
                                                modifier = Modifier.weight(1f),
                                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                                            ) {
                                                items(movieGenres) { g ->
                                                    CategoryPill(
                                                        text = g.name,
                                                        selected = g.id == selectedMovieGenreId,
                                                        onClick = { selectedMovieGenreId = g.id }
                                                    )
                                                }
                                            }
                                        }
                                    }

                                    item {
                                        if (moviesActiveCategoryTitle.isNotBlank()) {
                                            Text(
                                                text = moviesActiveCategoryTitle,
                                                color = Color.White,
                                                style = MaterialTheme.typography.titleLarge,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                    }

                                    // GENRE ROW (cards change when a genre is clicked)
                                    item {
                                        if (genreMovies.isNotEmpty()) {
                                            CinemaCatalogRow(
                                                category = Category(selectedGenreName, genreMovies),
                                                onMovieClick = onMovieClick,
                                                onRowFocused = { moviesActiveCategoryTitle = selectedGenreName },
                                                onMovieFocused = {
                                                    moviesActiveCategoryTitle = selectedGenreName
                                                    currentHero = it
                                                }
                                            )
                                        }
                                    }

                                    // ORIGINAL MOVIE ROWS (Trending/Popular/Top Rated/Latest/Recommended)
                                    items(movieCategories) { category ->
                                        CinemaCatalogRow(
                                            category = category,
                                            onMovieClick = onMovieClick,
                                            onRowFocused = { moviesActiveCategoryTitle = category.title },
                                            onMovieFocused = {
                                                moviesActiveCategoryTitle = category.title
                                                currentHero = it
                                            }
                                        )
                                    }
                                }
                            }
                            SidebarSection.SERIES -> {
                                val currentYear = java.util.Calendar.getInstance().get(java.util.Calendar.YEAR)
                                val yearList = remember(currentYear) { (1900..currentYear).toList().asReversed() }
                                var seriesActiveCategoryTitle by remember(section, visibleCategories) {
                                    mutableStateOf(visibleCategories.firstOrNull()?.title.orEmpty())
                                }

                                LaunchedEffect(visibleCategories) {
                                    if (seriesActiveCategoryTitle !in visibleCategories.map { it.title }) {
                                        seriesActiveCategoryTitle = visibleCategories.firstOrNull()?.title.orEmpty()
                                    }
                                }

                                LazyColumn(verticalArrangement = Arrangement.spacedBy(24.dp)) {
                                    item {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "Years",
                                                color = Color.White,
                                                style = MaterialTheme.typography.titleLarge,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                            Spacer(Modifier.width(20.dp))
                                            LazyRow(
                                                modifier = Modifier.weight(1f),
                                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                                            ) {
                                                item {
                                                    CategoryPill(
                                                        text = "All",
                                                        selected = selectedSeriesYear == null,
                                                        onClick = { selectedSeriesYear = null }
                                                    )
                                                }
                                                items(yearList) { y ->
                                                    CategoryPill(
                                                        text = y.toString(),
                                                        selected = selectedSeriesYear == y,
                                                        onClick = { selectedSeriesYear = y }
                                                    )
                                                }
                                            }
                                        }
                                    }

                                    item {
                                        if (seriesActiveCategoryTitle.isNotBlank()) {
                                            Text(
                                                text = seriesActiveCategoryTitle,
                                                color = Color.White,
                                                style = MaterialTheme.typography.titleLarge,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                    }

                                    items(visibleCategories) { category ->
                                        CinemaCatalogRow(
                                            category = category,
                                            onMovieClick = onMovieClick,
                                            onRowFocused = { seriesActiveCategoryTitle = category.title },
                                            onMovieFocused = {
                                                seriesActiveCategoryTitle = category.title
                                                currentHero = it
                                            }
                                        )
                                    }
                                }
                            }
                            else -> {
                                var activeCategoryTitle by remember(section, visibleCategories) {
                                    mutableStateOf(visibleCategories.firstOrNull()?.title.orEmpty())
                                }

                                LaunchedEffect(visibleCategories) {
                                    if (activeCategoryTitle !in visibleCategories.map { it.title }) {
                                        activeCategoryTitle = visibleCategories.firstOrNull()?.title.orEmpty()
                                    }
                                }

                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalArrangement = Arrangement.spacedBy(16.dp)
                                ) {
                                    if (activeCategoryTitle.isNotBlank()) {
                                        Text(
                                            text = activeCategoryTitle,
                                            color = Color.White,
                                            style = MaterialTheme.typography.titleLarge,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }

                                    LazyColumn(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .weight(1f),
                                        verticalArrangement = Arrangement.spacedBy(24.dp)
                                    ) {
                                        items(visibleCategories) { category ->
                                            CinemaCatalogRow(
                                                category = category,
                                                onMovieClick = onMovieClick,
                                                onRowFocused = { activeCategoryTitle = category.title },
                                                onMovieFocused = {
                                                    activeCategoryTitle = category.title
                                                    currentHero = it
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


@Composable
private fun ShelfSectionHeader(text: String) {
    Text(
        text = text,
        color = Color.White,
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(bottom = 12.dp)
    )
}

@Composable
private fun ContinueWatchingShelfRow(
    entries: List<ContinueWatchingEntry>,
    onClick: (ContinueWatchingEntry) -> Unit,
    onRowFocused: () -> Unit = {},
    onMovieFocused: (Movie) -> Unit = {}
) {
    Column {
        var focusedKey by remember(entries) { mutableStateOf<String?>(null) }

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            items(entries, key = { it.key }) { entry ->
                val badge = if (entry.movie.mediaType.equals("tv", ignoreCase = true)) {
                    "S${entry.seasonNumber} E${entry.episodeNumber}"
                } else {
                    "Resume"
                }
                RadiantMoviePoster(
                    movie = entry.movie,
                    dim = focusedKey != null && focusedKey != entry.key,
                    onClick = { onClick(entry) },
                    onFocused = {
                        focusedKey = entry.key
                        onRowFocused()
                        onMovieFocused(it)
                    },
                    badgeText = badge
                )
            }
        }

        Spacer(Modifier.height(32.dp))
    }
}

@Composable
private fun ChannelShelfRow(
    channels: List<Channel>,
    selectedStreamId: String? = null,
    onClick: (Channel) -> Unit,
    onRowFocused: () -> Unit = {}
) {
    Column {
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            items(channels, key = { it.streamId.ifBlank { it.name } }) { channel ->
                Box(modifier = Modifier.width(220.dp)) {
                    MockupChannelCard(
                        channel = channel,
                        isSelected = !selectedStreamId.isNullOrBlank() && channel.streamId == selectedStreamId,
                        onClick = { onClick(channel) },
                        onFocused = { onRowFocused() }
                    )
                }
            }
        }

        Spacer(Modifier.height(28.dp))
    }
}

@Composable
private fun SettingsActionCard(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var focused by remember { mutableStateOf(false) }
    Card(
        shape = RoundedCornerShape(14.dp),
        modifier = modifier
            .focusable()
            .onFocusChanged { focused = it.isFocused }
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { onClick() }
            .border(
                width = if (focused) 3.dp else 1.dp,
                color = if (focused) CyanGlow else Color(0x33FFFFFF),
                shape = RoundedCornerShape(14.dp)
            ),
        colors = CardDefaults.cardColors(
            containerColor = if (focused) Color(0x26FFFFFF) else Color(0x14000000)
        )
    ) {
        Text(
            text = text,
            color = if (focused) CyanGlow else Color.White,
            style = MaterialTheme.typography.titleSmall,
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp)
        )
    }
}


private fun mixMoviesYearRange(
    items: List<Movie>,
    startYear: Int,
    endYear: Int,
    maxItems: Int
): List<Movie> {
    if (items.isEmpty()) return items
    val buckets = LinkedHashMap<Int, ArrayDeque<Movie>>()
    for (y in startYear..endYear) buckets[y] = ArrayDeque()

    val noYear = ArrayDeque<Movie>()
    val outOfRange = ArrayDeque<Movie>()

    for (m in items) {
        val y = m.year.toIntOrNull()
        when {
            y == null -> noYear.add(m)
            y in startYear..endYear -> buckets.getValue(y).add(m)
            else -> outOfRange.add(m)
        }
    }

    // Zig-zag year order: 2026,2012,2025,2013,...
    val yearOrder = ArrayList<Int>(endYear - startYear + 1)
    var lo = startYear
    var hi = endYear
    while (lo <= hi) {
        yearOrder.add(hi)
        if (lo != hi) yearOrder.add(lo)
        hi--
        lo++
    }

    val result = ArrayList<Movie>(minOf(maxItems, items.size))

    var added = true
    while (result.size < maxItems && added) {
        added = false
        for (y in yearOrder) {
            val q = buckets[y] ?: continue
            if (q.isNotEmpty()) {
                result.add(q.removeFirst())
                added = true
                if (result.size >= maxItems) break
            }
        }
    }

    // Fill remaining spots (if any) with whatever is left, still preferring in-range.
    if (result.size < maxItems) {
        for (y in yearOrder) {
            val q = buckets[y] ?: continue
            while (q.isNotEmpty() && result.size < maxItems) {
                result.add(q.removeFirst())
            }
            if (result.size >= maxItems) break
        }
    }
    while (noYear.isNotEmpty() && result.size < maxItems) result.add(noYear.removeFirst())
    while (outOfRange.isNotEmpty() && result.size < maxItems) result.add(outOfRange.removeFirst())

    return result
}

@Composable
fun CinemaCatalogRow(
    category: Category,
    onMovieClick: (Movie) -> Unit,
    onRowFocused: () -> Unit = {},
    onMovieFocused: (Movie) -> Unit
) {
    Column {
        var focusedId by remember(category.title) { mutableStateOf<Int?>(null) }

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            items(category.items) { movie ->
                RadiantMoviePoster(
                    movie = movie,
                    dim = focusedId != null && focusedId != movie.id,
                    onClick = { onMovieClick(it) },
                    onFocused = {
                        focusedId = it.id
                        onRowFocused()
                        onMovieFocused(it)
                    }
                )
            }
        }

        Spacer(Modifier.height(32.dp))
    }
}

/**
 * 2. THE CARD GLOW (Shadow Bleed)
 *
 * Don't use a border. Use the shadow modifier with spotColor.
 */
@Composable
fun RadiantMoviePoster(
    movie: Movie,
    dim: Boolean,
    onClick: (Movie) -> Unit,
    onFocused: (Movie) -> Unit,
    posterWidth: Dp = 154.dp,
    posterHeight: Dp = 228.dp,
    badgeText: String = ""
) {
    var isFocused by remember { mutableStateOf(false) }
    val interactionSource = remember { MutableInteractionSource() }

    // Without focusable(), onFocusChanged won't fire reliably on TV/DPAD.
    // That was why the hero/backdrop wasn't updating while moving across cards.
    Column(
        modifier = Modifier
            .padding(10.dp)
            .onFocusChanged {
                isFocused = it.isFocused
                if (it.isFocused) onFocused(movie)
            }
            .alpha(if (dim) 0.72f else 1.0f)
            .offset(y = if (isFocused) (-6).dp else 0.dp)
            .scale(if (isFocused) 1.08f else 1.0f)
            .animateContentSize()
            .focusable(interactionSource = interactionSource),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Card(
            modifier = Modifier
                .width(posterWidth)
                .height(posterHeight)
                .clickable(
                    interactionSource = interactionSource,
                    indication = null
                ) { onClick(movie) }
                .then(
                    if (isFocused) Modifier.shadow(
                        elevation = 25.dp,
                        spotColor = Color.Cyan,
                        ambientColor = Color.Cyan,
                        shape = RoundedCornerShape(12.dp)
                    ) else Modifier
                ),
            shape = RoundedCornerShape(12.dp)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                AsyncImage(
                    model = movie.posterUrl,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                if (badgeText.isNotBlank()) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(8.dp)
                            .background(Color(0xCC000000), RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = badgeText,
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}

/**
 * 3. SIDEBAR ICON (Icons Only, no labels)
 */
@Composable
fun SidebarIcon(icon: ImageVector, isSelected: Boolean, onClick: () -> Unit) {
    var isFocused by remember { mutableStateOf(false) }
    val interactionSource = remember { MutableInteractionSource() }
    val active = isSelected || isFocused

    Box(
        modifier = Modifier
            .size(width = 80.dp, height = 60.dp)
            .onFocusChanged { isFocused = it.isFocused }
            .focusable(interactionSource = interactionSource)
            .clickable(
                interactionSource = interactionSource,
                indication = null
            ) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        // Blue selection block behind the icon (matches mockup highlight)
        if (active) {
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .padding(start = 10.dp, end = 6.dp)
                    .background(Color(0x3319B7FF), RoundedCornerShape(8.dp))
            )
        }
        if (active) {
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .height(35.dp)
                    .background(Color.Cyan, RoundedCornerShape(2.dp))
                    .align(Alignment.CenterStart)
            )
        }
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (active) Color.White else Color.Gray,
            modifier = Modifier.size(28.dp)
        )
    }
}


/**
 * 4. CATEGORY PILL (Scrollable category strip for Movies section)
 */
@Composable
fun CategoryPill(
    text: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    var isFocused by remember { mutableStateOf(false) }
    val interactionSource = remember { MutableInteractionSource() }
    val active = selected || isFocused

    Box(
        modifier = Modifier
            .onFocusChanged { isFocused = it.isFocused }
            .focusable(interactionSource = interactionSource)
            .clickable(
                interactionSource = interactionSource,
                indication = null
            ) { onClick() }
            .background(
                if (active) Color(0x4419B7FF) else Color(0x14000000),
                RoundedCornerShape(999.dp)
            )
            .border(
                width = if (active) 2.dp else 1.dp,
                color = if (active) Color.Cyan else Color(0x22FFFFFF),
                shape = RoundedCornerShape(999.dp)
            )
            .padding(horizontal = 13.dp, vertical = 7.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = if (active) Color.White else Color(0xCCFFFFFF),
            fontWeight = FontWeight.SemiBold,
            fontSize = 14.sp
        )
    }
}