package com.gamechanger.iptv.ui.screens

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.gamechanger.iptv.ui.components.LiveTvGrid
import com.gamechanger.iptv.ui.model.Channel

@Composable
fun LiveTvScreen(
    channels: List<Channel>,
    modifier: Modifier = Modifier,
    onChannelClick: (Channel) -> Unit = {}
) {
    LiveTvGrid(
        title = "Live TV",
        channels = channels,
        onChannelClick = onChannelClick,
        modifier = modifier
    )
}
