package com.gamechanger.iptv.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.gamechanger.iptv.ui.model.Channel

@Composable
fun LiveTvGrid(
    title: String,
    channels: List<Channel>,
    onChannelClick: (Channel) -> Unit,
    modifier: Modifier = Modifier
) {
    SectionTitle(text = title)

    LazyVerticalGrid(
        // Adaptive grid looks much better across TVs/tablets and avoids the "squashed peas" look.
        columns = GridCells.Adaptive(minSize = 320.dp),
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(
            items = channels,
            key = { c -> "${c.name}_${c.streamUrl}" }
        ) { channel ->
            MockupChannelCard(
                channel = channel,
                onClick = { onChannelClick(channel) }
            )
        }
    }
}
