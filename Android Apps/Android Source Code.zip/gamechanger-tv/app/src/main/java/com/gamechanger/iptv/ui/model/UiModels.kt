package com.gamechanger.iptv.ui.model

data class Movie(
    val id: Int = 0,
    val title: String,
    val overview: String = "",
    val backdropUrl: String = "",
    val posterUrl: String = "",
    val year: String = "",
    val rating: Double = 0.0,
    val mediaType: String = "movie"
)

data class Category(
    val title: String,
    val items: List<Movie>
)

data class Channel(
    val name: String,
    val logoUrl: String = "",
    val streamUrl: String = "",
    val groupTitle: String = "",
    val categoryId: String = "",
    val streamId: String = ""
)

data class LiveCategory(
    val id: String,
    val name: String
)
