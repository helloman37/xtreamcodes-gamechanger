package com.gamechanger.iptv.ui.theme

import androidx.compose.material3.Typography

val Typography = Typography()
