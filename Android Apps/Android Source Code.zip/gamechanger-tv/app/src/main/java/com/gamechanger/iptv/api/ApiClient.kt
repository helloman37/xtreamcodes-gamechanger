package com.gamechanger.iptv.api

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

object ApiClient {

    private val sharedOkHttp: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .writeTimeout(20, TimeUnit.SECONDS)
            .callTimeout(30, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }

    fun xtream(baseUrl: String): XtreamApiService =
        Retrofit.Builder()
            .baseUrl(baseUrl.trimEnd('/') + "/")
            .addConverterFactory(GsonConverterFactory.create())
            .client(sharedOkHttp)
            .build()
            .create(XtreamApiService::class.java)

    fun tmdb(baseUrl: String = "https://api.themoviedb.org/3/"): TmdbApiService =
        Retrofit.Builder()
                .baseUrl(baseUrl)
                // Use a shared client; TLS provider is upgraded in Application for older TV sticks.
                .client(sharedOkHttp)
                .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(TmdbApiService::class.java)

    fun updates(baseUrl: String = "https://who.what.who/"): UpdateApiService =
        Retrofit.Builder()
            .baseUrl(baseUrl)
            .addConverterFactory(GsonConverterFactory.create())
            .client(sharedOkHttp)
            .build()
            .create(UpdateApiService::class.java)
}
