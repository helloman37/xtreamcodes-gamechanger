package com.gamechanger.iptv.util

import com.gamechanger.iptv.api.UnsafeOkHttp
import okhttp3.Request
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

/**
 * Lightweight "internet time" helper.
 *
 * We sync by reading an HTTP Date header and keeping an offset from System.currentTimeMillis().
 * This keeps EPG alignment correct even if the device clock is wrong.
 */
object TimeSync {

    @Volatile private var offsetMs: Long = 0L
    @Volatile private var lastSyncMs: Long = 0L

    /** Current time in ms, adjusted by the last known internet offset. */
    fun nowMs(): Long = System.currentTimeMillis() + offsetMs

    /** True if we've ever successfully synced. */
    fun isSynced(): Boolean = lastSyncMs > 0L

    /**
     * Sync using HTTP Date header.
     * Call from a background thread (IO dispatcher). Safe to call frequently.
     */
    fun sync(serverUrl: String? = null) {
        val targets = buildList {
            val base = serverUrl?.trim()?.trimEnd('/')
            if (!base.isNullOrBlank()) {
                add(base)
                add("$base/player_api.php")
            }
            add("https://www.google.com/generate_204")
            add("https://clients3.google.com/generate_204")
        }

        for (url in targets) {
            try {
                val req = Request.Builder()
                    .url(url)
                    .head()
                    .build()

                UnsafeOkHttp.client.newCall(req).execute().use { resp ->
                    val dateHeader = resp.header("Date") ?: return@use
                    val serverMs = parseHttpDateMs(dateHeader) ?: return@use
                    val localMs = System.currentTimeMillis()
                    offsetMs = serverMs - localMs
                    lastSyncMs = localMs
                    return
                }
            } catch (_: Throwable) {
                // try next target
            }
        }
    }

    private fun parseHttpDateMs(value: String): Long? {
        val patterns = arrayOf(
            "EEE, dd MMM yyyy HH:mm:ss zzz",
            "EEEE, dd-MMM-yy HH:mm:ss zzz",
            "EEE MMM d HH:mm:ss yyyy"
        )

        for (p in patterns) {
            try {
                val sdf = SimpleDateFormat(p, Locale.US)
                sdf.timeZone = TimeZone.getTimeZone("GMT")
                val d = sdf.parse(value) ?: continue
                return d.time
            } catch (_: ParseException) {
                // next
            } catch (_: Throwable) {
                // next
            }
        }
        return null
    }
}
