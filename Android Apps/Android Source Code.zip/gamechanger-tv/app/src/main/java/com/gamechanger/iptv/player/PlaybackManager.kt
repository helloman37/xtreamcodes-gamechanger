package com.gamechanger.iptv.player

import android.content.Context
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import android.provider.Settings
import java.net.URLEncoder

object PlaybackManager {  
    fun play(dns: String, u: String, p: String, id: Int, context: Context, isLive: Boolean) {  
        val baseUrl = if (isLive) "$dns/live/$u/$p/$id" else "$dns/movie/$u/$p/$id.mp4"
        val dev = runCatching { Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) }.getOrNull().orEmpty()
        val enc = try { URLEncoder.encode(dev, "UTF-8") } catch (_: Throwable) { dev }
        val streamUrl = if (dev.isBlank() || !isLive) baseUrl else baseUrl + "?device_id=" + enc  
        val player = ExoPlayer.Builder(context).build()  
        player.setMediaItem(MediaItem.fromUri(streamUrl))  
        player.prepare()  
        player.play()  
    }  
}  