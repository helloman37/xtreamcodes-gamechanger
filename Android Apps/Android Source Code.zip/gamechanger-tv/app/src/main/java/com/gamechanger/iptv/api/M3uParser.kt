package com.gamechanger.iptv.api

import com.gamechanger.iptv.ui.model.Channel

/**
 * Minimal EXTINF M3U parser for Xtream get.php playlist.
 */
object M3uParser {

    fun parseChannels(m3uText: String, limit: Int = 1200): List<Channel> {
        if (!m3uText.startsWith("#EXTM3U")) return emptyList()

        val lines = m3uText.lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .toList()

        val safeLimit = limit.coerceAtLeast(1)
        val out = ArrayList<Channel>(minOf(safeLimit, 1200))
        val seen = HashSet<String>()
        var i = 0
        while (i < lines.size && out.size < safeLimit) {
            val line = lines[i]
            if (line.startsWith("#EXTINF", ignoreCase = true)) {
                val logo = extractAttr(line, "tvg-logo") ?: ""
                val name = extractName(line) ?: "Channel"
                val group = extractAttr(line, "group-title") ?: ""

                var j = i + 1
                while (j < lines.size && lines[j].startsWith("#")) j++
                if (j < lines.size) {
                    val url = lines[j]
                    val key = "${name.lowercase()}|${url.trim()}"
                    if (url.startsWith("http", ignoreCase = true) && seen.add(key)) {
                        out.add(Channel(name = name, logoUrl = logo, streamUrl = url, groupTitle = group))
                    }
                    i = j + 1
                    continue
                }
            }
            i++
        }
        return out
    }

    private fun extractAttr(extinfLine: String, key: String): String? {
        // key="value"
        val pattern = "\\b" + Regex.escape(key) + "\\s*=\\s*\"(.*?)\""
        return Regex(pattern).find(extinfLine)?.groupValues?.getOrNull(1)
    }

    private fun extractName(extinfLine: String): String? {
        val idx = extinfLine.lastIndexOf(',')
        if (idx >= 0 && idx + 1 < extinfLine.length) return extinfLine.substring(idx + 1).trim()
        return null
    }
}
