package com.gamechanger.iptv.ui.components

import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp

/**
 * GPU-only glow/shadow modifier (no nativeCanvas). Keeps compatibility across Compose versions.
 */
fun Modifier.glowShadow(
    color: Color,
    blurRadius: Dp,
    shapePath: (Size) -> Path
): Modifier = drawBehind {
    val path = shapePath(size)
    val blurPx = blurRadius.toPx().coerceAtLeast(0f)

    // Multi-pass stroke glow to fake blur.
    val steps = 6
    if (blurPx <= 0f) {
        drawPath(path = path, color = color.copy(alpha = 0.10f))
        return@drawBehind
    }

    for (i in steps downTo 1) {
        val t = i / steps.toFloat()
        val w = (blurPx * t).coerceAtLeast(1f)
        drawPath(
            path = path,
            color = color.copy(alpha = 0.14f * t),
            style = Stroke(width = w)
        )
    }

    // Soft fill to add body
    drawPath(path = path, color = color.copy(alpha = 0.06f))
}
