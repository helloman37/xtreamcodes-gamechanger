package com.gamechanger.iptv

import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.scale
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import com.gamechanger.iptv.ui.components.TvPillButton
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.dp
import com.gamechanger.iptv.api.ApiClient
import com.gamechanger.iptv.api.UpdateManifest
import com.gamechanger.iptv.ui.screens.GameChangerHomeScreen
import com.gamechanger.iptv.ui.screens.MainHomeScreen
import com.gamechanger.iptv.ui.theme.GameChangerTheme
import com.gamechanger.iptv.ui.theme.CyanGlow
import com.gamechanger.iptv.util.AppUpdater
import com.gamechanger.iptv.util.EpgDbHelper
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import com.gamechanger.iptv.api.PanelTelemetry
import com.gamechanger.iptv.util.TimeSync
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.foundation.focusGroup


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Keep the screen on while the app is open (Live TV / Movies should not sleep).
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val savedCreds = runCatching { EpgDbHelper(this).readCreds() }.getOrNull()
        val savedUsername = savedCreds?.first ?: ""
        val savedPassword = savedCreds?.second ?: ""

        setContent {
            val crashFile = remember { File(this.filesDir, "crash_last.txt") }
            var crashText by remember {
                mutableStateOf(if (crashFile.exists()) crashFile.readText() else null)
            }

            if (crashText != null) {
                CrashReportScreen(text = crashText!!) {
                    try {
                        crashFile.delete()
                    } catch (_: Throwable) {
                    }
                    crashText = null
                    recreate()
                }
                return@setContent
            }

            val scope = rememberCoroutineScope()
            var isLoggedIn by remember { mutableStateOf(false) }
            var serverUrl by remember { mutableStateOf("http://who.what.who") }
            var username by remember { mutableStateOf(savedUsername) }
            var password by remember { mutableStateOf(savedPassword) }
            var autoLoginTried by remember { mutableStateOf(false) }

            data class UpdateUi(
                val available: Boolean = false,
                val updating: Boolean = false,
                val manifest: UpdateManifest? = null,
                val progressBytes: Long = 0L,
                val progressTotal: Long = -1L
            )

            var updateUi by remember { mutableStateOf(UpdateUi()) }
            var pendingUpdateManifest by remember { mutableStateOf<UpdateManifest?>(null) }
            var dismissedUpdateVersionCode by remember { mutableStateOf<Int?>(null) }
            var fullscreenPlaybackActive by remember { mutableStateOf(false) }

            suspend fun fetchUpdateManifestSafely(): UpdateManifest? = withContext(Dispatchers.IO) {
                try {
                    ApiClient.updates().getUpdateManifest()
                } catch (_: Throwable) {
                    null
                }
            }

            fun offerUpdate(manifest: UpdateManifest) {
                if (manifest.versionCode <= BuildConfig.VERSION_CODE) return
                if (dismissedUpdateVersionCode == manifest.versionCode) return
                val currentShownVersion = updateUi.manifest?.versionCode
                if (currentShownVersion == manifest.versionCode && (updateUi.available || updateUi.updating)) return

                if (fullscreenPlaybackActive) {
                    pendingUpdateManifest = manifest
                    return
                }

                pendingUpdateManifest = null
                updateUi = UpdateUi(available = true, updating = false, manifest = manifest)
            }

            // Auto-login if creds exist in DB (unless banned/expired).
            LaunchedEffect(Unit) {
                if (autoLoginTried) return@LaunchedEffect
                autoLoginTried = true

                if (username.isBlank() || password.isBlank()) return@LaunchedEffect

                val (okLogin, reasonLogin) = withContext(Dispatchers.IO) {
                    try {
                        val api = ApiClient.xtream(serverUrl)
                        val resp = api.getPlaylist(username, password)
                        val body = resp.body()?.string() ?: ""
                        if (!(resp.isSuccessful && body.startsWith("#EXTM3U"))) {
                            return@withContext false to "Login failed"
                        }
                        val (ok, reason) = this@MainActivity.accountIsActive(serverUrl, username, password)
                        ok to reason
                    } catch (_: Throwable) {
                        false to "Login failed"
                    }
                }

                if (okLogin) {
                    isLoggedIn = true

                    // Notify panel: user logged in.
                    withContext(Dispatchers.IO) { PanelTelemetry.fireLogin(this@MainActivity, serverUrl, username) }

                    // Sync device time from internet/panel so EPG aligns.
                    withContext(Dispatchers.IO) { TimeSync.sync(serverUrl) }
                } else {
                    // Do not keep auto-trying banned/expired accounts.
                    runCatching { EpgDbHelper(this@MainActivity).clearCreds() }
                    username = ""
                    password = ""
                    if (!reasonLogin.isNullOrBlank()) {
                        Toast.makeText(this@MainActivity, reasonLogin, Toast.LENGTH_LONG).show()
                    }
                }
            }

            // Keep update checks alive while the app is open so new pushes show up without relaunching.
            LaunchedEffect(Unit) {
                while (true) {
                    val manifest = fetchUpdateManifestSafely()
                    if (manifest != null) {
                        offerUpdate(manifest)
                    }
                    delay(120_000)
                }
            }

            LaunchedEffect(fullscreenPlaybackActive, pendingUpdateManifest, dismissedUpdateVersionCode, updateUi.updating) {
                val pending = pendingUpdateManifest ?: return@LaunchedEffect
                if (fullscreenPlaybackActive) return@LaunchedEffect
                if (dismissedUpdateVersionCode == pending.versionCode) {
                    pendingUpdateManifest = null
                    return@LaunchedEffect
                }
                if (!updateUi.updating) {
                    pendingUpdateManifest = null
                    updateUi = UpdateUi(available = true, updating = false, manifest = pending)
                }
            }


            // Periodically verify subscription / ban status and kick back to login if needed.
            androidx.compose.runtime.LaunchedEffect(isLoggedIn, serverUrl, username, password) {
                if (!isLoggedIn) return@LaunchedEffect
                while (isLoggedIn) {
                    val (ok, reason) = this@MainActivity.accountIsActive(serverUrl, username, password)
                    if (!ok) {
                        Toast.makeText(
                            this@MainActivity,
                            reason ?: "Access ended",
                            Toast.LENGTH_LONG
                        ).show()
                        isLoggedIn = false
                        break
                    }
                    delay(20_000)
                }
            }

            GameChangerTheme {
                Box(Modifier.fillMaxSize()) {
                    if (isLoggedIn) {
                        MainHomeScreen(
                            serverUrl = serverUrl,
                            username = username,
                            password = password,
                            onLogout = {
                                isLoggedIn = false
                                username = ""
                                password = ""
                                runCatching { EpgDbHelper(this@MainActivity).clearCreds() }
                            },
                            onFullscreenPlaybackChanged = { fullscreenPlaybackActive = it }
                        )
                    } else {
                        GameChangerHomeScreen(
                            initialUsername = username,
                            initialPassword = password
                        ) { s, u, p ->
                            scope.launch {
                                try {
                                    val api = ApiClient.xtream(s)
                                    val resp = api.getPlaylist(u, p)
                                    val body = resp.body()?.string() ?: ""
                                    if (resp.isSuccessful && body.startsWith("#EXTM3U")) {
                                        val (ok, reason) = this@MainActivity.accountIsActive(s, u, p)
                                        if (!ok) {
                                            Toast.makeText(
                                                this@MainActivity,
                                                reason ?: "Access ended",
                                                Toast.LENGTH_LONG
                                            ).show()
                                            return@launch
                                        }
                                        Toast.makeText(
                                            this@MainActivity,
                                            "Connected",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                        serverUrl = s
                                        username = u
                                        password = p
                                        isLoggedIn = true
                                        runCatching { EpgDbHelper(this@MainActivity).writeCreds(u, p) }

                                        // Notify panel: user logged in.
                                        launch(Dispatchers.IO) { PanelTelemetry.fireLogin(this@MainActivity, serverUrl, username) }

                                        // Sync device time from internet/panel so EPG aligns.
                                        launch(Dispatchers.IO) { TimeSync.sync(serverUrl) }
                                    } else {
                                        throw RuntimeException("Bad response: HTTP " + resp.code())
                                    }
                                } catch (e: Exception) {
                                    Toast.makeText(
                                        this@MainActivity,
                                        "Login failed: " + (e.message ?: e::class.java.simpleName),
                                        Toast.LENGTH_LONG
                                    ).show()
                                }
                            }
                        }
                    }

                    // Keep time reasonably fresh while logged in.
                    androidx.compose.runtime.LaunchedEffect(isLoggedIn, serverUrl) {
                        if (!isLoggedIn) return@LaunchedEffect
                        while (isLoggedIn) {
                            try {
                                withContext(Dispatchers.IO) { TimeSync.sync(serverUrl) }
                            } catch (_: Throwable) {
                            }
                            delay(30L * 60_000L) // every 30 min
                        }
                    }

                    if (updateUi.available && updateUi.manifest != null) {
                        UpdateOverlay(
                            currentVersionName = BuildConfig.VERSION_NAME,
                            newVersionCode = updateUi.manifest!!.versionCode,
                            changelog = updateUi.manifest!!.changelog,
                            updating = updateUi.updating,
                            progressBytes = updateUi.progressBytes,
                            progressTotal = updateUi.progressTotal,
                            onLater = {
                                dismissedUpdateVersionCode = updateUi.manifest?.versionCode
                                pendingUpdateManifest = null
                                updateUi = UpdateUi()
                            },
                            onUpdateNow = {
                                val m = updateUi.manifest!!
                                updateUi = updateUi.copy(
                                    updating = true,
                                    progressBytes = 0L,
                                    progressTotal = -1L
                                )
                                scope.launch {
                                    try {
                                        val apk = withContext(Dispatchers.IO) {
                                            AppUpdater.downloadApk(this@MainActivity, m.apkUrl) { done, total ->
                                                updateUi = updateUi.copy(progressBytes = done, progressTotal = total)
                                            }
                                        }
                                        AppUpdater.installApk(this@MainActivity, apk)
                                    } catch (_: Throwable) {
                                        Toast.makeText(
                                            this@MainActivity,
                                            "Update failed",
                                            Toast.LENGTH_LONG
                                        ).show()
                                        updateUi = updateUi.copy(updating = false, progressBytes = 0L, progressTotal = -1L)
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }
    }

@Composable
private fun UpdateOverlay(
    currentVersionName: String,
    newVersionCode: Int,
    changelog: String?,
    updating: Boolean,
    progressBytes: Long,
    progressTotal: Long,
    onLater: () -> Unit,
    onUpdateNow: () -> Unit
) {
    val updateFocus = remember { FocusRequester() }
    val laterFocus = remember { FocusRequester() }
    val updateInteraction = remember { MutableInteractionSource() }
    val laterInteraction = remember { MutableInteractionSource() }
    // Start visually highlighted so the user immediately sees the default action.
    // (Focus is still requested below once the dialog is on screen.)
    var updateFocused by remember { mutableStateOf(true) }
    var laterFocused by remember { mutableStateOf(false) }

    val focusManager = LocalFocusManager.current

    Dialog(
        onDismissRequest = { if (!updating) onLater() },
        properties = DialogProperties(
            dismissOnBackPress = !updating,
            dismissOnClickOutside = false,
            usePlatformDefaultWidth = false
        )
    ) {

    // Request initial focus *after* the dialog content exists.
    LaunchedEffect(Unit) {
        // Some Android TV launchers steal focus during the first second after auto-login / nav.
        // We aggressively reclaim focus a few times so the default action stays highlighted.
        focusManager.clearFocus(force = true)
        delay(120)
        updateFocus.requestFocus()

        repeat(12) {
            delay(150)
            if (!updateFocused && !laterFocused) {
                updateFocused = true
                laterFocused = false
                updateFocus.requestFocus()
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xB0000000)),
        contentAlignment = Alignment.Center
    ) {
        Card(
            shape = androidx.compose.foundation.shape.RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0A0A0A)),
            modifier = Modifier
                .fillMaxWidth(0.78f)
                .border(1.dp, Color(0x22FFFFFF), androidx.compose.foundation.shape.RoundedCornerShape(22.dp))
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "Update available",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "Current: $currentVersionName   New: $newVersionCode",
                    color = Color(0xFFAAAAAA),
                    fontSize = 13.sp
                )

                if (!changelog.isNullOrBlank()) {
                    Spacer(Modifier.height(12.dp))
                    Text(
                        text = changelog.trim(),
                        color = Color(0xFFDDDDDD),
                        fontSize = 14.sp
                    )
                }

                Spacer(Modifier.height(18.dp))

                if (updating) {
                    val hasTotal = progressTotal > 0L

                    val p = if (hasTotal) {
                        (progressBytes.toFloat() / progressTotal.toFloat()).coerceIn(0f, 1f)
                    } else 0f

                    if (hasTotal) {
                        LinearProgressIndicator(
                            progress = p,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(50))
                        )
                    } else {
                        LinearProgressIndicator(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(50))
                        )
                    }

                    fun fmt(bytes: Long): String {
                        if (bytes <= 0L) return "0 MB"
                        val mb = bytes.toDouble() / (1024.0 * 1024.0)
                        return String.format("%.1f MB", mb)
                    }

                    val status = if (hasTotal) {
                        val pct = (p * 100f).toInt().coerceIn(0, 100)
                        "$pct%  ${fmt(progressBytes)} / ${fmt(progressTotal)}"
                    } else {
                        fmt(progressBytes)
                    }

                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = status,
                        color = Color(0xFFAAAAAA),
                        fontSize = 12.sp
                    )

                    Spacer(Modifier.height(10.dp))
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.focusGroup()
                ) {
                    Card(
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .focusRequester(updateFocus)
                            .focusProperties { right = laterFocus }
                            .focusable(enabled = true, interactionSource = updateInteraction)
                            .onFocusChanged { updateFocused = it.isFocused }
                            .clickable(
                                enabled = !updating,
                                interactionSource = updateInteraction,
                                indication = null
                            ) { onUpdateNow() }
                            .border(
                                width = if (updateFocused) 3.dp else 1.dp,
                                color = if (updateFocused) CyanGlow else Color(0x33FFFFFF),
                                shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp)
                            )
                            .scale(if (updateFocused) 1.04f else 1.0f),
                        colors = CardDefaults.cardColors(
                            containerColor = if (updateFocused) Color(0x26FFFFFF) else Color(0x14000000)
                        )
                    ) {
                        Text(
                            text = if (updating) "Downloading…" else "Update now",
                            color = if (updateFocused) CyanGlow else if (updating) Color(0xFFAAAAAA) else Color(0xFFDDDDDD),
                            modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp)
                        )
                    }

                    Card(
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .focusRequester(laterFocus)
                            .focusProperties { left = updateFocus }
                            .focusable(enabled = true, interactionSource = laterInteraction)
                            .onFocusChanged { laterFocused = it.isFocused }
                            .clickable(
                                enabled = !updating,
                                interactionSource = laterInteraction,
                                indication = null
                            ) { onLater() }
                            .border(
                                width = if (laterFocused) 3.dp else 1.dp,
                                color = if (laterFocused) CyanGlow else Color(0x33FFFFFF),
                                shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp)
                            )
                            .scale(if (laterFocused) 1.04f else 1.0f),
                        colors = CardDefaults.cardColors(
                            containerColor = if (laterFocused) Color(0x26FFFFFF) else Color(0x14000000)
                        )
                    ) {
                        Text(
                            text = "Later",
                            color = if (laterFocused) CyanGlow else if (updating) Color(0xFF666666) else Color(0xFFDDDDDD),
                            modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp)
                        )
                    }
                }
            }
        }
    }
    }
}

@Composable
private fun CrashReportScreen(text: String, onClearAndRestart: () -> Unit) {
    Surface(modifier = Modifier.fillMaxSize(), color = Color.Black) {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            Text(
                text = "App crashed last run. Tap CLEAR to restart.\n\n" + text,
                color = Color.White,
                modifier = Modifier.weight(1f).verticalScroll(rememberScrollState())
            )
            Spacer(modifier = Modifier.height(12.dp))
            TvPillButton(
                text = "CLEAR",
                onClick = onClearAndRestart,
                selected = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

    private suspend fun accountIsActive(baseUrl: String, u: String, p: String): Pair<Boolean, String?> {
        return try {
            val api = ApiClient.xtream(baseUrl)
            val resp = api.getAccountInfo(u, p)
            if (!resp.isSuccessful) {
                val c = resp.code()
                if (c == 401 || c == 403) return false to "Access ended"
            }

            val body = resp.body() ?: run {
                val r2 = api.getAccountInfoAction(u, p)
                if (!r2.isSuccessful) {
                    val c2 = r2.code()
                    if (c2 == 401 || c2 == 403) return false to "Access ended"
                }
                r2.body()
            }
            val info = body?.user_info

            fun s(v: Any?): String? = (v as? String)?.trim()
            fun l(v: Any?): Long? = when (v) {
                is Number -> v.toLong()
                is String -> v.trim().toLongOrNull()
                else -> null
            }
            fun b(v: Any?): Boolean? = when (v) {
                is Boolean -> v
                is Number -> v.toInt() != 0
                is String -> {
                    val t = v.trim().lowercase()
                    t == "1" || t == "true" || t == "yes"
                }
                else -> null
            }

            if (info == null) return true to null

            val auth = b(info["auth"]) ?: b(info["authenticated"]) ?: b(info["is_authenticated"])
            val status = s(info["status"])?.lowercase()?.trim()
            val banned = b(info["is_banned"]) ?: b(info["banned"]) ?: b(info["ban"]) ?: false
            val expSec = l(info["exp_date"]) ?: l(info["exp"])
            val nowSec = System.currentTimeMillis() / 1000L

            if (auth == false) return false to "Account not active"
            if (banned) return false to "Account banned"
            if (status != null && status.isNotBlank() && status != "active") {
                if (status.contains("ban")) return false to "Account banned"
                if (status.contains("exp")) return false to "Subscription expired"
                return false to "Account not active"
            }
            if (expSec != null && expSec > 0 && nowSec >= expSec) return false to "Subscription expired"

            true to null
        } catch (_: Throwable) {
            // Fallback: some panels return non-JSON/HTML when expired/banned.
            // Don't show endpoints; just decide whether access ended.
            try {
                val api = ApiClient.xtream(baseUrl)
                val r = api.getPlaylist(u, p)
                val code = r.code()
                if (code == 401 || code == 403) return false to "Access ended"

                val text = runCatching { r.body()?.string().orEmpty() }.getOrDefault("")
                if (r.isSuccessful && text.startsWith("#EXTM3U")) return true to null

                if (r.isSuccessful) {
                    val lower = text.lowercase()
                    if (lower.contains("ban")) return false to "Account banned"
                    if (lower.contains("exp")) return false to "Subscription expired"
                    return false to "Access ended"
                }

                if (code in 400..499) return false to "Access ended"

                // Otherwise (timeouts/5xx), do not hard-kick.
                true to null
            } catch (_: Throwable) {
                // Never hard-kick on a transient network error.
                true to null
            }
        }
    }

}