package com.gamechanger.iptv.api

import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

interface XtreamApiService {

    
// Xtream Codes JSON API (player_api.php)
@GET("player_api.php")
suspend fun getLiveCategories(
    @Query("username") u: String,
    @Query("password") p: String,
    @Query("action") action: String = "get_live_categories"
): Response<List<XtreamLiveCategoryDto>>

@GET("player_api.php")
suspend fun getLiveStreams(
    @Query("username") u: String,
    @Query("password") p: String,
    @Query("action") action: String = "get_live_streams",
    @Query("category_id") categoryId: String? = null
): Response<List<XtreamLiveStreamDto>>

// Account / auth status (no action param)
@GET("player_api.php")
suspend fun getAccountInfo(
    @Query("username") u: String,
    @Query("password") p: String
): Response<AccountResponse>

// Some panels require explicit action
@GET("player_api.php")
suspend fun getAccountInfoAction(
    @Query("username") u: String,
    @Query("password") p: String,
    @Query("action") action: String = "get_account_info"
): Response<AccountResponse>

// get.php returns playlist text (M3U), not JSON.
    @GET("get.php")
    suspend fun getPlaylist(
        @Query("username") u: String,
        @Query("password") p: String,
        @Query("type") type: String = "m3u_plus",
        @Query("output") output: String = "ts"
    ): Response<ResponseBody>
}
