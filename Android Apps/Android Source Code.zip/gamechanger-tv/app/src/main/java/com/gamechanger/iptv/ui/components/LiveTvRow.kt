package com.gamechanger.iptv.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gamechanger.iptv.ui.model.Channel
import com.gamechanger.iptv.ui.theme.GameChangerCyan

@Composable
fun LiveTvRow(
    channels: List<Channel>,
    modifier: Modifier = Modifier
) {
    if (channels.isEmpty()) return

    Text(
        text = "LIVE TV",
        fontSize = 22.sp,
        fontWeight = FontWeight.ExtraBold,
        color = GameChangerCyan,
        letterSpacing = 2.sp,
        modifier = modifier
            .fillMaxWidth()
            .padding(start = 24.dp, top = 18.dp, bottom = 6.dp)
    )

    Spacer(modifier = Modifier.height(4.dp))

    LazyRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(start = 12.dp, end = 24.dp)
    ) {
        items(channels) { ch ->
            MockupChannelCard(channel = ch)
        }
    }
}
