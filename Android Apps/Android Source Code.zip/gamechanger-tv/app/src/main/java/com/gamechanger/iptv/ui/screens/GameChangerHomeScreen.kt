package com.gamechanger.iptv.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.Image
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import com.gamechanger.iptv.ui.components.TvPillButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.draw.scale
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gamechanger.iptv.ui.theme.GameChangerCyan
import com.gamechanger.iptv.ui.theme.PureBlack

@Composable
fun GameChangerHomeScreen(
    modifier: Modifier = Modifier,
    initialUsername: String = "",
    initialPassword: String = "",
    onLogin: (serverUrl: String, username: String, password: String) -> Unit = { _, _, _ -> }
) {
    // Hidden/locked server URL (NOT shown on screen)
    val serverUrl = "http://who.what.who"

    var username by remember(initialUsername) { mutableStateOf(initialUsername) }
    var password by remember(initialPassword) { mutableStateOf(initialPassword) }

    Box(
        modifier = modifier
            .fillMaxSize()
    ) {
        // Techy login backdrop
        Image(
            painter = painterResource(id = com.gamechanger.iptv.R.drawable.login_bg),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        // Readability scrim (keeps your cyan UI readable on bright areas)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Black.copy(alpha = 0.70f),
                            Color.Black.copy(alpha = 0.35f),
                            Color.Black.copy(alpha = 0.75f)
                        )
                    )
                )
        )

        // Background is intentionally clean; the real login card is drawn by Compose below.
        // 
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 32.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ) {
            // Spacing before the real input card.
            Spacer(modifier = Modifier.height(190.dp))
            val cardShape = RoundedCornerShape(22.dp)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 720.dp)
                    .background(Color(0xFF070A0C), cardShape)
                    .border(1.dp, GameChangerCyan.copy(alpha = 0.22f), cardShape)
                    .padding(20.dp)
            ) {
                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it },
                    label = { Text("Username", color = GameChangerCyan) },
                    colors = TextFieldDefaults.colors(
                        focusedIndicatorColor = GameChangerCyan,
                        unfocusedIndicatorColor = GameChangerCyan.copy(alpha = 0.3f),
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(64.dp),
                    textStyle = TextStyle(color = Color.White),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next)
                )

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Password", color = GameChangerCyan) },
                    colors = TextFieldDefaults.colors(
                        focusedIndicatorColor = GameChangerCyan,
                        unfocusedIndicatorColor = GameChangerCyan.copy(alpha = 0.3f),
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(64.dp),
                    textStyle = TextStyle(color = Color.White),
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = {
                        if (username.isNotBlank() && password.isNotBlank()) {
                            onLogin(serverUrl, username, password)
                        }
                    })
                )

                Spacer(modifier = Modifier.height(20.dp))

            TvPillButton(
                text = "SUBMIT",
                onClick = { onLogin(serverUrl, username, password) },
                enabled = username.isNotBlank() && password.isNotBlank(),
                selected = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
            )

            }

            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}
