package com.gamechanger.iptv.ui.components

import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.size
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.pointer.pointerInput
import android.view.KeyEvent as AndroidKeyEvent
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import com.gamechanger.iptv.api.EpgXmltv
import com.gamechanger.iptv.util.EpgDbHelper
import com.gamechanger.iptv.util.TimeSync
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.produceState
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.gamechanger.iptv.ui.model.Channel
import com.gamechanger.iptv.ui.model.Movie
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.util.MimeTypes
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.PlaybackException
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.source.ProgressiveMediaSource
import com.google.android.exoplayer2.source.UnrecognizedInputFormatException
import com.google.android.exoplayer2.source.hls.HlsMediaSource
import com.google.android.exoplayer2.upstream.DefaultHttpDataSource
import com.google.android.exoplayer2.upstream.HttpDataSource
import com.google.android.exoplayer2.ui.PlayerView
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.gamechanger.iptv.api.ApiClient
import com.gamechanger.iptv.api.Keys
import com.gamechanger.iptv.api.TmdbImages
import com.gamechanger.iptv.api.TmdbMovieResult
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope

@Composable
fun CinematicPlayerOverlay(
    channel: Channel,
    isLive: Boolean = false,
    onClose: () -> Unit,
    liveAllChannels: List<Channel> = emptyList(),
    liveCategories: List<com.gamechanger.iptv.ui.model.LiveCategory> = emptyList(),
    liveCategoryId: String = "",
    onSelectCategory: (String) -> Unit = {},
    onTuneChannel: (Channel) -> Unit = {},
    onTunePreviousChannel: () -> Unit = {},
    onOpenMovie: (Movie) -> Unit = {}
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val focusManager = LocalFocusManager.current
    val rootFocusRequester = remember { FocusRequester() }
    val rootFocusScope = rememberCoroutineScope()
    val deviceId = remember {
        runCatching { Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) }.getOrNull().orEmpty()
    }

    // Player priority:
// - Live TV: start on Exo (VLC fallback)
// - VOD: start on VLC (Exo fallback)
    var useVlc by remember(channel.streamUrl, isLive) { mutableStateOf(!isLive) }
    var exoReady by remember(channel.streamUrl) { mutableStateOf(false) }
    var vlcReady by remember(channel.streamUrl) { mutableStateOf(false) }
    var errorMessage by remember(channel.streamUrl) { mutableStateOf<String?>(null) }

    val candidates = remember(channel.streamUrl) { buildStreamCandidates(channel.streamUrl) }

    var exoForceHls by remember(channel.streamUrl) { mutableStateOf(false) }

    // Prefer .ts for Live (Xtream), and avoid giving VLC .m3u8 (VLC adaptive demux can SIGABRT on some devices/emulators).
// Start with the original URL first. Some panels serve live streams on extensionless /live/.../id
// and will 404 if we force ".ts" up front.
var exoUrl by remember(channel.streamUrl) {
    mutableStateOf(candidates.firstOrNull() ?: channel.streamUrl)
}
var vlcUrl by remember(channel.streamUrl, isLive) {
        mutableStateOf(
            candidates.firstOrNull { !it.lowercase().contains(".m3u8") } ?: candidates.first()
        )
    }

    // Keep URLs in sync when switching players.
    LaunchedEffect(useVlc) {
        if (useVlc) {
            vlcUrl = pickVlcSafeUrl(candidates, exoUrl)
        } else {
            exoUrl = pickExoPreferredUrl(candidates, vlcUrl, isLive)
        }
    }

    var exoRestartToken by remember(channel.streamUrl) { mutableStateOf(0) }
    var exoRestartAttempts by remember(channel.streamUrl) { mutableStateOf(0) }

    // Watchdogs: some streams "stall" without emitting end/error; we auto-kick a restart if time/position stops moving.
    var exoLastPos by remember(channel.streamUrl) { mutableStateOf(-1L) }
    var exoStallCount by remember(channel.streamUrl) { mutableStateOf(0) }


    val exoPlayer = remember(exoUrl, useVlc) {
        if (!useVlc) {
            val httpFactory = DefaultHttpDataSource.Factory()
                    .setAllowCrossProtocolRedirects(true)
                    .setConnectTimeoutMs(12_000)
                    .setReadTimeoutMs(12_000)
                .setUserAgent("GameChanger")
                .setDefaultRequestProperties(mapOf("X-Device-ID" to deviceId))
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(15_000)
                .setReadTimeoutMs(15_000)

            ExoPlayer.Builder(context).build().apply {
                val lower = exoUrl.lowercase()
                val item = MediaItem.Builder()
                    .setUri(Uri.parse(exoUrl))
                    .apply {
                        if (lower.contains(".m3u8")) setMimeType(MimeTypes.APPLICATION_M3U8)
                    }
                    .build()

                // Force the correct MediaSource type.
                // Some m3u8 URLs were being treated as progressive which triggers
                // UnrecognizedInputFormatException (extractors list).
                val isHls = exoForceHls || lower.contains("m3u8") || lower.contains("hls")
                val mediaSource = if (isHls) {
                    HlsMediaSource.Factory(httpFactory).createMediaSource(item)
                } else {
                    ProgressiveMediaSource.Factory(httpFactory).createMediaSource(item)
                }

                setMediaSource(mediaSource)
                prepare()
                playWhenReady = true
            }
        } else null
    }

    DisposableEffect(exoPlayer) {
        val p = exoPlayer
        onDispose { p?.release() }
    }

    // Exo "start" timeout -> try alternate URL, then switch back to VLC.
    LaunchedEffect(exoUrl, useVlc, channel.streamUrl) {
        if (!useVlc) {
            exoReady = false
            errorMessage = null
            delay(12_000)
            if (!exoReady && !useVlc) {
                val next = nextCandidate(candidates, exoUrl)
                if (next != null) {
                    exoUrl = next
                } else {
                    useVlc = true
                }
            }
        }
    }

    // VLC "start" timeout -> switch to Exo (fallback).
    // TS often starts fast on Exo; if VLC doesn't come up quickly for TS, don't make the user wait.
    LaunchedEffect(vlcUrl, useVlc, channel.streamUrl) {
        if (useVlc) {
            vlcReady = false
            errorMessage = null

            val lower = vlcUrl.lowercase()
            val isTs = (lower.contains(".ts") && !lower.contains(".m3u8"))
            delay(if (isTs) 2_500 else 12_000)

            if (!vlcReady && useVlc) {
                useVlc = false
            }
        }
    }

    // Exo events: auto-restart on stop/end, and try ts<->m3u8 before falling back to VLC.
    DisposableEffect(exoPlayer, exoUrl, useVlc) {
        val p = exoPlayer
        if (p == null) return@DisposableEffect onDispose { }
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                when (state) {
                    Player.STATE_READY -> {
                        exoReady = true
                        exoRestartAttempts = 0
                    }
                    Player.STATE_IDLE -> {
                        // Sometimes a live stream drops back to IDLE without a clean error.
                        if (exoReady) {
                            exoRestartAttempts = (exoRestartAttempts + 1).coerceAtMost(8)
                            exoRestartToken += 1
                        }
                    }
                    Player.STATE_ENDED -> {
                        // Live streams sometimes "end"; auto-restart.
                        exoRestartAttempts = (exoRestartAttempts + 1).coerceAtMost(8)
                        exoRestartToken += 1
                    }
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                if (useVlc) return

                // If Exo tried progressive and couldn't detect format, retry as HLS once.
                val cause = error.cause
                val http = findInvalidResponseCode(cause)
                if (http != null) {
                    // 404/403/etc: try the next candidate URL instead of looping the same one.
                    val nextHttp = nextCandidate(candidates, exoUrl)
                    if (nextHttp != null) {
                        exoUrl = nextHttp
                        exoRestartToken += 1
                        return
                    }

                    // If we're already on the last candidate, bounce back to the original once
                    // (prevents getting stuck on a bad synthetic swap like ".ts").
                    val first = candidates.firstOrNull()
                    if (first != null && first != exoUrl) {
                        exoUrl = first
                        exoRestartToken += 1
                        return
                    }
                }

                if (cause is UnrecognizedInputFormatException && !exoForceHls) {
                    // Retry the SAME URL as HLS first. Some panels serve m3u8 on an extensionless /live/.../id.
                    exoForceHls = true
                    exoRestartToken += 1
                    return
                }

                // First: try alternate extension (ts <-> m3u8).
                val next = nextCandidate(candidates, exoUrl)
                if (next != null) {
                    exoUrl = next
                    exoRestartToken += 1
                    return
                }

                // Then: quick restart a couple times.
                if (exoRestartAttempts < 2) {
                    exoRestartAttempts += 1
                    exoRestartToken += 1
                    return
                }

                // Finally: VLC.
                useVlc = true
            }
        }
        p.addListener(listener)
        onDispose { p.removeListener(listener) }
    }

    
    // Exo watchdog: if playback is supposed to be running but position stops advancing, trigger a restart.
    LaunchedEffect(exoPlayer, useVlc, exoUrl, exoReady) {
        if (useVlc) return@LaunchedEffect
        val p = exoPlayer ?: return@LaunchedEffect
        // reset on URL change / re-enter
        exoLastPos = -1L
        exoStallCount = 0
        while (true) {
            delay(5000)
            if (useVlc) break
            if (!exoReady) continue
            // if we're not actively trying to play, don't treat it as a stall
            if (!p.playWhenReady) continue
            if (p.playbackState != Player.STATE_READY) continue
            val posMs = runCatching { p.currentPosition }.getOrDefault(-1L)
            if (posMs >= 0 && posMs == exoLastPos) {
                exoStallCount += 1
                if (exoStallCount >= 3) { // ~15s
                    exoRestartAttempts = (exoRestartAttempts + 1).coerceAtMost(8)
                    exoRestartToken += 1
                    exoStallCount = 0
                }
            } else {
                exoLastPos = posMs
                exoStallCount = 0
            }
        }
    }

// Exo restart worker.
    LaunchedEffect(exoRestartToken, exoPlayer, useVlc, exoUrl) {
        if (useVlc) return@LaunchedEffect
        val p = exoPlayer ?: return@LaunchedEffect
        if (exoRestartToken <= 0) return@LaunchedEffect
        delay(backoffMs(exoRestartAttempts))
        try {
            exoReady = false
            p.stop()
            p.clearMediaItems()
            val httpFactory = DefaultHttpDataSource.Factory()
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(12_000)
                .setReadTimeoutMs(12_000)
                .setUserAgent("GameChanger")
                .setDefaultRequestProperties(mapOf("X-Device-ID" to deviceId))

            val lower = exoUrl.lowercase()
            val isHls = exoForceHls || lower.contains("m3u8") || lower.contains("hls") || lower.contains("type=m3u8")

            val item = MediaItem.Builder()
                .setUri(Uri.parse(exoUrl))
                .apply { if (isHls) setMimeType(MimeTypes.APPLICATION_M3U8) }
                .build()

            val mediaSource = if (isHls) {
                HlsMediaSource.Factory(httpFactory).createMediaSource(item)
            } else {
                ProgressiveMediaSource.Factory(httpFactory).createMediaSource(item)
            }

            p.setMediaSource(mediaSource)
            p.prepare()
            p.playWhenReady = true
        } catch (_: Throwable) {
        }
    }

    // VLC state (created only when needed)
    val vlcBundle = remember(channel.streamUrl, useVlc) {
        if (!useVlc) null else {
            val opts = arrayListOf(
                "--network-caching=1500",
                "--live-caching=1500",
                "--file-caching=1500",
                "--http-reconnect",
                "--no-drop-late-frames",
                "--no-skip-frames",
                "--clock-jitter=0",
                "--clock-synchro=0"
            )
            val lib = LibVLC(context, opts)
            val mp = MediaPlayer(lib)
            lib to mp
        }
    }
    val libVlc = vlcBundle?.first
    val vlcPlayer = vlcBundle?.second

    var vlcLayout by remember(channel.streamUrl) { mutableStateOf<VLCVideoLayout?>(null) }
    var vlcAttached by remember(channel.streamUrl) { mutableStateOf(false) }
    var vlcPlaying by remember(channel.streamUrl) { mutableStateOf(false) }

    var vlcLastTime by remember(channel.streamUrl) { mutableStateOf(-1L) }
    var vlcStallCount by remember(channel.streamUrl) { mutableStateOf(0) }


    var vlcRestartToken by remember(channel.streamUrl) { mutableStateOf(0) }
    var vlcRestartAttempts by remember(channel.streamUrl) { mutableStateOf(0) }
    var vlcInternalRestart by remember(channel.streamUrl) { mutableStateOf(false) }

    DisposableEffect(lifecycleOwner, exoPlayer, vlcPlayer) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) {
                try { exoPlayer?.playWhenReady = false } catch (_: Throwable) {}
                try { exoPlayer?.stop() } catch (_: Throwable) {}
                try { vlcPlayer?.pause() } catch (_: Throwable) {}
                try { vlcPlayer?.stop() } catch (_: Throwable) {}
                onClose()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Attach VLC views once the AndroidView exists
    LaunchedEffect(useVlc, vlcPlayer, vlcLayout) {
        val layout = vlcLayout
        val player = vlcPlayer
        if (useVlc && player != null && layout != null && !vlcAttached) {
            try {
                player.attachViews(layout, null, false, false)
                vlcAttached = true
            } catch (_: Throwable) {
            }
        }
    }

    // VLC lifecycle (listener + cleanup)
    DisposableEffect(useVlc, vlcPlayer) {
        if (!useVlc || vlcPlayer == null) return@DisposableEffect onDispose { }

        val listener = MediaPlayer.EventListener { ev ->
            when (ev.type) {
                MediaPlayer.Event.Playing -> {
                    vlcPlaying = true
                    vlcReady = true
                    vlcRestartAttempts = 0
                    errorMessage = null
                }
                MediaPlayer.Event.Paused -> vlcPlaying = false
                MediaPlayer.Event.Stopped -> {
                    vlcPlaying = false
                    if (!vlcInternalRestart) {
                        val a = (vlcRestartAttempts + 1).coerceAtMost(10)
                        vlcRestartAttempts = a
                        vlcRestartToken += 1
                        if (a >= 3) useVlc = false
                    }
                }
                MediaPlayer.Event.EndReached -> {
                    vlcPlaying = false
                    if (!vlcInternalRestart) {
                        val a = (vlcRestartAttempts + 1).coerceAtMost(10)
                        vlcRestartAttempts = a
                        vlcRestartToken += 1
                        if (a >= 3) useVlc = false
                    }
                }
                MediaPlayer.Event.EncounteredError -> {
                    vlcPlaying = false
                    if (!vlcInternalRestart) {
                        // Try alternate URL once (ts <-> m3u8) before looping retries.
                        val next = nextCandidateVlcSafe(candidates, vlcUrl)
                        if (next != null) vlcUrl = next
                        val a = (vlcRestartAttempts + 1).coerceAtMost(10)
                        vlcRestartAttempts = a
                        vlcRestartToken += 1
                        if (a >= 2) useVlc = false
                    }
                }
            }
        }
        vlcPlayer.setEventListener(listener)

        onDispose {
            try { vlcPlayer.setEventListener(null) } catch (_: Throwable) {}
            try { vlcPlayer.stop() } catch (_: Throwable) {}
            try { vlcPlayer.detachViews() } catch (_: Throwable) {}
            try { vlcPlayer.release() } catch (_: Throwable) {}
            try { libVlc?.release() } catch (_: Throwable) {}
        }
    }

    // Kick initial VLC start when we first enter VLC mode.
    LaunchedEffect(useVlc, vlcAttached, vlcPlayer) {
        if (useVlc && vlcAttached && vlcPlayer != null) {
            vlcRestartToken += 1
        }
    }

    
    // VLC watchdog: if VLC is "playing" but time stops advancing for a while, restart.
    LaunchedEffect(useVlc, vlcPlayer, vlcAttached, vlcUrl) {
        if (!useVlc) return@LaunchedEffect
        val player = vlcPlayer ?: return@LaunchedEffect
        if (!vlcAttached) return@LaunchedEffect
        vlcLastTime = -1L
        vlcStallCount = 0
        while (true) {
            delay(5000)
            if (!useVlc) break
            if (!vlcAttached) continue
            if (!vlcPlaying) continue
            val t = runCatching { player.time }.getOrDefault(-1L)
            if (t >= 0 && t == vlcLastTime) {
                vlcStallCount += 1
                if (vlcStallCount >= 3) { // ~15s
                    vlcRestartAttempts = (vlcRestartAttempts + 1).coerceAtMost(10)
                    vlcRestartToken += 1
                    vlcStallCount = 0
                }
            } else {
                vlcLastTime = t
                vlcStallCount = 0
            }
        }
    }

// VLC restart worker (auto-restart when stream stops)
    LaunchedEffect(vlcRestartToken, useVlc, vlcPlayer, libVlc, vlcAttached, vlcUrl) {
        if (!useVlc) return@LaunchedEffect
        val player = vlcPlayer ?: return@LaunchedEffect
        val lib = libVlc ?: return@LaunchedEffect
        if (!vlcAttached) return@LaunchedEffect
        if (vlcRestartToken <= 0) return@LaunchedEffect

        delay(backoffMs(vlcRestartAttempts))

        vlcInternalRestart = true
        try {
            runCatching { player.stop() }
            val media = Media(lib, Uri.parse(vlcUrl))
            applyVlcMediaOptions(media, vlcUrl)
            player.media = media
            media.release()
            player.play()
        } catch (_: Throwable) {
            // keep silent on-screen
        } finally {
            vlcInternalRestart = false
        }
    }

    var showControls by remember { mutableStateOf(!isLive) }
    var positionMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(0L) }

    // Live info overlay (channel/logo/EPG) - auto-hides
    var liveInfoVisible by remember(channel.streamUrl, isLive) { mutableStateOf(isLive) }
    var liveInfoToken by remember(channel.streamUrl, isLive) { mutableStateOf(0) }
    var liveNowNext by remember(channel.streamId) { mutableStateOf<com.gamechanger.iptv.api.EpgNowNext?>(null) }

    var liveSearchVisible by remember(channel.streamUrl, isLive) { mutableStateOf(false) }
    var liveSearchQuery by remember(channel.streamUrl, isLive) { mutableStateOf("") }
    val liveSearchFieldRequester = remember { FocusRequester() }
    var liveSearchFocusToken by remember(channel.streamUrl, isLive) { mutableStateOf(0) }
    var liveSearchInteractionToken by remember(channel.streamUrl, isLive) { mutableStateOf(0) }

    var drawerMode by remember(channel.streamUrl) { mutableStateOf(0) } // 0 none, 1 guide, 2 categories, 3 channels

    val liveSearchUi by produceState(
        initialValue = LiveSearchUi(),
        key1 = isLive,
        key2 = liveSearchVisible,
        key3 = liveSearchQuery
    ) {
        if (!isLive || !liveSearchVisible) {
            value = LiveSearchUi()
            return@produceState
        }

        val q = liveSearchQuery.trim()
        if (q.length < 2) {
            value = LiveSearchUi()
            return@produceState
        }

        value = LiveSearchUi(loading = true, items = emptyList())
        delay(300)

        value = try {
            val api = ApiClient.tmdb()
            val items = withContext(Dispatchers.IO) {
                coroutineScope {
                    val movieDeferred = async { api.searchMovie(Keys.TMDB_API_KEY, q, page = 1).results }
                    val seriesDeferred = async { api.searchSeries(Keys.TMDB_API_KEY, q, page = 1).results }
                    (movieDeferred.await() + seriesDeferred.await())
                        .map { it.toOverlayMovie() }
                        .filter { it.id > 0 && it.title.isNotBlank() }
                        .distinctBy { "${it.mediaType}_${it.id}" }
                        .sortedByDescending { it.rating }
                        .take(24)
                }
            }
            LiveSearchUi(loading = false, items = items)
        } catch (_: Throwable) {
            LiveSearchUi(loading = false, items = emptyList())
        }
    }

    // Tick so EPG "Now" can flip to "Next" when the clock passes the stop time.
    var nowTickMs by remember(isLive) { mutableLongStateOf(TimeSync.nowMs()) }
    LaunchedEffect(isLive) {
        if (!isLive) return@LaunchedEffect
        while (true) {
            nowTickMs = TimeSync.nowMs()
            kotlinx.coroutines.delay(5_000)
        }
    }

    val liveNowNextDisplay = remember(liveNowNext, nowTickMs) { normalizeNowNext(liveNowNext, nowTickMs) }


    fun showLiveInfoOverlay() {
        if (!isLive) return
        liveInfoVisible = true
        liveInfoToken += 1
    }

    fun touchLiveSearchOverlay() {
        if (!isLive || !liveSearchVisible) return
        liveSearchInteractionToken += 1
    }

    fun focusRootSafely() {
        rootFocusScope.launch {
            runCatching { focusManager.clearFocus(force = true) }
            withFrameNanos { }
            runCatching { rootFocusRequester.requestFocus() }
        }
    }

    fun openLiveSearchOverlay() {
        if (!isLive) return
        drawerMode = 0
        focusRootSafely()
        showLiveInfoOverlay()
        liveSearchVisible = true
        liveSearchFocusToken += 1
        liveSearchInteractionToken += 1
    }

    fun closeLiveSearchOverlay() {
        liveSearchVisible = false
        focusRootSafely()
    }

    fun stopPlaybackNow() {
        try { exoPlayer?.playWhenReady = false } catch (_: Throwable) {}
        try { exoPlayer?.stop() } catch (_: Throwable) {}
        try { vlcPlayer?.pause() } catch (_: Throwable) {}
        try { vlcPlayer?.stop() } catch (_: Throwable) {}
    }

    LaunchedEffect(liveSearchFocusToken, liveSearchVisible, isLive, liveSearchUi.items.size, liveSearchQuery) {
        if (!isLive || !liveSearchVisible) return@LaunchedEffect
        if (liveSearchQuery.trim().length >= 2 && liveSearchUi.items.isNotEmpty()) return@LaunchedEffect
        withFrameNanos { }
        runCatching { liveSearchFieldRequester.requestFocus() }
    }

    LaunchedEffect(liveSearchVisible, liveSearchInteractionToken, isLive) {
        if (!isLive || !liveSearchVisible) return@LaunchedEffect
        delay(5000)
        liveSearchVisible = false
        focusRootSafely()
    }

    LaunchedEffect(drawerMode, liveSearchVisible, isLive) {
        if (!isLive) return@LaunchedEffect
        if (drawerMode == 0 && !liveSearchVisible) {
            withFrameNanos { }
            runCatching { focusManager.clearFocus(force = true) }
            runCatching { rootFocusRequester.requestFocus() }
        }
    }

    suspend fun loadLiveNowNext() {
        if (!isLive) return
        val sid = channel.streamId
        if (sid.isBlank()) {
            liveNowNext = null
            return
        }
        val db = EpgDbHelper(context)
        val (_, map) = withContext(Dispatchers.IO) { db.readNowNext(listOf(sid)) }
        liveNowNext = map[sid]
    }

    LaunchedEffect(channel.streamId, isLive) {
        if (!isLive) return@LaunchedEffect
        while (true) {
            loadLiveNowNext()
            delay(60_000)
        }
    }

    LaunchedEffect(channel.streamUrl, isLive) {
        if (isLive) showLiveInfoOverlay()
    }

    LaunchedEffect(liveInfoToken, isLive) {
        if (!isLive) return@LaunchedEffect
        if (liveInfoToken <= 0) return@LaunchedEffect
        delay(3500)
        liveInfoVisible = false
    }


    LaunchedEffect(exoPlayer, vlcPlayer, useVlc) {
        while (true) {
            if (!useVlc && exoPlayer != null) {
                positionMs = exoPlayer.currentPosition
                durationMs = exoPlayer.duration.coerceAtLeast(0L)
            } else if (useVlc && vlcPlayer != null) {
                positionMs = vlcPlayer.time.coerceAtLeast(0L)
                durationMs = vlcPlayer.length.coerceAtLeast(0L)
            } else {
                positionMs = 0L
                durationMs = 0L
            }
            delay(250)
        }
    }

    val drawerEnabled = liveAllChannels.isNotEmpty()

    // Channels for the category we are currently in
    val categoryChannels = remember(liveAllChannels, liveCategoryId) {
        if (liveAllChannels.isEmpty()) emptyList()
        else if (liveCategoryId.isBlank()) liveAllChannels
        else liveAllChannels.filter { it.categoryId == liveCategoryId }
    }

    // Live channel up/down tuning (while video is playing).
    fun tuneRelative(delta: Int) {
        if (!isLive) return
        val list = if (categoryChannels.isNotEmpty()) categoryChannels else liveAllChannels
        if (list.isEmpty()) return

        // Close drawer/search pane on channel change.
        if (drawerMode != 0) drawerMode = 0
        closeLiveSearchOverlay()
        focusRootSafely()

        val curIdx = run {
            val sid = channel.streamId
            if (sid.isNotBlank()) {
                val i = list.indexOfFirst { it.streamId == sid }
                if (i >= 0) return@run i
            }
            val u = channel.streamUrl
            if (u.isNotBlank()) {
                val i = list.indexOfFirst { it.streamUrl == u }
                if (i >= 0) return@run i
            }
            val n = channel.name
            val i = list.indexOfFirst { it.name == n }
            if (i >= 0) return@run i
            0
        }

        val newIdx = (curIdx + delta).coerceIn(0, list.lastIndex)
        if (newIdx != curIdx) {
            onTuneChannel(list[newIdx])
        }
        showLiveInfoOverlay()
    }

    val timeFmt = remember { SimpleDateFormat("h:mm a", Locale.US) }
    var drawerNowNext by remember(liveCategoryId) { mutableStateOf<Map<String, com.gamechanger.iptv.api.EpgNowNext>>(emptyMap()) }
    var drawerEpgLoading by remember { mutableStateOf(false) }

    // Load cached EPG for the current category when the drawer is open
    LaunchedEffect(drawerEnabled, drawerMode, liveCategoryId) {
        if (!drawerEnabled) return@LaunchedEffect
        if (drawerMode == 0) return@LaunchedEffect
        val ids = categoryChannels.mapNotNull { it.streamId.takeIf { s -> s.isNotBlank() } }
        if (ids.isEmpty()) {
            drawerNowNext = emptyMap()
            return@LaunchedEffect
        }
        val db = EpgDbHelper(context)
        val (_, map) = withContext(Dispatchers.IO) { db.readNowNext(ids) }
        drawerNowNext = map
    }

    // Hardcoded EPG URLs (primary + fallback).
    val drawerEpgUrls = remember {
        listOf(
            "who.what.who",
            "who.what.who"
        )
    }

    fun cycleDrawer() {
        if (!drawerEnabled) return
        closeLiveSearchOverlay()
        drawerMode = when (drawerMode) {
            0 -> 1
            1 -> 2
            2 -> 3
            else -> 0
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .focusRequester(rootFocusRequester)
            .focusable()
            .onPreviewKeyEvent { e: androidx.compose.ui.input.key.KeyEvent ->
                val ne = e.nativeKeyEvent
                if (ne.action != AndroidKeyEvent.ACTION_DOWN) return@onPreviewKeyEvent false

                // Live TV: only hijack remote channel keys when the search overlay is closed.
                if (isLive && drawerMode == 0 && !liveSearchVisible) {
                    when (ne.keyCode) {
                        AndroidKeyEvent.KEYCODE_DPAD_UP,
                        AndroidKeyEvent.KEYCODE_CHANNEL_UP -> {
                            tuneRelative(-1)
                            return@onPreviewKeyEvent true
                        }
                        AndroidKeyEvent.KEYCODE_DPAD_DOWN,
                        AndroidKeyEvent.KEYCODE_CHANNEL_DOWN -> {
                            tuneRelative(1)
                            return@onPreviewKeyEvent true
                        }
                        AndroidKeyEvent.KEYCODE_DPAD_CENTER,
                        AndroidKeyEvent.KEYCODE_ENTER -> {
                            openLiveSearchOverlay()
                            return@onPreviewKeyEvent true
                        }
                        AndroidKeyEvent.KEYCODE_DPAD_RIGHT -> {
                            onTunePreviousChannel()
                            return@onPreviewKeyEvent true
                        }
                    }
                } else if (isLive && drawerMode == 0 && liveSearchVisible) {
                    when (ne.keyCode) {
                        AndroidKeyEvent.KEYCODE_BACK -> {
                            closeLiveSearchOverlay()
                            return@onPreviewKeyEvent true
                        }
                        AndroidKeyEvent.KEYCODE_DPAD_LEFT,
                        AndroidKeyEvent.KEYCODE_DPAD_RIGHT,
                        AndroidKeyEvent.KEYCODE_DPAD_UP,
                        AndroidKeyEvent.KEYCODE_DPAD_DOWN,
                        AndroidKeyEvent.KEYCODE_DPAD_CENTER,
                        AndroidKeyEvent.KEYCODE_ENTER -> {
                            touchLiveSearchOverlay()
                            return@onPreviewKeyEvent false
                        }
                    }
                }

                if (!drawerEnabled) return@onPreviewKeyEvent false
                when (ne.keyCode) {
                    AndroidKeyEvent.KEYCODE_DPAD_LEFT -> {
                        cycleDrawer()
                        true
                    }
                    AndroidKeyEvent.KEYCODE_DPAD_RIGHT -> {
                        if (drawerMode != 0) {
                            drawerMode = 0
                            focusRootSafely()
                            true
                        } else false
                    }
                    else -> false
                }
            }
            .pointerInput(drawerEnabled, drawerMode, isLive, liveSearchVisible) {
                if (!drawerEnabled) return@pointerInput
                var total = 0f
                detectHorizontalDragGestures(
                    onHorizontalDrag = { _, dragAmount -> total += dragAmount },
                    onDragEnd = {
                        when {
                            liveSearchVisible && total > 80f -> closeLiveSearchOverlay()
                            !liveSearchVisible && total < -80f -> cycleDrawer()
                            isLive && drawerMode == 0 && !liveSearchVisible && total > 80f -> onTunePreviousChannel()
                        }
                        total = 0f
                    },
                    onDragCancel = { total = 0f }
                )
            }
            .pointerInput(isLive, drawerMode, liveSearchVisible, channel.streamUrl, liveCategoryId) {
                if (!isLive) return@pointerInput
                if (drawerMode != 0) return@pointerInput
                if (liveSearchVisible) return@pointerInput
                var totalY = 0f
                detectVerticalDragGestures(
                    onVerticalDrag = { _, dragAmount -> totalY += dragAmount },
                    onDragEnd = {
                        if (totalY > 80f) tuneRelative(1)
                        else if (totalY < -80f) tuneRelative(-1)
                        totalY = 0f
                    },
                    onDragCancel = { totalY = 0f }
                )
            }
            .clickable(enabled = drawerMode == 0 && !liveSearchVisible) {
                if (isLive) {
                    openLiveSearchOverlay()
                } else {
                    showControls = !showControls
                }
            }
    ) {
        if (!useVlc && exoPlayer != null) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = {
                    PlayerView(it).apply {
                        useController = false
                        player = exoPlayer
                    }
                },
                update = { it.player = exoPlayer }
            )
        } else {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    VLCVideoLayout(ctx).apply {
                        keepScreenOn = true
                        vlcLayout = this
                    }
                },
                update = { layout ->
                    vlcLayout = layout
                }
            )
        }

        if (isLive && drawerMode == 0 && liveSearchVisible) {
            LiveSearchOverlay(
                query = liveSearchQuery,
                onQueryChange = {
                    liveSearchQuery = it
                    touchLiveSearchOverlay()
                },
                searchUi = liveSearchUi,
                searchFieldRequester = liveSearchFieldRequester,
                onResultClick = { movie ->
                    stopPlaybackNow()
                    closeLiveSearchOverlay()
                    onOpenMovie(movie)
                },
                onDismiss = { closeLiveSearchOverlay() },
                onInteraction = { touchLiveSearchOverlay() },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(horizontal = 18.dp, vertical = 18.dp)
            )
        }

        // generic status text only (no endpoints)
        errorMessage?.let { msg ->
            Text(
                text = msg,
                style = MaterialTheme.typography.labelMedium,
                color = Color(0xFFFFD54F),
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(12.dp)
            )
        }


        // Live info overlay (auto hides)
        if (isLive && drawerMode == 0 && liveInfoVisible) {
            LiveChannelInfoOverlay(
                channel = channel,
                nowNext = liveNowNextDisplay,
                timeFmt = timeFmt,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(18.dp)
            )
        }
        // Live TV quick drawer: Left/SwipeLeft cycles: Guide -> Categories -> Channels
        if (drawerEnabled && drawerMode != 0) {
            val scope = rememberCoroutineScope()

            // TV: when the drawer opens / changes mode, force focus into the current item instead of dumb top-of-list behavior.
            val guideListState = rememberLazyListState()
            val categoriesListState = rememberLazyListState()
            val channelsListState = rememberLazyListState()

            val guideFirstRequester = remember { FocusRequester() }
            val categoriesFirstRequester = remember { FocusRequester() }
            val channelsFirstRequester = remember { FocusRequester() }

            val currentChannelIndex = remember(categoryChannels, channel.streamId, channel.streamUrl, channel.name) {
                findChannelIndex(categoryChannels, channel)
            }
            val currentCategoryIndex = remember(liveCategories, liveCategoryId, channel.categoryId) {
                val targetCategoryId = liveCategoryId.ifBlank { channel.categoryId }
                liveCategories.indexOfFirst { it.id == targetCategoryId }.takeIf { it >= 0 } ?: 0
            }

            LaunchedEffect(drawerMode, liveCategoryId, categoryChannels.size, liveCategories.size, channel.streamId, channel.streamUrl, channel.name) {
                // give Compose a frame to compose the list items first
                withFrameNanos { }
                when (drawerMode) {
                    1 -> {
                        if (categoryChannels.isNotEmpty()) {
                            runCatching { guideListState.scrollToItem(currentChannelIndex.coerceIn(0, categoryChannels.lastIndex)) }
                        }
                        runCatching { guideFirstRequester.requestFocus() }
                    }
                    2 -> {
                        if (liveCategories.isNotEmpty()) {
                            runCatching { categoriesListState.scrollToItem(currentCategoryIndex.coerceIn(0, liveCategories.lastIndex)) }
                        }
                        runCatching { categoriesFirstRequester.requestFocus() }
                    }
                    3 -> {
                        if (categoryChannels.isNotEmpty()) {
                            runCatching { channelsListState.scrollToItem(currentChannelIndex.coerceIn(0, categoryChannels.lastIndex)) }
                        }
                        runCatching { channelsFirstRequester.requestFocus() }
                    }
                }
            }
            Box(
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .fillMaxHeight()
                    .width(560.dp)
                    .background(Color(0xEE000000))
                    .padding(16.dp)
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = when (drawerMode) {
                                1 -> "EPG"
                                2 -> "Categories"
                                else -> "Channels"
                            },
                            color = Color.White,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.SemiBold
                        )

                        if (drawerMode == 1) {
                            val interaction = remember { MutableInteractionSource() }
                            val focused by interaction.collectIsFocusedAsState()
                            Card(
                                modifier = Modifier
                                    .focusable(interactionSource = interaction)
                                    .clickable(interactionSource = interaction, indication = null) {
                                        scope.launch {
                                            drawerEpgLoading = true
                                            try {
                                                val res = withContext(Dispatchers.IO) {
                                                    EpgXmltv.fetchNowNextForChannelsFromUrls(
                                                        urls = drawerEpgUrls,
                                                        channels = categoryChannels
                                                    )
                                                }
                                                withContext(Dispatchers.IO) {
                                                    EpgDbHelper(context).writeNowNext(res.nowNextByStreamId)
                                                }
                                                drawerNowNext = res.nowNextByStreamId
                                            } catch (_: Throwable) {
                                            } finally {
                                                drawerEpgLoading = false
                                            }
                                        }
                                    }
                                    .border(
                                        width = if (focused) 2.dp else 1.dp,
                                        color = if (focused) Color(0xFF00E5FF) else Color(0x22FFFFFF),
                                        shape = RoundedCornerShape(12.dp)
                                    ),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = if (focused) Color(0x2400E5FF) else Color(0x14000000))
                            ) {
                                Text(
                                    text = if (drawerEpgLoading) "Refreshing…" else "Refresh",
                                    color = Color.White,
                                    style = MaterialTheme.typography.labelLarge,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    if (drawerMode == 1) {
                        LazyColumn(
                            state = guideListState,
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            itemsIndexed(categoryChannels, key = { _, it -> it.streamId.ifBlank { it.name } }) { idx, ch ->
                                val nn = drawerNowNext[ch.streamId]
                                val cur = nn?.current
                                val nxt = nn?.next
                                val interaction = remember { MutableInteractionSource() }
                                val isFocused by interaction.collectIsFocusedAsState()

                                Card(
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .then(if (idx == currentChannelIndex) Modifier.focusRequester(guideFirstRequester) else Modifier)
                                        .shadow(if (isFocused) 10.dp else 0.dp, RoundedCornerShape(14.dp), clip = false)
                                        .onPreviewKeyEvent { e: androidx.compose.ui.input.key.KeyEvent ->
                                            val ne = e.nativeKeyEvent
                                            if (ne.action == AndroidKeyEvent.ACTION_UP && (ne.keyCode == AndroidKeyEvent.KEYCODE_ENTER || ne.keyCode == AndroidKeyEvent.KEYCODE_DPAD_CENTER)) {
                                                onTuneChannel(ch)
                                                drawerMode = 0
                                                focusRootSafely()
                                                true
                                            } else false
                                        }
                                        .focusable(interactionSource = interaction)
                                        .clickable(interactionSource = interaction, indication = null) {
                                            onTuneChannel(ch)
                                            drawerMode = 0
                                            focusRootSafely()
                                        }
                                        .border(
                                            width = if (isFocused) 2.dp else 1.dp,
                                            color = if (isFocused) Color(0xFF00E5FF) else Color(0x22FFFFFF),
                                            shape = RoundedCornerShape(14.dp)
                                        ),
                                    colors = CardDefaults.cardColors(containerColor = if (isFocused) Color(0x2400E5FF) else Color(0x14000000))
                                ) {
                                    Column(Modifier.padding(horizontal = 14.dp, vertical = 12.dp)) {
                                        Text(
                                            text = ch.name,
                                            color = Color.White,
                                            style = MaterialTheme.typography.titleSmall,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Spacer(Modifier.height(4.dp))
                                        Text(
                                            text = if (cur != null) "Now: ${cur.title} (${timeFmt.format(Date(cur.startMs))} - ${timeFmt.format(Date(cur.stopMs))})" else "Now: —",
                                            color = Color(0xFFB0B0B0),
                                            style = MaterialTheme.typography.bodySmall,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = if (nxt != null) "Next: ${nxt.title} (${timeFmt.format(Date(nxt.startMs))})" else "Next: —",
                                            color = Color(0xFFB0B0B0),
                                            style = MaterialTheme.typography.bodySmall,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }
                        }
                    } else if (drawerMode == 2) {
                        // Categories list
                        LazyColumn(
                            state = categoriesListState,
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            itemsIndexed(liveCategories, key = { _, it -> it.id.ifBlank { it.name } }) { idx, cat ->
                                val interaction = remember { MutableInteractionSource() }
                                val isFocused by interaction.collectIsFocusedAsState()
                                Card(
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .then(if (idx == currentCategoryIndex) Modifier.focusRequester(categoriesFirstRequester) else Modifier)
                                        .focusable(interactionSource = interaction)
                                        .clickable(interactionSource = interaction, indication = null) {
                                            // Select category, then jump straight to Channels pane.
                                            onSelectCategory(cat.id)
                                            drawerMode = 3
                                            }
                                        .border(
                                            width = if (isFocused) 2.dp else 1.dp,
                                            color = if (isFocused) Color(0xFF00E5FF) else Color(0x22FFFFFF),
                                            shape = RoundedCornerShape(14.dp)
                                        ),
                                    colors = CardDefaults.cardColors(containerColor = if (isFocused) Color(0x2400E5FF) else Color(0x14000000))
                                ) {
                                    Text(
                                        text = cat.name,
                                        color = Color.White,
                                        style = MaterialTheme.typography.titleSmall,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 14.dp)
                                    )
                                }
                            }
                        }
                    } else {
                        // Channels list for current category
                        LazyColumn(
                            state = channelsListState,
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            itemsIndexed(categoryChannels, key = { _, it -> it.streamId.ifBlank { it.name } }) { idx, ch ->
                                val interaction = remember { MutableInteractionSource() }
                                val isFocused by interaction.collectIsFocusedAsState()
                                Card(
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .then(if (idx == currentChannelIndex) Modifier.focusRequester(channelsFirstRequester) else Modifier)
                                        .focusable(interactionSource = interaction)
                                        .clickable(interactionSource = interaction, indication = null) {
                                            onTuneChannel(ch)
                                            drawerMode = 0
                                            focusRootSafely()
                                        }
                                        .border(
                                            width = if (isFocused) 2.dp else 1.dp,
                                            color = if (isFocused) Color(0xFF00E5FF) else Color(0x22FFFFFF),
                                            shape = RoundedCornerShape(14.dp)
                                        ),
                                    colors = CardDefaults.cardColors(containerColor = if (isFocused) Color(0x2400E5FF) else Color(0x14000000))
                                ) {
                                    Text(
                                        text = ch.name,
                                        color = Color.White,
                                        style = MaterialTheme.typography.titleSmall,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 14.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showControls && !isLive) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color(0xCC000000), Color.Transparent)
                        )
                    )
                    .padding(18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "←",
                    style = MaterialTheme.typography.titleLarge,
                    color = Color.White,
                    modifier = Modifier
                        .padding(end = 14.dp)
                        .clickable { onClose() }
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = channel.name,
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White,
                        maxLines = 1
                    )
                    val sub = channel.groupTitle.ifBlank { "LIVE TV" }
                    Text(
                        text = sub.uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xB3FFFFFF),
                        maxLines = 1
                    )
                }

                if (useVlc) {
                    Text(
                        text = "VLC",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xB3FFFFFF)
                    )
                }
            }

            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color.Transparent, Color(0xE6000000))
                        )
                    )
                    .padding(horizontal = 18.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                
                    val dur = durationMs.takeIf { it > 0L } ?: 1L
                    Slider(
                        value = (positionMs.toFloat() / dur.toFloat()).coerceIn(0f, 1f),
                        onValueChange = { frac ->
                            val seekTo = (dur * frac).toLong()
                            if (!useVlc && exoPlayer != null) exoPlayer.seekTo(seekTo)
                            if (useVlc && vlcPlayer != null && durationMs > 0) vlcPlayer.time = seekTo
                        },
                        enabled = durationMs > 0
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = formatTime(positionMs),
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xB3FFFFFF)
                        )

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            val playing = if (!useVlc) (exoPlayer?.isPlaying == true) else vlcPlaying
                            Text(
                                text = if (playing) "⏸" else "▶",
                                style = MaterialTheme.typography.titleLarge,
                                color = Color.White,
                                modifier = Modifier
                                    .padding(horizontal = 14.dp)
                                    .clickable {
                                        if (!useVlc && exoPlayer != null) {
                                            if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
                                        } else if (useVlc && vlcPlayer != null) {
                                            if (vlcPlaying) vlcPlayer.pause() else vlcPlayer.play()
                                        }
                                    }
                            )
                            Text(
                                text = "✕",
                                style = MaterialTheme.typography.titleLarge,
                                color = Color.White,
                                modifier = Modifier
                                    .padding(start = 14.dp)
                                    .clickable { onClose() }
                            )
                        }

                        Text(
                            text = formatTime(durationMs),
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xB3FFFFFF)
                        )
                    }
                


        }
    }
}

}
private fun backoffMs(attempt: Int): Long {
    // attempt=0 -> immediate; then ramps up but stays snappy for live TV.
    return when {
        attempt <= 0 -> 0L
        attempt == 1 -> 1200L
        attempt == 2 -> 2200L
        attempt == 3 -> 3500L
        attempt == 4 -> 5200L
        else -> 7000L
    }
}

private fun buildStreamCandidates(url: String): List<String> {
    val u = url.trim()
    if (u.isEmpty()) return emptyList()

    val out = ArrayList<String>(4)
    out.add(u)

    val lower = u.lowercase()
    val qIdx = u.indexOf('?')
    val base = if (qIdx >= 0) u.substring(0, qIdx) else u
    val query = if (qIdx >= 0) u.substring(qIdx) else ""

    fun addCandidate(rawBase: String, ext: String) {
        out.add(rawBase + ext + query)
    }

    // Swap common Xtream extensions.
    if (lower.endsWith(".ts") || lower.contains(".ts?")) {
        val baseNoExt = if (base.lowercase().endsWith(".ts")) base.dropLast(3) else base
        addCandidate(baseNoExt, ".m3u8")
    } else if (lower.endsWith(".m3u8") || lower.contains(".m3u8?")) {
        val baseNoExt = if (base.lowercase().endsWith(".m3u8")) base.dropLast(5) else base
        addCandidate(baseNoExt, ".ts")
    } else {
        // Extensionless URLs (common in Xtream /live/.../id) — try explicit .ts and .m3u8.
        val lastSeg = base.substringAfterLast('/', base)
        val hasDot = lastSeg.contains('.')
        if (!hasDot) {
            addCandidate(base, ".m3u8")
            addCandidate(base, ".ts")
        }
    }

    return out.distinct()
}


private fun nextCandidate(candidates: List<String>, current: String): String? {
    val idx = candidates.indexOf(current)
    if (idx < 0) return null
    val nextIdx = idx + 1
    return if (nextIdx in candidates.indices) candidates[nextIdx] else null
}


private fun findInvalidResponseCode(t: Throwable?): HttpDataSource.InvalidResponseCodeException? {
    var c = t
    while (c != null) {
        if (c is HttpDataSource.InvalidResponseCodeException) return c
        c = c.cause
    }
    return null
}



private fun nextCandidateVlcSafe(candidates: List<String>, current: String): String? {
    val idx = candidates.indexOf(current)
    if (idx < 0) return null
    for (i in (idx + 1) until candidates.size) {
        val c = candidates[i]
        if (!c.lowercase().contains(".m3u8")) return c
    }
    return null
}

private fun pickVlcSafeUrl(candidates: List<String>, current: String): String {
    val lower = current.lowercase()
    val ts = candidates.firstOrNull { it.lowercase().endsWith(".ts") || it.lowercase().contains(".ts?") }
    if (lower.contains(".m3u8")) return ts ?: current

    // If extensionless and we have a TS candidate, prefer TS for VLC.
    val base = current.substringBefore('?')
    val lastSeg = base.substringAfterLast('/', base)
    val hasDot = lastSeg.contains('.')
    if (!hasDot) return ts ?: current

    return current
}

private fun pickExoPreferredUrl(candidates: List<String>, current: String, isLive: Boolean): String {
    // Live: start with the ORIGINAL URL first.
    // Some providers 404 the synthetic ".ts" swap, and if we start on the last candidate we never
    // get a chance to try the real m3u8/original.
    if (isLive) {
        return candidates.firstOrNull() ?: current
    }
    return current
}
private fun findChannelIndex(channels: List<Channel>, channel: Channel): Int {
    if (channels.isEmpty()) return 0

    val streamId = channel.streamId
    if (streamId.isNotBlank()) {
        val idx = channels.indexOfFirst { it.streamId == streamId }
        if (idx >= 0) return idx
    }

    val streamUrl = channel.streamUrl
    if (streamUrl.isNotBlank()) {
        val idx = channels.indexOfFirst { it.streamUrl == streamUrl }
        if (idx >= 0) return idx
    }

    val name = channel.name
    val idx = channels.indexOfFirst { it.name == name }
    return if (idx >= 0) idx else 0
}

private fun applyVlcMediaOptions(media: Media, url: String) {
    // Robust reconnect/caching defaults (no endpoints shown anywhere).
    media.addOption(":network-caching=1500")
    media.addOption(":live-caching=1500")
    media.addOption(":file-caching=1500")
    media.addOption(":http-reconnect=true")
    media.addOption(":reconnect=true")
    media.addOption(":clock-jitter=0")
    media.addOption(":clock-synchro=0")
    media.addOption(":no-video-title-show")

    // Some sources block "unknown" clients; generic UA helps without exposing URLs.
    media.addOption(
        ":http-user-agent=Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
    )

    val lower = url.lowercase()
    if (lower.contains(".m3u8")) {
        // Avoid VLC adaptive/HLS playlist demux crashes seen on some devices/emulators.
        // If the server is actually serving TS behind a .m3u8 URL, forcing TS can still work.
        media.addOption(":demux=ts")
        media.addOption(":codec=avcodec")
        media.addOption(":avcodec-hw=any")
        media.addOption(":no-audio-time-stretch")
    } else if (lower.endsWith(".ts") || lower.contains(".ts?")) {
        // TS over HTTP can be picky depending on headers/muxing; these options help VLC
        // decode H264 + AAC(ADTS) more consistently on Android devices.
        media.addOption(":codec=avcodec")
        media.addOption(":avcodec-hw=any")
        media.addOption(":no-audio-time-stretch")
    }
}

private fun normalizeNowNext(
    nowNext: com.gamechanger.iptv.api.EpgNowNext?,
    nowMs: Long
): com.gamechanger.iptv.api.EpgNowNext? {
    val cur = nowNext?.current
    val nxt = nowNext?.next

    val curActive = cur != null &&
        cur.startMs > 0L &&
        cur.stopMs > cur.startMs &&
        nowMs >= cur.startMs &&
        nowMs < cur.stopMs

    val nextActive = nxt != null &&
        nxt.startMs > 0L &&
        nxt.stopMs > nxt.startMs &&
        nowMs >= nxt.startMs &&
        nowMs < nxt.stopMs

    return when {
        curActive -> com.gamechanger.iptv.api.EpgNowNext(
            current = cur,
            next = nxt?.takeIf { it.stopMs > nowMs },
            matchedXmltvId = nowNext?.matchedXmltvId
        )
        nextActive -> com.gamechanger.iptv.api.EpgNowNext(
            current = nxt,
            next = null,
            matchedXmltvId = nowNext?.matchedXmltvId
        )
        nxt != null && nxt.stopMs > nowMs -> com.gamechanger.iptv.api.EpgNowNext(
            current = null,
            next = nxt,
            matchedXmltvId = nowNext?.matchedXmltvId
        )
        cur != null && cur.stopMs > nowMs -> com.gamechanger.iptv.api.EpgNowNext(
            current = cur,
            next = nxt?.takeIf { it.stopMs > nowMs },
            matchedXmltvId = nowNext?.matchedXmltvId
        )
        else -> com.gamechanger.iptv.api.EpgNowNext(
            current = null,
            next = null,
            matchedXmltvId = nowNext?.matchedXmltvId
        )
    }
}

private fun formatTime(ms: Long): String {
    if (ms <= 0) return "0:00"
    val totalSec = ms / 1000
    val m = totalSec / 60
    val s = totalSec % 60
    return "%d:%02d".format(m, s)
}


@Composable
private fun LiveChannelInfoOverlay(
    channel: Channel,
    nowNext: com.gamechanger.iptv.api.EpgNowNext?,
    timeFmt: SimpleDateFormat,
    modifier: Modifier = Modifier
) {
    val cur = nowNext?.current
    val curTitle = cur?.title?.takeIf { it.isNotBlank() } ?: "No EPG"
    val timeRange = if (cur != null && cur.startMs > 0L && cur.stopMs > cur.startMs) {
        "${timeFmt.format(Date(cur.startMs))} - ${timeFmt.format(Date(cur.stopMs))}"
    } else ""

    val nowMs = TimeSync.nowMs()
    val progress = if (cur != null && cur.startMs > 0L && cur.stopMs > cur.startMs) {
        ((nowMs - cur.startMs).toFloat() / (cur.stopMs - cur.startMs).toFloat()).coerceIn(0f, 1f)
    } else null

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xCC000000)),
        modifier = modifier
            .width(620.dp)
            .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(18.dp))
            .shadow(12.dp, RoundedCornerShape(18.dp))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (channel.logoUrl.isNotBlank()) {
                AsyncImage(
                    model = channel.logoUrl,
                    contentDescription = channel.name,
                    modifier = Modifier.size(64.dp),
                    contentScale = ContentScale.Fit
                )
            } else {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .background(Color(0x2200E5FF), RoundedCornerShape(14.dp))
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = channel.name,
                        color = Color.White,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Card(
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0x2600E5FF)),
                        modifier = Modifier.padding(start = 10.dp)
                    ) {
                        Text(
                            text = "LIVE",
                            color = Color(0xFF00E5FF),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }

                Text(
                    text = curTitle,
                    color = Color.White,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                if (timeRange.isNotBlank()) {
                    Text(
                        text = timeRange,
                        color = Color(0xB3FFFFFF),
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                if (progress != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(4.dp)
                            .background(Color(0x22FFFFFF), RoundedCornerShape(4.dp))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(progress)
                                .fillMaxHeight()
                                .background(Color(0xFF00E5FF), RoundedCornerShape(4.dp))
                        )
                    }
                }
            }
        }
    }
}

private data class LiveSearchUi(
    val loading: Boolean = false,
    val items: List<Movie> = emptyList()
)

private fun TmdbMovieResult.toOverlayMovie(): Movie {
    val titleText = (title ?: name ?: "Untitled").trim()
    val yearText = (release_date ?: first_air_date)?.take(4)?.trim().orEmpty()
    val media = if (title.isNullOrBlank()) "tv" else "movie"

    return Movie(
        id = id ?: 0,
        title = titleText.ifBlank { "Untitled" },
        overview = overview?.trim().orEmpty(),
        posterUrl = TmdbImages.posterW500(poster_path),
        backdropUrl = TmdbImages.backdropW780(backdrop_path),
        year = yearText,
        rating = vote_average ?: 0.0,
        mediaType = media
    )
}

@Composable
private fun LiveSearchOverlay(
    query: String,
    onQueryChange: (String) -> Unit,
    searchUi: LiveSearchUi,
    searchFieldRequester: FocusRequester,
    onResultClick: (Movie) -> Unit,
    onDismiss: () -> Unit,
    onInteraction: () -> Unit,
    modifier: Modifier = Modifier
) {
    val resultsListState = rememberLazyListState()
    val overlayScope = rememberCoroutineScope()
    var searchFieldFocused by remember { mutableStateOf(false) }
    var focusedResultIndex by remember(searchUi.items) { mutableStateOf(-1) }

    fun focusResult(index: Int) {
        if (index !in searchUi.items.indices) return
        focusedResultIndex = index
        onInteraction()
        overlayScope.launch {
            val visible = resultsListState.layoutInfo.visibleItemsInfo
            val firstVisible = visible.firstOrNull()?.index
            val lastVisible = visible.lastOrNull()?.index
            if (firstVisible == null || lastVisible == null || index !in firstVisible..lastVisible) {
                runCatching { resultsListState.scrollToItem(index) }
            }
            withFrameNanos { }
            runCatching { searchFieldRequester.requestFocus() }
        }
    }

    fun focusSearchField() {
        focusedResultIndex = -1
        onInteraction()
        overlayScope.launch {
            withFrameNanos { }
            runCatching { searchFieldRequester.requestFocus() }
        }
    }

    LaunchedEffect(searchUi.items.size) {
        if (searchUi.items.isEmpty() && focusedResultIndex != -1) {
            focusedResultIndex = -1
            focusSearchField()
        } else if (focusedResultIndex >= searchUi.items.size) {
            focusedResultIndex = -1
        }
    }

    LaunchedEffect(query.trim(), searchUi.items.size) {
        if (query.trim().length >= 2 && searchUi.items.isNotEmpty() && focusedResultIndex == -1) {
            focusResult(0)
        }
        if (query.trim().length >= 2) {
            overlayScope.launch {
                withFrameNanos { }
                runCatching { searchFieldRequester.requestFocus() }
            }
        }
    }

    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xD6000000)),
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(22.dp))
            .shadow(16.dp, RoundedCornerShape(22.dp))
            .onPreviewKeyEvent { event ->
                val native = event.nativeKeyEvent
                if (native.action != AndroidKeyEvent.ACTION_DOWN) return@onPreviewKeyEvent false
                onInteraction()

                when (native.keyCode) {
                    AndroidKeyEvent.KEYCODE_DPAD_DOWN -> {
                        if (searchFieldFocused && searchUi.items.isNotEmpty()) {
                            focusResult(0)
                        }
                        true
                    }
                    AndroidKeyEvent.KEYCODE_DPAD_UP -> {
                        if (focusedResultIndex >= 0) {
                            focusSearchField()
                        }
                        true
                    }
                    AndroidKeyEvent.KEYCODE_DPAD_LEFT -> {
                        when {
                            focusedResultIndex > 0 -> focusResult(focusedResultIndex - 1)
                            else -> onInteraction()
                        }
                        true
                    }
                    AndroidKeyEvent.KEYCODE_DPAD_RIGHT -> {
                        when {
                            focusedResultIndex in searchUi.items.indices && focusedResultIndex < searchUi.items.lastIndex -> {
                                focusResult(focusedResultIndex + 1)
                            }
                            focusedResultIndex in searchUi.items.indices -> {
                                onInteraction()
                            }
                            else -> {
                                onDismiss()
                            }
                        }
                        true
                    }
                    AndroidKeyEvent.KEYCODE_BACK -> {
                        onDismiss()
                        true
                    }
                    AndroidKeyEvent.KEYCODE_DPAD_CENTER,
                    AndroidKeyEvent.KEYCODE_ENTER -> {
                        if (focusedResultIndex in searchUi.items.indices) {
                            onResultClick(searchUi.items[focusedResultIndex])
                            true
                        } else searchFieldFocused
                    }
                    else -> false
                }
            }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = "Search VOD from Live TV",
                color = Color.White,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            if (searchUi.loading) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color(0xFF00E5FF))
                    Text(
                        text = "Searching",
                        color = Color(0xCCFFFFFF),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            if (query.trim().length >= 2 && searchUi.items.isNotEmpty()) {
                LazyRow(
                    state = resultsListState,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    itemsIndexed(searchUi.items, key = { _, it -> "${it.mediaType}_${it.id}" }) { index, movie ->
                        val isFocused = focusedResultIndex == index
                        val interaction = remember { MutableInteractionSource() }
                        Column(
                            modifier = Modifier
                                .width(140.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Card(
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(205.dp)
                                    .clickable(interactionSource = interaction, indication = null) { focusedResultIndex = index; onResultClick(movie) }
                                    .border(
                                        width = if (isFocused) 2.dp else 1.dp,
                                        color = if (isFocused) Color(0xFF00E5FF) else Color(0x22FFFFFF),
                                        shape = RoundedCornerShape(14.dp)
                                    ),
                                colors = CardDefaults.cardColors(containerColor = Color(0x18000000))
                            ) {
                                AsyncImage(
                                    model = movie.posterUrl.ifBlank { movie.backdropUrl },
                                    contentDescription = movie.title,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }

                            Text(
                                text = movie.title,
                                color = Color.White,
                                style = MaterialTheme.typography.bodyMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = listOfNotNull(
                                    movie.year.takeIf { it.isNotBlank() },
                                    movie.mediaType.uppercase()
                                ).joinToString(" • "),
                                color = Color(0xB3FFFFFF),
                                style = MaterialTheme.typography.labelSmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            } else if (query.trim().length >= 2 && !searchUi.loading) {
                Text(
                    text = "No matches yet.",
                    color = Color(0xCCFFFFFF),
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            TextField(
                value = query,
                onValueChange = onQueryChange,
                singleLine = true,
                placeholder = { Text("Search movies or shows…", color = Color(0xFF8C8C8C)) },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color(0xFF111111),
                    unfocusedContainerColor = Color(0xFF111111),
                    disabledContainerColor = Color(0xFF111111),
                    focusedIndicatorColor = Color(0xFF00E5FF),
                    unfocusedIndicatorColor = Color(0x33FFFFFF),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    cursorColor = Color(0xFF00E5FF)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .focusRequester(searchFieldRequester)
                    .onFocusChanged {
                        searchFieldFocused = it.isFocused
                        if (it.isFocused) {
                            focusedResultIndex = -1
                            onInteraction()
                        }
                    }
            )
        }
    }
}
