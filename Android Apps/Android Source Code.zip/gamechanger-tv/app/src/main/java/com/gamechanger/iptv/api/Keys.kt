package com.gamechanger.iptv.api

object Keys {
    // TMDB API key (pre-filled)
    const val TMDB_API_KEY = "32b609d895fa932fdf84565ff317e1cf"
}
