package com.gamechanger.iptv.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import androidx.compose.material3.Text
import com.gamechanger.iptv.ui.theme.ElectricBlue
import com.gamechanger.iptv.ui.theme.SurfaceDark

@Composable  
fun MediaCard(title: String, poster: String, onClick: (() -> Unit)? = null) {  
    var isFocused by remember { mutableStateOf(false) }  
    val scale by animateFloatAsState(if (isFocused) 1.15f else 1.0f)  

    Column(  
        modifier = Modifier  
            .onFocusChanged { isFocused = it.isFocused }  
            .scale(scale)  
            .padding(12.dp)  
            .width(160.dp)  
            .border(if (isFocused) 3.dp else 0.dp, ElectricBlue, RoundedCornerShape(12.dp))  
            .background(SurfaceDark, RoundedCornerShape(12.dp))  
            .clip(RoundedCornerShape(12.dp))  
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
    ) {  
        AsyncImage(model = poster, contentDescription = title, modifier = Modifier.height(240.dp), contentScale = ContentScale.Crop)  
        Text(title, color = if (isFocused) ElectricBlue else Color.White, modifier = Modifier.padding(8.dp), maxLines = 1)  
    }  
}  
