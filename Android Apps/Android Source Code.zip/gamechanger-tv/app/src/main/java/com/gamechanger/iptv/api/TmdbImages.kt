package com.gamechanger.iptv.api

object TmdbImages {
    fun posterW500(path: String?): String =
        if (path.isNullOrBlank()) "" else "https://image.tmdb.org/t/p/w500$path"

    fun backdropW780(path: String?): String =
        if (path.isNullOrBlank()) "" else "https://image.tmdb.org/t/p/w780$path"
}
