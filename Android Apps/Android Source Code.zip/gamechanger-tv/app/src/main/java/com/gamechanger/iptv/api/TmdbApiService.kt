package com.gamechanger.iptv.api

import retrofit2.http.GET
import retrofit2.http.Query
import retrofit2.http.Path

data class TmdbListResponse(
    val results: List<TmdbMovieResult> = emptyList()
)

data class TmdbGenreListResponse(
    val genres: List<TmdbGenre> = emptyList()
)

data class TmdbGenre(
    val id: Int,
    val name: String
)

data class TmdbMovieResult(
    val id: Int? = null,
    val title: String? = null,
    val name: String? = null,
    val overview: String? = null,
    val poster_path: String? = null,
    val backdrop_path: String? = null,
    val release_date: String? = null,
    val first_air_date: String? = null,
    val vote_average: Double? = null
)


data class TmdbSeasonSummary(
    val id: Int? = null,
    val name: String? = null,
    val season_number: Int? = null,
    val episode_count: Int? = null
)

data class TmdbTvDetailsResponse(
    val id: Int? = null,
    val name: String? = null,
    val overview: String? = null,
    val seasons: List<TmdbSeasonSummary> = emptyList(),
    val number_of_seasons: Int? = null
)

data class TmdbEpisodeSummary(
    val id: Int? = null,
    val name: String? = null,
    val episode_number: Int? = null
)

data class TmdbSeasonDetailsResponse(
    val id: Int? = null,
    val name: String? = null,
    val season_number: Int? = null,
    val episodes: List<TmdbEpisodeSummary> = emptyList()
)

interface TmdbApiService {

    // Genres
    @GET("genre/movie/list")
    suspend fun movieGenres(
        @Query("api_key") key: String
    ): TmdbGenreListResponse

    @GET("discover/movie")
    suspend fun discoverMovies(
        @Query("api_key") key: String,
        @Query("with_genres") genreId: Int,
        @Query("sort_by") sortBy: String = "popularity.desc",
        @Query("include_adult") includeAdult: Boolean = false,
        @Query("page") page: Int = 1
    ): TmdbListResponse

    @GET("discover/tv")
    suspend fun discoverSeries(
        @Query("api_key") key: String,
        @Query("first_air_date_year") year: Int,
        @Query("sort_by") sortBy: String = "popularity.desc",
        @Query("include_adult") includeAdult: Boolean = false,
        @Query("page") page: Int = 1
    ): TmdbListResponse

    // Movies
    @GET("trending/movie/week")
    suspend fun trendingMoviesWeek(
        @Query("api_key") key: String,
        @Query("page") page: Int = 1
    ): TmdbListResponse

    @GET("movie/popular")
    suspend fun popularMovies(
        @Query("api_key") key: String,
        @Query("page") page: Int = 1
    ): TmdbListResponse

    @GET("movie/top_rated")
    suspend fun topRatedMovies(
        @Query("api_key") key: String,
        @Query("page") page: Int = 1
    ): TmdbListResponse

    @GET("movie/upcoming")
    suspend fun upcomingMovies(
        @Query("api_key") key: String,
        @Query("page") page: Int = 1
    ): TmdbListResponse

    @GET("search/movie")
    suspend fun searchMovie(
        @Query("api_key") key: String,
        @Query("query") title: String,
        @Query("page") page: Int = 1
    ): TmdbListResponse

    // Series (TV)
    @GET("trending/tv/week")
    suspend fun trendingSeriesWeek(
        @Query("api_key") key: String,
        @Query("page") page: Int = 1
    ): TmdbListResponse

    @GET("tv/popular")
    suspend fun popularSeries(
        @Query("api_key") key: String,
        @Query("page") page: Int = 1
    ): TmdbListResponse

    @GET("tv/top_rated")
    suspend fun topRatedSeries(
        @Query("api_key") key: String,
        @Query("page") page: Int = 1
    ): TmdbListResponse

    @GET("tv/on_the_air")
    suspend fun onTheAirSeries(
        @Query("api_key") key: String,
        @Query("page") page: Int = 1
    ): TmdbListResponse

    @GET("search/tv")
    suspend fun searchSeries(
        @Query("api_key") key: String,
        @Query("query") title: String,
        @Query("page") page: Int = 1
    ): TmdbListResponse

    // TV details / seasons / episodes
    @GET("tv/{tv_id}")
    suspend fun tvDetails(
        @Path("tv_id") tvId: Int,
        @Query("api_key") key: String
    ): TmdbTvDetailsResponse

    @GET("tv/{tv_id}/season/{season_number}")
    suspend fun seasonDetails(
        @Path("tv_id") tvId: Int,
        @Path("season_number") seasonNumber: Int,
        @Query("api_key") key: String
    ): TmdbSeasonDetailsResponse

}
