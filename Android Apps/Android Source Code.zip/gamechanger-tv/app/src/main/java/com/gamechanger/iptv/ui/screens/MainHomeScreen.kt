package com.gamechanger.iptv.ui.screens

import android.util.Log
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import android.webkit.JavascriptInterface
import androidx.compose.ui.platform.LocalContext
import java.util.concurrent.CopyOnWriteArrayList
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.webkit.WebResourceRequest
import android.webkit.WebResourceError
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.viewinterop.AndroidView
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.CookieManager
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import okhttp3.OkHttpClient
import okhttp3.Request
import com.gamechanger.iptv.ui.components.TvPillButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.gamechanger.iptv.api.ApiClient
import com.gamechanger.iptv.api.Keys
import com.gamechanger.iptv.api.M3uParser
import com.gamechanger.iptv.api.TmdbImages
import com.gamechanger.iptv.api.TmdbListResponse
import com.gamechanger.iptv.api.TmdbMovieResult
import com.gamechanger.iptv.ui.model.Channel
import com.gamechanger.iptv.ui.model.LiveCategory
import com.gamechanger.iptv.ui.components.CinematicPlayerOverlay
import com.gamechanger.iptv.ui.model.Movie
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.foundation.shape.RoundedCornerShape
import android.view.View
import android.view.ViewGroup
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.InputDevice
import android.view.Gravity
import android.os.SystemClock
import android.graphics.Canvas
import android.graphics.Paint
import android.widget.FrameLayout
import android.graphics.Color as AndroidColor
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.Surface
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import com.gamechanger.iptv.util.CacheCleaner
import android.provider.Settings
import java.net.URLEncoder
import com.gamechanger.iptv.api.PanelTelemetry
import com.gamechanger.iptv.util.UserShelfStore


private const val SERVERS_JSON_URL: String = "https://who.what.who/servers.json" // set to your own servers.json endpoint

private data class PlaybackServer(
    val name: String,
    val webViewTemplate: String
)

private data class PlaybackConfig(
    val servers: List<PlaybackServer>,
    val defaultIndex: Int,
    val error: String? = null
)

private data class SelectedMovieState(
    val movie: Movie,
    val seasonNumber: Int = 1,
    val episodeNumber: Int = 1
)

@Composable
fun MainHomeScreen(
    serverUrl: String,
    username: String,
    password: String,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier,
    onFullscreenPlaybackChanged: (Boolean) -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val trending by rememberTmdbMovies(
        fetch = {
            fetchCombinedTmdbMovies(
                { page -> ApiClient.tmdb().trendingMoviesWeek(Keys.TMDB_API_KEY, page) },
                pages = 4
            )
        },
        mixYears = true
    )
    val popular by rememberTmdbMovies(
        fetch = {
            fetchCombinedTmdbMovies(
                { page -> ApiClient.tmdb().popularMovies(Keys.TMDB_API_KEY, page) },
                pages = 6
            )
        },
        mixYears = true
    )
    val topRated by rememberTmdbMovies(
        fetch = {
            fetchCombinedTmdbMovies(
                { page -> ApiClient.tmdb().topRatedMovies(Keys.TMDB_API_KEY, page) },
                pages = 6
            )
        },
        mixYears = true
    )
    val latest by rememberTmdbMovies(
        fetch = {
            fetchCombinedTmdbMovies(
                { page -> ApiClient.tmdb().upcomingMovies(Keys.TMDB_API_KEY, page) },
                pages = 4
            )
        },
        mixYears = true
    )
    val trendingTv by rememberTmdbMovies(
        fetch = {
            fetchCombinedTmdbMovies(
                { page -> ApiClient.tmdb().trendingSeriesWeek(Keys.TMDB_API_KEY, page) },
                pages = 1
            )
        }
    )
    val popularTv by rememberTmdbMovies(
        fetch = {
            fetchCombinedTmdbMovies(
                { page -> ApiClient.tmdb().popularSeries(Keys.TMDB_API_KEY, page) },
                pages = 1
            )
        }
    )
    val topRatedTv by rememberTmdbMovies(
        fetch = {
            fetchCombinedTmdbMovies(
                { page -> ApiClient.tmdb().topRatedSeries(Keys.TMDB_API_KEY, page) },
                pages = 1
            )
        }
    )
    val onTheAirTv by rememberTmdbMovies(
        fetch = {
            fetchCombinedTmdbMovies(
                { page -> ApiClient.tmdb().onTheAirSeries(Keys.TMDB_API_KEY, page) },
                pages = 1
            )
        }
    )

    data class LiveTvPayload(
    val categories: List<LiveCategory> = emptyList(),
    val channels: List<Channel> = emptyList()
)

var liveRequested by remember { mutableStateOf(false) }
var liveRefreshToken by remember { mutableStateOf(0) }
val liveTv by produceState(initialValue = LiveTvPayload(), liveRequested, liveRefreshToken, serverUrl, username, password) {
    if (!liveRequested) {
        value = LiveTvPayload()
        return@produceState
    }
    value = try {
        withContext(Dispatchers.IO) {
            val api = ApiClient.xtream(serverUrl)
            val cats = api.getLiveCategories(username, password).body().orEmpty()
            val streams = api.getLiveStreams(username, password).body().orEmpty()

            val categoryMap = cats.associate { (it.categoryId ?: "").trim() to (it.categoryName ?: "").trim() }

            val uiCats = cats.mapNotNull { c ->
                val id = (c.categoryId ?: "").trim()
                val name = (c.categoryName ?: "").trim()
                if (id.isBlank() || name.isBlank()) null else LiveCategory(id = id, name = name)
            }.distinctBy { it.id }

            val channels = streams.mapNotNull { s ->
                val streamId = (s.streamId ?: "").trim()
                if (streamId.isBlank()) return@mapNotNull null
                val name = (s.name ?: "").trim().ifBlank { "Channel" }
                val catId = (s.categoryId ?: "").trim()

                // Prefer panel-provided direct_source when available (commonly .m3u8 or custom URLs).
                // If it's a relative path like "steam.m3u8", resolve it against the Xtream live base
                // (/live/{user}/{pass}/) since many panels store direct_source as a filename.

val baseLiveUrl = serverUrl.trimEnd('/') + "/live/" + username + "/" + password + "/" + streamId
val resolvedStreamUrl = appendDeviceId(baseLiveUrl, deviceId(context))

Channel(
                    name = name,
                    logoUrl = (s.streamIcon ?: "").trim(),
                    streamUrl = resolvedStreamUrl,
                    groupTitle = categoryMap[catId].orEmpty(),
                    categoryId = catId,
                    streamId = streamId
                )
            }

            LiveTvPayload(categories = uiCats, channels = channels)
        }
    } catch (_: Throwable) {
        // Fallback to playlist parsing if JSON API is unavailable
        try {
            withContext(Dispatchers.IO) {
                val body = ApiClient.xtream(serverUrl)
                    .getPlaylist(username, password)
                    .body()
                    ?.string()
                    .orEmpty()
                val channels = M3uParser.parseChannels(body, limit = 1200)
                LiveTvPayload(categories = emptyList(), channels = channels)
            }
        } catch (_: Throwable) {
            LiveTvPayload()
        }
    }
}

    val sectionState = remember { mutableStateOf(SidebarSection.HOME) }
    val liveTabState = remember { mutableStateOf(LiveTab.CHANNELS) }
    val selectedLiveCategoryIdState = remember { mutableStateOf("") }
    var lastWatchedLiveStreamId by remember { mutableStateOf<String?>(null) }

    var selectedMovie by remember { mutableStateOf<SelectedMovieState?>(null) }
    var selectedChannel by remember { mutableStateOf<Channel?>(null) }
    var previousLiveChannel by remember { mutableStateOf<Channel?>(null) }
    var shelfVersion by remember { mutableStateOf(0) }

    fun openLiveChannel(channel: Channel, rememberPrevious: Boolean = true) {
        val current = selectedChannel
        if (rememberPrevious && current != null && current.streamId != channel.streamId) {
            previousLiveChannel = current
        }
        lastWatchedLiveStreamId = channel.streamId
        if (channel.categoryId.isNotBlank()) selectedLiveCategoryIdState.value = channel.categoryId
        UserShelfStore.recordRecentChannel(context, channel)
        shelfVersion++
        sectionState.value = SidebarSection.LIVE
        liveTabState.value = LiveTab.CHANNELS
        selectedChannel = channel
    }

    fun tuneToPreviousLiveChannel() {
        val current = selectedChannel ?: return
        val previous = previousLiveChannel ?: return
        if (previous.streamId == current.streamId) return
        previousLiveChannel = current
        openLiveChannel(previous, rememberPrevious = false)
    }

    androidx.compose.runtime.LaunchedEffect(selectedChannel != null) {
        onFullscreenPlaybackChanged(selectedChannel != null)
    }
    androidx.compose.runtime.DisposableEffect(Unit) {
        onDispose { onFullscreenPlaybackChanged(false) }
    }

    val favoriteMovies = remember(context, shelfVersion) { UserShelfStore.getFavoriteMovies(context) }
    val favoriteChannels = remember(context, shelfVersion) { UserShelfStore.getFavoriteChannels(context) }
    val continueWatching = remember(context, shelfVersion) { UserShelfStore.getContinueWatching(context) }
    val recentLiveChannels = remember(context, shelfVersion) { UserShelfStore.getRecentChannels(context) }

    if (selectedChannel != null) {
        // Fire realtime watch events to your panel while the live player is open.
        val watching = selectedChannel!!
        androidx.compose.runtime.LaunchedEffect(watching.streamId) {
            withContext(Dispatchers.IO) {
                PanelTelemetry.fireLiveTune(
                    context = context,
                    serverUrl = serverUrl,
                    username = username,
                    channel = watching,
                    streamUrl = watching.streamUrl
                )
            }

            // “Real time” heartbeat (keeps panel updated while they sit on the channel)
            while (isActive && selectedChannel?.streamId == watching.streamId) {
                delay(25_000)
                withContext(Dispatchers.IO) {
                    PanelTelemetry.fireLiveHeartbeat(
                        context = context,
                        serverUrl = serverUrl,
                        username = username,
                        channel = watching
                    )
                }
            }
        }

        BackHandler {
            val closing = selectedChannel
            selectedChannel = null
            sectionState.value = SidebarSection.LIVE
            liveTabState.value = LiveTab.CHANNELS
            val lastCat = selectedLiveCategoryIdState.value
            if (lastCat.isBlank()) {
                closing?.categoryId?.let { if (it.isNotBlank()) selectedLiveCategoryIdState.value = it }
            }

            // Optional: notify panel they stopped watching.
            if (closing != null) {
                scope.launch(Dispatchers.IO) {
                    PanelTelemetry.fireLiveStop(context, serverUrl, username, closing!!)
}
            }
        }
        CinematicPlayerOverlay(
            channel = selectedChannel!!,
            isLive = true,
            onClose = {
                val closing = selectedChannel
                selectedChannel = null
                sectionState.value = SidebarSection.LIVE
                liveTabState.value = LiveTab.CHANNELS

                if (closing != null) {
                    // Optional: notify panel they stopped watching.
                    scope.launch(Dispatchers.IO) {
                        PanelTelemetry.fireLiveStop(context, serverUrl, username, closing!!)
}
                }
            },
            liveAllChannels = liveTv.channels,
            liveCategories = liveTv.categories,
            liveCategoryId = selectedLiveCategoryIdState.value,
            onSelectCategory = { catId ->
                if (catId.isNotBlank()) selectedLiveCategoryIdState.value = catId
            },
            onTuneChannel = { ch ->
                openLiveChannel(ch)
            },
            onTunePreviousChannel = {
                tuneToPreviousLiveChannel()
            },
            onOpenMovie = { movie ->
                val closing = selectedChannel
                selectedChannel = null
                sectionState.value = SidebarSection.LIVE
                liveTabState.value = LiveTab.CHANNELS
                selectedMovie = SelectedMovieState(movie)
                if (closing != null) {
                    scope.launch(Dispatchers.IO) {
                        PanelTelemetry.fireLiveStop(context, serverUrl, username, closing)
                    }
                }
            }
        )
    } else if (selectedMovie != null) {
        val detailState = selectedMovie!!
        BackHandler { selectedMovie = null }
        TmdbDetailScreen(
            movie = detailState.movie,
            initialSeasonNumber = detailState.seasonNumber,
            initialEpisodeNumber = detailState.episodeNumber,
            isFavorite = UserShelfStore.isMovieFavorite(context, detailState.movie),
            onToggleFavorite = {
                UserShelfStore.toggleMovieFavorite(context, it)
                shelfVersion++
            },
            onRecordContinueWatching = { movie, seasonNumber, episodeNumber ->
                UserShelfStore.recordContinueWatching(context, movie, seasonNumber, episodeNumber)
                shelfVersion++
            },
            onBack = { selectedMovie = null },
            modifier = modifier
        )
    } else {
        HomeDashboard(
            trending = trending,
            popular = popular,
            topRated = topRated,
            latest = latest,
            recommended = (topRated + trending).distinctBy { "${it.mediaType}_${it.id}_${it.title}" },
            seriesTrending = trendingTv,
            seriesPopular = popularTv,
            seriesTopRated = topRatedTv,
            seriesOnTheAir = onTheAirTv,
            liveCategories = liveTv.categories,
            liveChannels = liveTv.channels,
            continueWatching = continueWatching,
            recentLiveChannels = recentLiveChannels.map { it.channel },
            favoriteMovies = favoriteMovies,
            favoriteLiveChannels = favoriteChannels,
            serverUrl = serverUrl,
            username = username,
            password = password,
            sectionState = sectionState,
            liveTabState = liveTabState,
            selectedLiveCategoryIdState = selectedLiveCategoryIdState,
            lastWatchedLiveStreamId = lastWatchedLiveStreamId,
            onRequestLiveChannels = { liveRequested = true; liveRefreshToken++ },
            onMovieClick = { selectedMovie = SelectedMovieState(it) },
            onContinueWatchingClick = { entry -> selectedMovie = SelectedMovieState(entry.movie, entry.seasonNumber, entry.episodeNumber) },
            onChannelClick = {
                openLiveChannel(it, rememberPrevious = selectedChannel != null)
            },
            isChannelFavorite = { UserShelfStore.isChannelFavorite(context, it) },
            onToggleChannelFavorite = {
                UserShelfStore.toggleChannelFavorite(context, it)
                shelfVersion++
            },
            onClearContinueWatching = {
                UserShelfStore.clearContinueWatching(context)
                shelfVersion++
            },
            onClearRecentChannels = {
                UserShelfStore.clearRecentChannels(context)
                shelfVersion++
            },
            onClearFavorites = {
                UserShelfStore.clearAllFavorites(context)
                shelfVersion++
            },
            onLogout = onLogout,
            modifier = modifier
        )
    }
}



private fun buildLiveStreamUrl(baseUrl: String, username: String, password: String, streamId: String): String {
    val root = baseUrl.trimEnd('/')
    // Default to MPEG-TS; many panels also support .m3u8 if you want HLS.
    return "$root/live/$username/$password/$streamId.ts"
}

@Composable
private fun rememberTmdbMovies(
    fetch: suspend () -> List<TmdbMovieResult>,
    mixYears: Boolean = false
): State<List<Movie>> {
    return produceState(initialValue = emptyList()) {
        value = try {
            withContext(Dispatchers.IO) {
                val items = fetch()
                    .map { it.toUiMovie() }
                    .filter { it.title.isNotBlank() && (it.posterUrl.isNotBlank() || it.backdropUrl.isNotBlank()) }
                    .distinctBy { "${it.mediaType}_${it.id}_${it.title}_${it.year}" }

                if (mixYears) {
                    mixMoviesYearRange(items, startYear = 2012, endYear = 2026, maxItems = 60)
                } else {
                    items
                }
            }
        } catch (_: Throwable) {
            emptyList()
        }
    }
}

private suspend fun fetchCombinedTmdbMovies(
    fetchPage: suspend (Int) -> TmdbListResponse,
    pages: Int = 1
): List<TmdbMovieResult> = coroutineScope {
    (1..pages).map { page -> async { fetchPage(page).results } }
        .awaitAll()
        .flatten()
}


private fun mixMoviesYearRange(
    items: List<Movie>,
    startYear: Int,
    endYear: Int,
    maxItems: Int
): List<Movie> {
    if (items.isEmpty()) return items
    val buckets = LinkedHashMap<Int, ArrayDeque<Movie>>()
    for (y in startYear..endYear) buckets[y] = ArrayDeque()

    val noYear = ArrayDeque<Movie>()
    val outOfRange = ArrayDeque<Movie>()

    for (m in items) {
        val y = m.year.toIntOrNull()
        when {
            y == null -> noYear.add(m)
            y in startYear..endYear -> buckets.getValue(y).add(m)
            else -> outOfRange.add(m)
        }
    }

    // Zig-zag year order: 2026,2012,2025,2013,...
    val yearOrder = ArrayList<Int>(endYear - startYear + 1)
    var lo = startYear
    var hi = endYear
    while (lo <= hi) {
        yearOrder.add(hi)
        if (lo != hi) yearOrder.add(lo)
        hi--
        lo++
    }

    val result = ArrayList<Movie>(minOf(maxItems, items.size))

    var added = true
    while (result.size < maxItems && added) {
        added = false
        for (y in yearOrder) {
            val q = buckets[y] ?: continue
            if (q.isNotEmpty()) {
                result.add(q.removeFirst())
                added = true
                if (result.size >= maxItems) break
            }
        }
    }

    // Fill remaining spots (if any) with whatever is left, still preferring in-range.
    if (result.size < maxItems) {
        for (y in yearOrder) {
            val q = buckets[y] ?: continue
            while (q.isNotEmpty() && result.size < maxItems) {
                result.add(q.removeFirst())
            }
            if (result.size >= maxItems) break
        }
    }
    while (noYear.isNotEmpty() && result.size < maxItems) result.add(noYear.removeFirst())
    while (outOfRange.isNotEmpty() && result.size < maxItems) result.add(outOfRange.removeFirst())

    return result
}

private fun TmdbMovieResult.toUiMovie(): Movie {
    val titleText = (title ?: name ?: "Untitled").trim()
    val yearText = (release_date ?: first_air_date)?.take(4)?.trim().orEmpty()
    val media = if (title.isNullOrBlank()) "tv" else "movie"

    return Movie(
        id = id ?: 0,
        title = titleText.ifBlank { "Untitled" },
        overview = overview?.trim().orEmpty(),
        posterUrl = TmdbImages.posterW500(poster_path),
        backdropUrl = TmdbImages.backdropW780(backdrop_path),
        year = yearText,
        rating = vote_average ?: 0.0,
        mediaType = media
    )
}


@Composable
private fun TmdbDetailScreen(
    movie: Movie,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    initialSeasonNumber: Int = 1,
    initialEpisodeNumber: Int = 1,
    isFavorite: Boolean = false,
    onToggleFavorite: (Movie) -> Unit = {},
    onRecordContinueWatching: (Movie, Int, Int) -> Unit = { _, _, _ -> }
) {
    var webViewUrl by remember { mutableStateOf<String?>(null) }
    var seasonNumber by remember(movie.id, initialSeasonNumber) { mutableStateOf(initialSeasonNumber.coerceAtLeast(1)) }
    var episodeNumber by remember(movie.id, initialEpisodeNumber) { mutableStateOf(initialEpisodeNumber.coerceAtLeast(1)) }

    val isTv = movie.mediaType.equals("tv", ignoreCase = true) || movie.mediaType.equals("series", ignoreCase = true)

    // TMDB metadata for seasons/episodes (TV only)
    val tvDetails by produceState<com.gamechanger.iptv.api.TmdbTvDetailsResponse?>(
        initialValue = null,
        key1 = movie.id,
        key2 = isTv
    ) {
        if (!isTv || movie.id <= 0) {
            value = null
            return@produceState
        }
        value = try {
            withContext(Dispatchers.IO) { ApiClient.tmdb().tvDetails(movie.id, Keys.TMDB_API_KEY) }
        } catch (_: Throwable) {
            null
        }
    }

    val seasons = remember(tvDetails) {
        tvDetails?.seasons
            ?.mapNotNull { s -> s.season_number?.let { sn -> sn to (s.name ?: "") } }
            ?.sortedBy { it.first }
            ?.toList()
            ?: emptyList()
    }

    // Keep selected season valid when metadata loads/changes
    androidx.compose.runtime.LaunchedEffect(isTv, seasons) {
        if (!isTv) return@LaunchedEffect
        val seasonNumbers = seasons.map { it.first }.toSet()
        if (seasonNumbers.isNotEmpty() && seasonNumber !in seasonNumbers) {
            // Prefer first non-special season if present
            val preferred = seasons.firstOrNull { it.first > 0 }?.first ?: seasons.first().first
            seasonNumber = preferred
            episodeNumber = 1
        }
    }

    val seasonDetails by produceState<com.gamechanger.iptv.api.TmdbSeasonDetailsResponse?>(
        initialValue = null,
        key1 = movie.id,
        key2 = seasonNumber,
        key3 = isTv
    ) {
        if (!isTv || movie.id <= 0) {
            value = null
            return@produceState
        }
        value = try {
            withContext(Dispatchers.IO) { ApiClient.tmdb().seasonDetails(movie.id, seasonNumber, Keys.TMDB_API_KEY) }
        } catch (_: Throwable) {
            null
        }
    }

    val episodeMax = remember(seasonDetails, tvDetails, seasonNumber) {
        val fromDetails = seasonDetails?.episodes?.size ?: 0
        if (fromDetails > 0) return@remember fromDetails
        val seasonSummary = tvDetails?.seasons?.firstOrNull { it.season_number == seasonNumber }
        seasonSummary?.episode_count ?: 1
    }

    // Clamp episode within range when metadata loads
    androidx.compose.runtime.LaunchedEffect(isTv, seasonNumber, episodeMax) {
        if (!isTv) return@LaunchedEffect
        if (episodeNumber < 1) episodeNumber = 1
        if (episodeNumber > episodeMax) episodeNumber = episodeMax
    }

    val episodePicks = remember(seasonDetails, episodeMax) {
        val eps = seasonDetails?.episodes
            ?.mapNotNull { e -> e.episode_number }
            ?.sorted()
            ?: (1..episodeMax).toList()
        // show at most 30 buttons; stepper still works for higher numbers
        eps.take(30)
    }


    val playbackConfig by produceState(
    initialValue = PlaybackConfig(emptyList(), 0),
    key1 = SERVERS_JSON_URL,
    key2 = movie.mediaType
) {
    value = try {
        withContext(Dispatchers.IO) { fetchPlaybackConfigV3(SERVERS_JSON_URL, movie.mediaType) }
    } catch (t: Throwable) {
        PlaybackConfig(emptyList(), 0, t.message ?: t::class.java.simpleName)
    }
}

val servers = playbackConfig.servers


	// Always default to Player 1 (first server in servers.json)
	var selectedServerIndex by remember { mutableStateOf(0) }
	androidx.compose.runtime.LaunchedEffect(servers.size) {
	    selectedServerIndex = 0
	}

    val selectedServer = servers.getOrNull(selectedServerIndex)

    Box(modifier = modifier.fillMaxSize().background(Color.Black)) {
        AsyncImage(
            model = movie.backdropUrl.ifBlank { movie.posterUrl },
            contentDescription = movie.title,
            modifier = Modifier
                .fillMaxWidth()
                .height(520.dp)
                .alpha(0.68f),
            contentScale = ContentScale.Crop
        )

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color.Transparent, Color(0xCC000000), Color.Black),
                        startY = 180f
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(42.dp)
        ) {
		    TvActionButton(text = "Back", onClick = onBack)

            Spacer(Modifier.height(28.dp))

            Row(
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                AsyncImage(
                    model = movie.posterUrl.ifBlank { movie.backdropUrl },
                    contentDescription = movie.title,
                    modifier = Modifier
                        .width(240.dp)
                        .height(360.dp),
                    contentScale = ContentScale.Crop
                )

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = movie.title,
                        color = Color.White,
                        style = MaterialTheme.typography.displaySmall,
                        fontWeight = FontWeight.Black
                    )

                    Spacer(Modifier.height(12.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                        if (movie.year.isNotBlank()) {
                            Text(
                                text = movie.year,
                                color = Color(0xFFD0D0D0),
                                style = MaterialTheme.typography.titleMedium
                            )
                        }
                        Text(
                            text = if (movie.mediaType.equals("tv", ignoreCase = true)) "SERIES" else "MOVIE",
                            color = Color(0xFF00FFFF),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        if (movie.rating > 0.0) {
                            Text(
                                text = "⭐ %.1f".format(movie.rating),
                                color = Color.White,
                                style = MaterialTheme.typography.titleMedium
                            )
                        }
                    }

                    Spacer(Modifier.height(22.dp))

                    Text(
                        text = if (movie.overview.isNotBlank()) movie.overview else "No TMDB overview available.",
                        color = Color(0xFFE4E4E4),
                        style = MaterialTheme.typography.bodyLarge
                    )

                    Spacer(Modifier.height(18.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        TvActionButton(
                            text = if (isFavorite) "REMOVE FAVORITE" else "ADD FAVORITE",
                            onClick = { onToggleFavorite(movie) }
                        )
                    }


playbackConfig.error?.let { err ->
    Spacer(Modifier.height(10.dp))
    Text(
        text = "servers.json error: $err",
        color = Color(0xFFFFC107),
        style = MaterialTheme.typography.bodyMedium
    )
}


if (isTv) {
    Spacer(Modifier.height(14.dp))

    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = Color(0x66000000),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(
                text = "Season",
                color = Color.White,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(8.dp))

            if (seasons.isEmpty()) {
                Text(
                    text = "No TMDB season metadata available.",
                    color = Color(0xFFFFC107),
                    style = MaterialTheme.typography.bodyMedium
                )
            } else {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(seasons) { (sn, _) ->
                        CompactPill(
                            text = "S$sn",
                            selected = sn == seasonNumber,
                            onClick = {
                                seasonNumber = sn
                                episodeNumber = 1
                            }
                        )
                    }
                }

                val seasonName = seasons.firstOrNull { it.first == seasonNumber }?.second.orEmpty()
                if (seasonName.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = seasonName,
                        color = Color(0xFFBDBDBD),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            Spacer(Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Episode",
                    color = Color.White,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    CompactPill(
                        text = "◀",
                        selected = false,
                        enabled = episodeNumber > 1
                    ) { if (episodeNumber > 1) episodeNumber -= 1 }

                    Spacer(Modifier.width(10.dp))

                    Text(
                        text = "E$episodeNumber / $episodeMax",
                        color = Color.White,
                        style = MaterialTheme.typography.titleMedium
                    )

                    Spacer(Modifier.width(10.dp))

                    CompactPill(
                        text = "▶",
                        selected = false,
                        enabled = episodeNumber < episodeMax
                    ) { if (episodeNumber < episodeMax) episodeNumber += 1 }
                }
            }

            if (episodeMax > 0) {
                Spacer(Modifier.height(10.dp))
                EpisodeGrid(
                    selectedEpisode = episodeNumber,
                    episodeMax = episodeMax,
                    onSelect = { episodeNumber = it }
                )
            }
        }
    }
}


                    if (servers.isNotEmpty()) {
                        Spacer(Modifier.height(18.dp))

                        Text(
                            text = "Servers",
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )

                        Spacer(Modifier.height(10.dp))

                        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            items(servers) { s ->
                                CategoryPill(
                                    text = s.name,
                                    selected = s == selectedServer,
                                    onClick = { selectedServerIndex = servers.indexOf(s) }
                                )
                            }
                        }
                    }
                    else {
                        Spacer(Modifier.height(14.dp))
                        Text(
                            text = "No servers loaded from servers.json",
                            color = Color(0xFFFFC107),
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }

                    Spacer(Modifier.height(18.dp))

                    val playUrl = buildWebViewUrl(selectedServer?.webViewTemplate.orEmpty(), movie, seasonNumber, episodeNumber)
                    val canPlay = playUrl.isNotBlank()

		            TvActionButton(
		                text = "PLAY",
		                enabled = canPlay,
		                onClick = {
                            onRecordContinueWatching(movie, seasonNumber, episodeNumber)
		                    Log.d("Playback", "Loading: $playUrl")
		                    webViewUrl = playUrl
		                }
		            )
                }
            }

            Spacer(Modifier.size(24.dp))
        }

        if (webViewUrl != null) {
            WebViewOverlay(url = webViewUrl!!, onClose = { webViewUrl = null })
        }
    }
}



private fun copyToClipboard(context: Context, label: String, text: String) {
    try {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(label, text))
        Toast.makeText(context, "$label copied", Toast.LENGTH_SHORT).show()
    } catch (_: Throwable) {
        // no-op
    }
}

private class WebDebugBridge(
    private val context: Context,
    private val requestLog: CopyOnWriteArrayList<String>
) {
    @JavascriptInterface
    fun copyUrl(url: String) {
        copyToClipboard(context, "URL", url)
    }

    @JavascriptInterface
    fun copyRequests() {
        copyToClipboard(context, "Requests", requestLog.joinToString("\n"))
    }
}

private class TvCursorView(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = AndroidColor.WHITE
        style = Paint.Style.FILL
        alpha = 235
    }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = AndroidColor.BLACK
        style = Paint.Style.STROKE
        strokeWidth = (2f * d).coerceAtLeast(2f)
        alpha = 210
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val r = (minOf(width, height) / 2f) - stroke.strokeWidth
        if (r <= 0f) return
        canvas.drawCircle(cx, cy, r, fill)
        canvas.drawCircle(cx, cy, r, stroke)

    }
}


private class TvCursorController(
    private val root: FrameLayout,
    private val cursor: View,
    private val webView: WebView,
    cursorSizePx: Int,
    density: Float
) {
    private val step = 26f * density
    private val edgeZone = 38f * density
    private val scrollStep = (54f * density).toInt().coerceAtLeast(24)
    private val halfSize = cursorSizePx / 2f

    var x: Float = 0f
    var y: Float = 0f
    var isFullscreen: Boolean = false

    private val hideDelayMs = 3000L
    private val handler = Handler(Looper.getMainLooper())
    private val hideRunnable = Runnable {
        cursor.visibility = View.GONE
    }

    private fun scheduleHide() {
        handler.removeCallbacks(hideRunnable)
        handler.postDelayed(hideRunnable, hideDelayMs)
    }


    private fun clamp() {
        val w = root.width.toFloat().coerceAtLeast(1f)
        val h = root.height.toFloat().coerceAtLeast(1f)
        x = x.coerceIn(0f, w)
        y = y.coerceIn(0f, h)
    }

    private fun place() {
        clamp()
        cursor.translationX = x - halfSize
        cursor.translationY = y - halfSize
        cursor.bringToFront()
    }
    fun show() {
        cursor.visibility = View.VISIBLE
        cursor.bringToFront()
        scheduleHide()
    }

    fun hideNow() {
        handler.removeCallbacks(hideRunnable)
        cursor.visibility = View.GONE
    }

    fun dispose() {
        handler.removeCallbacks(hideRunnable)
    }

    fun initCenter() {
        x = root.width / 2f
        y = root.height / 2f
        place()
        sendHoverEnter()
        sendHoverMove()
    }

    private fun obtainMouseEvent(
        action: Int,
        downTime: Long,
        eventTime: Long,
        x: Float,
        y: Float,
        buttonState: Int = 0
    ): MotionEvent {
        val pp = arrayOf(MotionEvent.PointerProperties().apply {
            id = 0
            toolType = MotionEvent.TOOL_TYPE_MOUSE
        })
        val pc = arrayOf(MotionEvent.PointerCoords().apply {
            this.x = x
            this.y = y
            pressure = 1f
            size = 1f
        })
        return MotionEvent.obtain(
            downTime,
            eventTime,
            action,
            1,
            pp,
            pc,
            0,
            buttonState,
            1f,
            1f,
            0,
            0,
            InputDevice.SOURCE_MOUSE,
            0
        )
    }


    private fun obtainTouchEvent(
        action: Int,
        downTime: Long,
        eventTime: Long,
        x: Float,
        y: Float
    ): MotionEvent {
        val pp = arrayOf(MotionEvent.PointerProperties().apply {
            id = 0
            toolType = MotionEvent.TOOL_TYPE_FINGER
        })
        val pc = arrayOf(MotionEvent.PointerCoords().apply {
            this.x = x
            this.y = y
            pressure = 1f
            size = 1f
        })
        return MotionEvent.obtain(
            downTime,
            eventTime,
            action,
            1,
            pp,
            pc,
            0,
            0,
            1f,
            1f,
            0,
            0,
            InputDevice.SOURCE_TOUCHSCREEN,
            0
        )
    }

    fun sendHoverEnter() {
        val t = SystemClock.uptimeMillis()
        val ev = obtainMouseEvent(MotionEvent.ACTION_HOVER_ENTER, t, t, x, y)
        runCatching { webView.dispatchGenericMotionEvent(ev) }
        ev.recycle()
    }

    fun sendHoverMove() {
        val t = SystemClock.uptimeMillis()
        val ev = obtainMouseEvent(MotionEvent.ACTION_HOVER_MOVE, t, t, x, y)
        runCatching { webView.dispatchGenericMotionEvent(ev) }
        ev.recycle()
    }

    fun click() {
        runCatching { webView.requestFocus() }
        runCatching { webView.requestFocusFromTouch() }

        val downTime = SystemClock.uptimeMillis()

        // Touch click (needed for most WebView element selection / focusing)
        val downTouch = obtainTouchEvent(MotionEvent.ACTION_DOWN, downTime, downTime, x, y)
        val upTouch = obtainTouchEvent(MotionEvent.ACTION_UP, downTime, downTime + 12, x, y)
        runCatching { webView.dispatchTouchEvent(downTouch) }
        runCatching { webView.dispatchTouchEvent(upTouch) }
        downTouch.recycle(); upTouch.recycle()

        // Mouse-style fallback (some embedded players behave better with mouse input)
        val downMouse = obtainMouseEvent(MotionEvent.ACTION_DOWN, downTime, downTime, x, y, MotionEvent.BUTTON_PRIMARY)
        val upMouse = obtainMouseEvent(MotionEvent.ACTION_UP, downTime, downTime + 12, x, y, 0)
        runCatching { webView.dispatchTouchEvent(downMouse) }
        runCatching { webView.dispatchTouchEvent(upMouse) }
        downMouse.recycle(); upMouse.recycle()
    }

    fun moveLeft() {
        show()
        x -= step
        place()
        sendHoverMove()
    }

    fun moveRight() {
        show()
        x += step
        place()
        sendHoverMove()
    }

    fun moveUp() {
        show()
        if (y > 0f) {
            y -= step
            if (y < 0f) y = 0f
        } else {
            webView.scrollBy(0, -scrollStep)
        }
        place()
        sendHoverMove()
    }

    fun moveDown() {
        show()
        val h = root.height.toFloat().coerceAtLeast(1f)
        val maxY = (h - 1f).coerceAtLeast(0f)
        if (y < maxY) {
            y += step
            if (y > maxY) y = maxY
        } else {
            webView.scrollBy(0, scrollStep)
        }
        place()
        sendHoverMove()
    }

}

@Composable
private fun WebViewOverlay(
    url: String,
    onClose: () -> Unit
) {
    BackHandler(onBack = onClose)

    val context = LocalContext.current
    val requestLog = remember { CopyOnWriteArrayList<String>() }
    var currentUrl by remember(url) { mutableStateOf(url) }
    val webViewRef = remember { mutableStateOf<WebView?>(null) }
    val cursorControllerRef = remember { mutableStateOf<TvCursorController?>(null) }

    val focusRequester = remember { FocusRequester() }

    androidx.compose.runtime.LaunchedEffect(Unit) {
        // Make sure DPAD events land on the WebView container so the TV cursor works.
        focusRequester.requestFocus()
    }

    // Clear app/webview cache on ENTER
    androidx.compose.runtime.LaunchedEffect(url) {
        withContext(Dispatchers.IO) {
            CacheCleaner.clearAppCache(context)
        }
        CacheCleaner.clearWebViewGlobalStorage()
    }

    // Clear app/webview cache on EXIT
    androidx.compose.runtime.DisposableEffect(Unit) {
        onDispose {
            webViewRef.value?.let { wv ->
                CacheCleaner.clearWebViewGlobalStorage()
                CacheCleaner.clearWebViewInstance(wv)
                runCatching { (wv.parent as? ViewGroup)?.removeView(wv) }
                runCatching { wv.destroy() }
                webViewRef.value = null
            }
            runCatching { CacheCleaner.clearAppCache(context) }
        }
    }


    var isLoading by remember { mutableStateOf(true) }
    var loadError by remember { mutableStateOf<String?>(null) }

    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { ctx ->
                val root = FrameLayout(ctx)

                // TV cursor overlay (DPAD moves it; OK clicks)
                val density = ctx.resources.displayMetrics.density
                val cursorSizePx = (18f * density).toInt().coerceAtLeast(14)
                val cursor = TvCursorView(ctx).apply {
                    isClickable = false
                    isFocusable = false
                    visibility = View.VISIBLE
					tag = "GC_TV_CURSOR"
					// Keep the cursor above the WebView (some devices ignore z-order without elevation)
					elevation = 999f
                }
                val cursorLp = FrameLayout.LayoutParams(cursorSizePx, cursorSizePx).apply {
                    gravity = Gravity.TOP or Gravity.START
                }

                // Cursor stays visible on TV (DPAD drives it).

                var cursorX = 0f
                var cursorY = 0f
                fun clampAndPlaceCursor() {
                    val w = root.width.toFloat().coerceAtLeast(1f)
                    val h = root.height.toFloat().coerceAtLeast(1f)
                    cursorX = cursorX.coerceIn(0f, w)
                    cursorY = cursorY.coerceIn(0f, h)
                    cursor.translationX = cursorX - (cursorSizePx / 2f)
                    cursor.translationY = cursorY - (cursorSizePx / 2f)
                }

                                fun obtainMouseEvent(action: Int, downTime: Long, eventTime: Long, x: Float, y: Float, buttonState: Int = 0): MotionEvent {
                    val pp = arrayOf(MotionEvent.PointerProperties().apply {
                        id = 0
                        toolType = MotionEvent.TOOL_TYPE_MOUSE
                    })
                    val pc = arrayOf(MotionEvent.PointerCoords().apply {
                        this.x = x
                        this.y = y
                        pressure = 1f
                        size = 1f
                    })
                    return MotionEvent.obtain(
                        downTime,
                        eventTime,
                        action,
                        1,
                        pp,
                        pc,
                        0,
                        buttonState,
                        1f,
                        1f,
                        0,
                        0,
                        InputDevice.SOURCE_MOUSE,
                        0
                    )
                }

                fun sendHoverEnter(webView: WebView) {
                    val t = SystemClock.uptimeMillis()
                    val ev = obtainMouseEvent(MotionEvent.ACTION_HOVER_ENTER, t, t, cursorX, cursorY)
                    runCatching { webView.dispatchGenericMotionEvent(ev) }
                    ev.recycle()
                }

                fun sendHoverMove(webView: WebView) {
                    val t = SystemClock.uptimeMillis()
                    val ev = obtainMouseEvent(MotionEvent.ACTION_HOVER_MOVE, t, t, cursorX, cursorY)
                    runCatching { webView.dispatchGenericMotionEvent(ev) }
                    ev.recycle()
                }

				fun clickAtCursor(webView: WebView) {
					val downTime = SystemClock.uptimeMillis()
					// Mouse-style click for TV WebView (some players ignore touchscreen events).
					val down = obtainMouseEvent(MotionEvent.ACTION_DOWN, downTime, downTime, cursorX, cursorY, MotionEvent.BUTTON_PRIMARY)
					val up = obtainMouseEvent(MotionEvent.ACTION_UP, downTime, downTime + 12, cursorX, cursorY, 0)
					runCatching { webView.dispatchTouchEvent(down) }
					runCatching { webView.dispatchTouchEvent(up) }
					down.recycle(); up.recycle()
				}


                val webView = WebView(ctx).apply {
                    // Keep a reference for cleanup
                    webViewRef.value = this

                    // Clear WebView cache/storage before loading (ENTER)
                    CacheCleaner.clearWebViewGlobalStorage()
                    CacheCleaner.clearWebViewInstance(this)

                    // Prevent "black rectangle" issues with video surfaces in some WebView/Compose setups
                    setBackgroundColor(AndroidColor.TRANSPARENT)
                    isVerticalScrollBarEnabled = false
                    isHorizontalScrollBarEnabled = false
                    setLayerType(View.LAYER_TYPE_HARDWARE, null)

                    // Allow selecting/clicking elements reliably (TV + touch injection)
                    isFocusable = true
                    isFocusableInTouchMode = true
                    isClickable = true
                    isLongClickable = true
                    setOnLongClickListener { false }

                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.mediaPlaybackRequiresUserGesture = false
                    settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                    settings.useWideViewPort = true
                    settings.loadWithOverviewMode = true
                    settings.javaScriptCanOpenWindowsAutomatically = true
                    settings.setSupportMultipleWindows(true)

                    // Many embedded players need cookies + a normal UA
                    settings.userAgentString =
                        "Mozilla/5.0 (Linux; Android 12; Android TV) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

                    CookieManager.getInstance().setAcceptCookie(true)
                    CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)

                    // Debug helpers (adds in-page copy buttons)
                    addJavascriptInterface(WebDebugBridge(ctx, requestLog), "GC")

                    webViewClient = object : WebViewClient() {
                        override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                            super.onPageStarted(view, url, favicon)
                            isLoading = true
                            loadError = null
                        }

                        override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                            super.onReceivedError(view, request, error)
                            if (request.isForMainFrame) {
                                isLoading = false
                                loadError = "Web error: ${error.errorCode} ${error.description}"
                            }
                        }

                        override fun onReceivedSslError(view: WebView, handler: android.webkit.SslErrorHandler, error: android.net.http.SslError) {
                            // Don't proceed; surface the error so it's obvious it's SSL/cert related.
                            isLoading = false
                            loadError = "SSL error: ${error.primaryError} (certificate not trusted)"
                            handler.cancel()
                        }

                        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                            val u = request.url
                            try {
                                if (u.scheme == "http" || u.scheme == "https") {
                                    val s = u.toString()
                                    if (s.isNotBlank()) {
                                        if (requestLog.isEmpty() || requestLog.last() != s) requestLog.add(s)
                                        if (requestLog.size > 200) requestLog.removeAt(0)
                                    }
                                }
                            } catch (_: Throwable) {}
                            // Chromium sometimes requests a special internal poster URL; returning a 204 removes noisy CORS failures.
                            if (u.scheme == "view-video-poster") {
                                return WebResourceResponse(
                                    "text/plain",
                                    "utf-8",
                                    204,
                                    "No Content",
                                    mapOf(
                                        "Access-Control-Allow-Origin" to "*",
                                        "Access-Control-Allow-Methods" to "GET, OPTIONS",
                                        "Access-Control-Allow-Headers" to "*",
                                        "Access-Control-Max-Age" to "86400"
                                    ),
                                    ByteArrayInputStream(ByteArray(0))
                                )
                            }
                            return super.shouldInterceptRequest(view, request)
                        }

                        override fun onPageFinished(view: WebView, url: String) {
                            super.onPageFinished(view, url)
                            currentUrl = url
                            isLoading = false

                            // Inject a small debug UI into the page to copy the current URL / request list.
                            val js = """(function() {
                                try {
                                  // Patch fetch for internal poster scheme noise
                                  const origFetch = window.fetch;
                                  if (origFetch) {
                                    window.fetch = function(input, init) {
                                      try {
                                        const u = (typeof input === 'string') ? input : (input && input.url ? input.url : '');
                                        if (u && u.startsWith('view-video-poster:')) {
                                          return Promise.resolve(new Response('', {status: 204}));
                                        }
                                      } catch (e) {}
                                      return origFetch.apply(this, arguments);
                                    };
                                  }
                                } catch (e) {}
                              })();"""
                            view.evaluateJavascript(js, null)
                        }
                    }
                }

                val controller = TvCursorController(root, cursor, webView, cursorSizePx, density).also {
                    cursorControllerRef.value = it
                }

                root.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
                    override fun onViewAttachedToWindow(v: View) {}
                    override fun onViewDetachedFromWindow(v: View) {
                        controller.dispose()
                    }
                })


                // Fullscreen HTML5 video support (many players use this)
                var customView: View? = null
                var customCallback: WebChromeClient.CustomViewCallback? = null

                webView.webChromeClient = object : WebChromeClient() {
                    override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                        if (view == null) return
                        // Remove any existing fullscreen view
                        customView?.let { root.removeView(it) }

                        customView = view
                        customCallback = callback
                        controller.isFullscreen = true

                        webView.visibility = View.GONE
                        controller.hideNow()
                        root.addView(
                            view,
                            FrameLayout.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                        )
                    }

                    override fun onHideCustomView() {
                        customView?.let { root.removeView(it) }
                        customView = null
                        webView.visibility = View.VISIBLE
                        controller.isFullscreen = false
                        controller.show()
                        controller.sendHoverEnter()
                        controller.sendHoverMove()
                        customCallback?.onCustomViewHidden()
                        customCallback = null
                    }
                }

                root.addView(
                    webView,
                    FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                )

				// Cursor MUST be added after the WebView so it stays visible on top.
				root.addView(cursor, cursorLp)
				cursor.bringToFront()

                // Store webview for update() and for future debugging
                root.tag = webView

                // Keep focus on the root so DPAD drives the cursor on TVs
                root.isFocusable = true
                root.isFocusableInTouchMode = true
                root.descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
                root.requestFocus()

                root.onFocusChangeListener = View.OnFocusChangeListener { v, hasFocus ->
                    if (!hasFocus) runCatching { v.requestFocus() }
                }
                // Initialize cursor position once layout is known
                root.post {
                    controller.initCenter()
                    controller.show()
                }

                val step = 26f * density
                val edgeZone = 38f * density
                val scrollStep = (54f * density).toInt().coerceAtLeast(24)

                
webView.setOnKeyListener { _, keyCode, event ->
                    if (event.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false

                    // If fullscreen custom view is showing, don't drive cursor/clicks.
                    if (customView != null || controller.isFullscreen) return@setOnKeyListener false

                    when (keyCode) {
                        KeyEvent.KEYCODE_DPAD_LEFT -> { controller.moveLeft(); true }
                        KeyEvent.KEYCODE_DPAD_RIGHT -> { controller.moveRight(); true }
                        KeyEvent.KEYCODE_DPAD_UP -> { controller.moveUp(); true }
                        KeyEvent.KEYCODE_DPAD_DOWN -> { controller.moveDown(); true }
                        KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> { controller.show(); controller.click(); true }
                        else -> false
                    }
                }


root.setOnKeyListener { _, keyCode, event ->
                    if (event.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false

                    // If fullscreen custom view is showing, don't drive cursor/clicks.
                    if (customView != null || controller.isFullscreen) return@setOnKeyListener false

                    when (keyCode) {
                        KeyEvent.KEYCODE_DPAD_LEFT -> { controller.moveLeft(); true }
                        KeyEvent.KEYCODE_DPAD_RIGHT -> { controller.moveRight(); true }
                        KeyEvent.KEYCODE_DPAD_UP -> { controller.moveUp(); true }
                        KeyEvent.KEYCODE_DPAD_DOWN -> { controller.moveDown(); true }
                        KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> { controller.show(); controller.click(); true }
                        else -> false
                    }
                }

                webView.loadUrl(url)
                root
            },
            update = { root ->
                val webView = root.tag as? WebView
                if (webView != null && webView.url != url) webView.loadUrl(url)
				// Keep DPAD focus driving the cursor on TVs.
				runCatching { root.requestFocus() }
				runCatching { (root.findViewWithTag<View>("GC_TV_CURSOR"))?.bringToFront() }
            },
            
            modifier = Modifier
                    .fillMaxSize()
                    .focusRequester(focusRequester)
                    .focusable()
                    .onPreviewKeyEvent { ev ->
                        if (ev.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                        val controller = cursorControllerRef.value ?: return@onPreviewKeyEvent false
                        if (controller.isFullscreen) return@onPreviewKeyEvent false
                        when (ev.nativeKeyEvent.keyCode) {
                            KeyEvent.KEYCODE_DPAD_LEFT -> { controller.moveLeft(); true }
                            KeyEvent.KEYCODE_DPAD_RIGHT -> { controller.moveRight(); true }
                            KeyEvent.KEYCODE_DPAD_UP -> { controller.moveUp(); true }
                            KeyEvent.KEYCODE_DPAD_DOWN -> { controller.moveDown(); true }
                            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> { controller.show(); controller.click(); true }
                            else -> false
                        }
                    }
                    .onFocusChanged {
                        if (!it.isFocused) runCatching { focusRequester.requestFocus() }
                    }
        )
        if (isLoading) {
            CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
        }
        loadError?.let { err ->
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(24.dp)
                    .background(Color(0xAA000000), shape = RoundedCornerShape(12.dp))
                    .padding(16.dp)
            ) {
                Text(text = err, color = Color.White)
                Spacer(modifier = Modifier.height(12.dp))
                TvPillButton(
                    text = "Copy Error",
                    onClick = { copyToClipboard(context, "WebView Error", err) }
                )
            }
        }




    }
}

@Composable
private fun TvActionButton(
    text: String,
    enabled: Boolean = true,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    TvPillButton(
        text = text,
        onClick = onClick,
        enabled = enabled,
        modifier = modifier
    )
}

@Composable
private fun CompactPill(
    text: String,
    selected: Boolean,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    var isFocused by remember { mutableStateOf(false) }
    val interactionSource = remember { MutableInteractionSource() }
    val active = enabled && (selected || isFocused)

    Box(
        modifier = Modifier
            .height(34.dp)
            .widthIn(min = 46.dp)
            .onFocusChanged { isFocused = it.isFocused }
            .focusable(enabled = enabled, interactionSource = interactionSource)
            .clickable(
                enabled = enabled,
                interactionSource = interactionSource,
                indication = null
            ) { onClick() }
            .background(
                if (active) Color(0x3319B7FF) else Color(0x22000000),
                RoundedCornerShape(999.dp)
            )
            .border(
                1.dp,
                if (active) Color.Cyan else Color(0x22FFFFFF),
                RoundedCornerShape(999.dp)
            )
            .padding(horizontal = 10.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = if (enabled) {
                if (active) Color.White else Color(0xFFB0B0B0)
            } else {
                Color(0xFF666666)
            },
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
private fun EpisodeGrid(
    selectedEpisode: Int,
    episodeMax: Int,
    onSelect: (Int) -> Unit
) {
    val columns = 8
    val pageSize = 40

    val safeMax = episodeMax.coerceAtLeast(0)
    if (safeMax <= 0) return

    val page = ((selectedEpisode - 1).coerceAtLeast(0) / pageSize)
    val start = page * pageSize + 1
    val end = minOf(start + pageSize - 1, safeMax)

    val episodes = (start..end).toList()
    val rows = ((episodes.size + columns - 1) / columns).coerceAtLeast(1)
    val cellHeight = 34
    val spacing = 10
    val gridHeight = (rows * cellHeight + (rows - 1) * spacing).dp

    Column {
        if (safeMax > pageSize) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "E$start–E$end",
                    color = Color(0xFFBDBDBD),
                    style = MaterialTheme.typography.bodyMedium
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CompactPill(
                        text = "Prev",
                        selected = false,
                        enabled = start > 1
                    ) { onSelect((start - pageSize).coerceAtLeast(1)) }

                    Spacer(Modifier.width(10.dp))

                    CompactPill(
                        text = "Next",
                        selected = false,
                        enabled = end < safeMax
                    ) { onSelect((start + pageSize).coerceAtMost(safeMax)) }
                }
            }
            Spacer(Modifier.height(10.dp))
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(columns),
            modifier = Modifier
                .fillMaxWidth()
                .height(gridHeight),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            userScrollEnabled = false
        ) {
            items(episodes) { ep ->
                CompactPill(
                    text = "E$ep",
                    selected = ep == selectedEpisode,
                    onClick = { onSelect(ep) }
                )
            }
        }
    }
}



private fun applyEmbedCompatIfNeeded(url: String): String {
    return try {
        val uri = Uri.parse(url)
        val host = uri.host?.lowercase().orEmpty()
        if (host != "realmovie.who.what.who" && host != "realmovie1.who.what.who") return url

        val path = uri.encodedPath ?: return url
        if (path.startsWith("")) return url

        // If the server exposes /embed/movie/... and /embed/tv/..., prefer that lightweight route.
        val shouldEmbed = path.startsWith("/movie/") || path.startsWith("/tv/")
        if (!shouldEmbed) return url

        uri.buildUpon()
            .encodedPath("/embed$path")
            .build()
            .toString()
    } catch (_: Throwable) {
        url
    }
}

private fun buildWebViewUrl(template: String, movie: Movie, seasonNumber: Int, episodeNumber: Int): String {
    val t = template.trim()
    if (t.isBlank()) return ""

    val tmdbId = movie.id.toString()
    val mediaType = movie.mediaType
    val seasonStr = seasonNumber.toString()
    val episodeStr = episodeNumber.toString()

    var out = t
        // id tokens
        .replace("{id}", tmdbId)
        .replace("{tmdbId}", tmdbId)
        .replace("{tmdb_id}", tmdbId)
        .replace("{tmdb}", tmdbId)
        .replace("\${mi}", tmdbId)
        .replace("\${mt}", mediaType)
        .replace("\${si}", seasonStr)
        // media tokens
        .replace("{type}", mediaType)
        .replace("{mediaType}", mediaType)
        .replace("{media_type}", mediaType)
        // tv tokens
        .replace("{season}", seasonStr)
        .replace("{season_number}", seasonStr)
        .replace("\${season}", seasonStr)
        .replace("{episode}", episodeStr)
        .replace("{episode_number}", episodeStr)
        .replace("\${episode}", episodeStr)

    // Keep it simple and safe: only allow http(s)
    out = out.trim()
    return if (out.startsWith("http://") || out.startsWith("https://")) applyEmbedCompatIfNeeded(out) else ""
}

private fun fetchPlaybackConfigV3(url: String, mediaTypeRaw: String): PlaybackConfig {
    val endpoint = url.trim()
    if (endpoint.isBlank()) return PlaybackConfig(emptyList(), 0, "servers.json url is blank")

    val client = OkHttpClient.Builder().build()
    val req = Request.Builder()
        .url(endpoint)
        .header("Accept", "application/json")
        .header(
            "User-Agent",
            "Mozilla/5.0 (Linux; Android 12; Android TV) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        )
        .build()

    client.newCall(req).execute().use { resp ->
        if (!resp.isSuccessful) {
            return PlaybackConfig(emptyList(), 0, "HTTP ${resp.code}")
        }

        val body = resp.body?.string().orEmpty().trim()
        if (body.isBlank()) return PlaybackConfig(emptyList(), 0, "Empty body")

        val tok = try { JSONTokener(body).nextValue() } catch (_: Throwable) {
            return PlaybackConfig(emptyList(), 0, "Invalid JSON")
        }

        val mediaType = mediaTypeRaw.trim().lowercase()
        val isTv = mediaType == "tv" || mediaType == "series"

        fun safeUrl(s: String): String {
            val t = s.trim()
            return if (t.startsWith("http://") || t.startsWith("https://")) t else ""
        }

        // v3 schema: { defaults: { movieServerIndex, tvServerIndex }, movieServers: [...], tvServers: [...] }
        if (tok is JSONObject) {
            val defaults = tok.optJSONObject("defaults")
            val rawIndex = if (isTv) defaults?.optInt("tvServerIndex", 1) ?: 1 else defaults?.optInt("movieServerIndex", 1) ?: 1
            val arr = if (isTv) tok.optJSONArray("tvServers") else tok.optJSONArray("movieServers")
            if (arr != null) {
                val servers = ArrayList<PlaybackServer>(arr.length())
                val seen = HashSet<String>()
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    val name = obj.optString("name").trim()
                    if (name.isBlank() || !seen.add(name)) continue
                    val template = safeUrl(obj.optString("template").ifBlank { obj.optString("webViewTemplate") })
                    if (template.isBlank()) continue
                    servers.add(PlaybackServer(name = name, webViewTemplate = template))
                }

                val defaultIndex = when {
                    servers.isEmpty() -> 0
                    rawIndex in 0 until servers.size -> rawIndex
                    rawIndex in 1..servers.size -> rawIndex - 1
                    else -> 0
                }
                return PlaybackConfig(servers, defaultIndex, if (servers.isEmpty()) "No servers in JSON" else null)
            }
        }

        // fallback: old schema with an array at root or {servers:[...]} or {data:[...]}
        val arr: JSONArray = when (tok) {
            is JSONArray -> tok
            is JSONObject -> {
                when {
                    tok.opt("servers") is JSONArray -> tok.getJSONArray("servers")
                    tok.opt("data") is JSONArray -> tok.getJSONArray("data")
                    else -> return PlaybackConfig(emptyList(), 0, "Unsupported servers.json schema")
                }
            }
            else -> return PlaybackConfig(emptyList(), 0, "Unsupported servers.json schema")
        }

        val servers = ArrayList<PlaybackServer>(arr.length())
        val seen = HashSet<String>()

        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue

            val name = firstString(obj, "name", "title", "label", "server")?.trim().orEmpty()
            if (name.isBlank()) continue
            if (!seen.add(name)) continue

            val template = firstString(
                obj,
                "webViewTemplate",
                "webviewTemplate",
                "template",
                "playTemplate",
                "playUrl",
                "play_url",
                "urlTemplate",
                "watchUrl",
                "watch_url",
                "url"
            )?.trim().orEmpty()

            val safeTemplate = safeUrl(template)
            if (safeTemplate.isBlank()) continue
            servers.add(PlaybackServer(name = name, webViewTemplate = safeTemplate))
        }

        return PlaybackConfig(servers, 0, if (servers.isEmpty()) "No servers in JSON" else null)
    }
}

private fun firstString(obj: JSONObject, vararg keys: String): String? {
    for (k in keys) {
        if (!obj.has(k)) continue
        val v = obj.opt(k) ?: continue
        if (v is String) return v
        return v.toString()
    }
    return null
}

private fun deviceId(context: Context): String {
    return runCatching {
        Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
    }.getOrNull().orEmpty()
}

private fun appendDeviceId(url: String, deviceId: String): String {
    if (deviceId.isBlank()) return url
    val encoded = try { URLEncoder.encode(deviceId, "UTF-8") } catch (_: Throwable) { deviceId }
    return if (url.contains("?")) {
        if (url.endsWith("?") || url.endsWith("&")) url + "device_id=" + encoded else url + "&device_id=" + encoded
    } else {
        url + "?device_id=" + encoded
    }
}