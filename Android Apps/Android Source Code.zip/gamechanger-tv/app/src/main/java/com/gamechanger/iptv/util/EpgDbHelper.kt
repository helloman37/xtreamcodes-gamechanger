package com.gamechanger.iptv.util

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.gamechanger.iptv.api.EpgNowNext
import com.gamechanger.iptv.api.EpgProgram

class EpgDbHelper(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS epg_now_next (
                stream_id TEXT PRIMARY KEY,
                cur_title TEXT,
                cur_start INTEGER,
                cur_stop INTEGER,
                next_title TEXT,
                next_start INTEGER,
                next_stop INTEGER,
                updated_at INTEGER
            )
            """.trimIndent()
        )

        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS app_creds (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                username TEXT,
                password TEXT,
                updated_at INTEGER
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 1) onCreate(db)
        if (oldVersion < 2) {
            db.execSQL(
                """
                CREATE TABLE IF NOT EXISTS app_creds (
                    id INTEGER PRIMARY KEY CHECK (id = 1),
                    username TEXT,
                    password TEXT,
                    updated_at INTEGER
                )
                """.trimIndent()
            )
        }
    }

    fun readCreds(): Pair<String, String>? {
        val db = readableDatabase
        db.rawQuery("SELECT username, password FROM app_creds WHERE id = 1", emptyArray()).use { c ->
            if (!c.moveToFirst()) return null
            val u = c.getString(0) ?: ""
            val p = c.getString(1) ?: ""
            if (u.isBlank() || p.isBlank()) return null
            return u to p
        }
    }

    fun writeCreds(username: String, password: String, updatedAtMs: Long = System.currentTimeMillis()) {
        val db = writableDatabase
        val cv = ContentValues().apply {
            put("id", 1)
            put("username", username)
            put("password", password)
            put("updated_at", updatedAtMs)
        }
        db.insertWithOnConflict("app_creds", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun clearCreds() {
        writableDatabase.delete("app_creds", "id = 1", null)
    }

    fun readNowNext(streamIds: List<String>, nowMs: Long = TimeSync.nowMs()): Pair<Long, Map<String, EpgNowNext>> {
        if (streamIds.isEmpty()) return 0L to emptyMap()
        val db = readableDatabase
        val out = HashMap<String, EpgNowNext>(streamIds.size)
        var newest = 0L

        // SQLite has a 999 bind limit; chunk IN queries.
        val chunkSize = 800
        var idx = 0
        while (idx < streamIds.size) {
            val chunk = streamIds.subList(idx, kotlin.math.min(idx + chunkSize, streamIds.size))
            idx += chunkSize
            val placeholders = chunk.joinToString(",") { "?" }
            val sql = "SELECT stream_id, cur_title, cur_start, cur_stop, next_title, next_start, next_stop, updated_at FROM epg_now_next WHERE stream_id IN ($placeholders)"

            db.rawQuery(sql, chunk.toTypedArray()).use { c ->
                while (c.moveToNext()) {
                    val sid = c.getString(0) ?: continue
                    val curTitle = c.getString(1)
                    val curStart = c.getLong(2)
                    val curStop = c.getLong(3)
                    val nextTitle = c.getString(4)
                    val nextStart = c.getLong(5)
                    val nextStop = c.getLong(6)
                    val updatedAt = c.getLong(7)
                    if (updatedAt > newest) newest = updatedAt

                    val cur = if (!curTitle.isNullOrBlank() && curStart > 0L && curStop > 0L) {
                        EpgProgram(title = curTitle, startMs = curStart, stopMs = curStop)
                    } else null
                    val nxt = if (!nextTitle.isNullOrBlank() && nextStart > 0L && nextStop > 0L) {
                        EpgProgram(title = nextTitle, startMs = nextStart, stopMs = nextStop)
                    } else null

                    out[sid] = normalizeNowNext(
                        EpgNowNext(current = cur, next = nxt, matchedXmltvId = null),
                        nowMs
                    ) ?: EpgNowNext(current = null, next = null, matchedXmltvId = null)
                }
            }
        }

        return newest to out
    }


    private fun normalizeNowNext(nowNext: EpgNowNext?, nowMs: Long): EpgNowNext? {
        val cur = nowNext?.current
        val nxt = nowNext?.next

        val curActive = cur != null &&
            cur.startMs > 0L &&
            cur.stopMs > cur.startMs &&
            nowMs >= cur.startMs &&
            nowMs < cur.stopMs

        val nextActive = nxt != null &&
            nxt.startMs > 0L &&
            nxt.stopMs > nxt.startMs &&
            nowMs >= nxt.startMs &&
            nowMs < nxt.stopMs

        return when {
            curActive -> EpgNowNext(
                current = cur,
                next = nxt?.takeIf { it.stopMs > nowMs },
                matchedXmltvId = nowNext?.matchedXmltvId
            )
            nextActive -> EpgNowNext(
                current = nxt,
                next = null,
                matchedXmltvId = nowNext?.matchedXmltvId
            )
            nxt != null && nxt.stopMs > nowMs -> EpgNowNext(
                current = null,
                next = nxt,
                matchedXmltvId = nowNext?.matchedXmltvId
            )
            cur != null && cur.stopMs > nowMs -> EpgNowNext(
                current = cur,
                next = nxt?.takeIf { it.stopMs > nowMs },
                matchedXmltvId = nowNext?.matchedXmltvId
            )
            else -> EpgNowNext(
                current = null,
                next = null,
                matchedXmltvId = nowNext?.matchedXmltvId
            )
        }
    }

    fun writeNowNext(nowNextByStreamId: Map<String, EpgNowNext>, updatedAtMs: Long = System.currentTimeMillis()) {
        if (nowNextByStreamId.isEmpty()) return
        val db = writableDatabase
        db.beginTransaction()
        try {
            for ((sid, nn) in nowNextByStreamId) {
                if (sid.isBlank()) continue
                val cv = ContentValues().apply {
                    put("stream_id", sid)
                    put("cur_title", nn.current?.title)
                    put("cur_start", nn.current?.startMs ?: 0L)
                    put("cur_stop", nn.current?.stopMs ?: 0L)
                    put("next_title", nn.next?.title)
                    put("next_start", nn.next?.startMs ?: 0L)
                    put("next_stop", nn.next?.stopMs ?: 0L)
                    put("updated_at", updatedAtMs)
                }
                db.insertWithOnConflict("epg_now_next", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    companion object {
        private const val DB_NAME = "epg.db"
        private const val DB_VERSION = 2
    }
}
