package com.gamechanger.iptv.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import com.gamechanger.iptv.ui.model.Movie

/**
 * Full-screen cinematic backdrop + vignette "wash" that matches the mockup.
 * Uses the hero movie backdrop and darkens left/bottom for legibility.
 */
@Composable
fun CinematicShell(
    heroMovie: Movie,
    content: @Composable RowScope.() -> Unit
) {
    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        // 1) Full Screen Backdrop Image (slightly dimmed)
        val backdrop = if (heroMovie.backdropUrl.isNotBlank()) heroMovie.backdropUrl else heroMovie.posterUrl
        AsyncImage(
            model = backdrop,
            contentDescription = null,
            modifier = Modifier.fillMaxSize().alpha(0.6f),
            contentScale = ContentScale.Crop
        )

        // 2) Horizontal + Vertical gradient wash (dark left / dark bottom)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(Color.Black, Color.Transparent),
                        startX = 0f,
                        endX = 1200f
                    )
                )
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, Color.Black)
                    )
                )
        )

        // 3) Layout Content
        Row(modifier = Modifier.fillMaxSize()) {
            content()
        }
    }
}
