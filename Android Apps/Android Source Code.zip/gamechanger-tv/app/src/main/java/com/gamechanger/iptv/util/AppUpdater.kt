package com.gamechanger.iptv.util

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

object AppUpdater {

    private fun updateDir(activity: Activity): File {
        val dir = File(activity.cacheDir, "updates")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    suspend fun downloadApk(
        activity: Activity,
        url: String,
        onProgress: ((downloadedBytes: Long, totalBytes: Long) -> Unit)? = null
    ): File {
        val client = OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .callTimeout(120, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()

        val req = Request.Builder()
            .url(url)
            .header("User-Agent", "GameChanger")
            .build()

        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("HTTP ${resp.code}")
            val body = resp.body ?: throw IOException("Empty body")

            val total = body.contentLength() // may be -1

            val outFile = File(updateDir(activity), "update.apk")
            body.byteStream().use { input ->
                outFile.outputStream().use { output ->
                    val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                    var downloaded = 0L
                    var lastEmitMs = 0L
                    var lastEmitBytes = 0L

                    while (true) {
                        val read = input.read(buffer)
                        if (read <= 0) break
                        output.write(buffer, 0, read)
                        downloaded += read

                        if (onProgress != null) {
                            val now = System.currentTimeMillis()
                            val timeOk = (now - lastEmitMs) >= 120L
                            val bytesOk = (downloaded - lastEmitBytes) >= (256L * 1024L)
                            if (timeOk || bytesOk) {
                                lastEmitMs = now
                                lastEmitBytes = downloaded
                                withContext(Dispatchers.Main.immediate) {
                                    onProgress(downloaded, total)
                                }
                            }
                        }
                    }

                    if (onProgress != null) {
                        withContext(Dispatchers.Main.immediate) {
                            onProgress(downloaded, total)
                        }
                    }
                }
            }
            return outFile
        }
    }

    fun installApk(activity: Activity, apkFile: File) {
        // On Android O+, user may need to allow installs from this app.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ok = activity.packageManager.canRequestPackageInstalls()
            if (!ok) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:${activity.packageName}")
                )
                activity.startActivity(intent)
                return
            }
        }

        val uri = FileProvider.getUriForFile(
            activity,
            "${activity.packageName}.fileprovider",
            apkFile
        )

        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        activity.startActivity(intent)
    }
}
