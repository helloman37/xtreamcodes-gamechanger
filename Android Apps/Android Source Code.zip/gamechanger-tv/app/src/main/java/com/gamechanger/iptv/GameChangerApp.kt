package com.gamechanger.iptv

import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import coil.Coil
import coil.ImageLoader
import okhttp3.ConnectionSpec
import okhttp3.OkHttpClient
import org.conscrypt.Conscrypt
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.security.Security
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.TimeUnit

class GameChangerApp : Application() {
    override fun onCreate() {
        super.onCreate()

        // Force a modern TLS provider on cheap/older TV sticks so HTTPS image + TMDB calls don't silently fail.
        // (TMDB poster/backdrop assets are HTTPS-only.)
        try {
            Security.insertProviderAt(Conscrypt.newProvider(), 1)
            // Prefer Conscrypt's engine sockets for better TLS compatibility on cheap Android TV devices.
            try { Conscrypt.setUseEngineSocketByDefault(true) } catch (_: Throwable) {}
        } catch (_: Throwable) {
        }

        // Drop a breadcrumb each launch so we can tell whether we're dealing with a hard kill / ANR.
        try {
            File(filesDir, "last_launch.txt").writeText(
                "Time: ${java.time.ZonedDateTime.now()}\n" +
                    "Process: ${android.os.Process.myPid()}\n"
            )
        } catch (_: Throwable) {
        }

        // Persist the last crash to disk so we can render it on next launch (helps when logcat is incomplete).
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                val payload = buildString {
                    appendLine("=== GameChanger crash ===")
                    appendLine("Time: ${java.time.ZonedDateTime.now()}")
                    appendLine("Thread: ${t.name}")
                    appendLine()
                    append(sw.toString())
                }
                File(filesDir, "crash_last.txt").writeText(payload)
                copyCrashToClipboard(payload)
                Log.e("GameChangerCrash", payload)
            } catch (_: Throwable) {
                // ignore
            } finally {
                previous?.uncaughtException(t, e)
            }
        }

        // Lightweight ANR watchdog: if the main thread stops processing for ~8s, dump all stacks.
        // This catches "killed with SIG: 9" cases where logcat doesn't show a Java exception.
        try {
            val mainHandler = Handler(Looper.getMainLooper())
            val tick = AtomicInteger(0)
            val ack = AtomicInteger(0)

            val ping = object : Runnable {
                override fun run() {
                    ack.set(tick.get())
                    mainHandler.postDelayed(this, 500)
                }
            }
            mainHandler.post(ping)

            Thread({
                while (true) {
                    val observed = tick.incrementAndGet()
                    Thread.sleep(8000)
                    if (ack.get() != observed) {
                        val dump = buildString {
                            appendLine("=== GameChanger ANR suspected ===")
                            appendLine("Time: ${java.time.ZonedDateTime.now()}")
                            appendLine("Main thread unresponsive ~8s")
                            appendLine()
                            val all = Thread.getAllStackTraces()
                            for ((th, st) in all) {
                                appendLine("--- Thread: ${th.name} (id=${th.id}, state=${th.state}) ---")
                                for (el in st) {
                                    appendLine("    at $el")
                                }
                                appendLine()
                            }
                        }

                        try {
                            File(filesDir, "crash_last.txt").writeText(dump)
                            copyCrashToClipboard(dump)
                        } catch (_: Throwable) {
                        }
                        Log.e("GameChangerANR", dump)
                    }
                }
            }, "GameChanger-ANRWatchdog").apply { isDaemon = true }.start()
        } catch (_: Throwable) {
        }

        // Use a very compatible TLS profile. Some Android TV sticks choke on strict MODERN_TLS / TLS1.3.
        val okHttp = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .writeTimeout(20, TimeUnit.SECONDS)
            .callTimeout(30, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .followRedirects(true)
            .followSslRedirects(true)
            .connectionSpecs(
                listOf(
                    ConnectionSpec.COMPATIBLE_TLS,
                    ConnectionSpec.CLEARTEXT
                )
            )
            .build()

        imageLoader = ImageLoader.Builder(this)
            .okHttpClient(okHttp)
            // Some Android TV / Onn sticks have GPU/decoder quirks with hardware bitmaps.
            // Disabling hardware bitmaps fixes the classic "images never appear" symptom.
            .allowHardware(false)
            .crossfade(true)
            .build()

        // Make AsyncImage use THIS loader (otherwise Coil uses its default loader).
        Coil.setImageLoader(imageLoader)
    }

    private fun copyCrashToClipboard(payload: String) {
        try {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager ?: return
            val clip = ClipData.newPlainText("GameChanger crash log", payload)
            clipboard.setPrimaryClip(clip)
        } catch (_: Throwable) {
        }
    }

    companion object {
        lateinit var imageLoader: ImageLoader
            private set
    }
}
