package com.gamechanger.iptv.util

import android.content.Context
import com.gamechanger.iptv.ui.model.Channel
import com.gamechanger.iptv.ui.model.Movie
import org.json.JSONArray
import org.json.JSONObject

private const val PREFS_NAME = "gc_user_shelf"
private const val KEY_FAVORITE_MOVIES = "favorite_movies"
private const val KEY_FAVORITE_CHANNELS = "favorite_channels"
private const val KEY_CONTINUE_WATCHING = "continue_watching"
private const val KEY_RECENT_CHANNELS = "recent_channels"

private const val MAX_FAVORITE_MOVIES = 80
private const val MAX_FAVORITE_CHANNELS = 80
private const val MAX_CONTINUE_WATCHING = 40
private const val MAX_RECENT_CHANNELS = 30

data class ContinueWatchingEntry(
    val movie: Movie,
    val seasonNumber: Int = 1,
    val episodeNumber: Int = 1,
    val updatedAt: Long = System.currentTimeMillis()
) {
    val key: String
        get() = movieKey(movie)
}

object UserShelfStore {
    private fun prefs(context: Context) = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getFavoriteMovies(context: Context): List<Movie> =
        parseMovieList(prefs(context).getString(KEY_FAVORITE_MOVIES, null))

    fun isMovieFavorite(context: Context, movie: Movie): Boolean {
        val key = movieKey(movie)
        return getFavoriteMovies(context).any { movieKey(it) == key }
    }

    fun toggleMovieFavorite(context: Context, movie: Movie): Boolean {
        val key = movieKey(movie)
        val current = getFavoriteMovies(context).toMutableList()
        val existingIndex = current.indexOfFirst { movieKey(it) == key }
        val isFavorite = existingIndex >= 0
        if (isFavorite) {
            current.removeAt(existingIndex)
        } else {
            current.removeAll { movieKey(it) == key }
            current.add(0, movie)
        }
        saveMovieList(context, KEY_FAVORITE_MOVIES, current.take(MAX_FAVORITE_MOVIES))
        return !isFavorite
    }

    fun clearFavoriteMovies(context: Context) {
        prefs(context).edit().remove(KEY_FAVORITE_MOVIES).apply()
    }

    fun getFavoriteChannels(context: Context): List<Channel> =
        parseChannelList(prefs(context).getString(KEY_FAVORITE_CHANNELS, null))

    fun isChannelFavorite(context: Context, channel: Channel): Boolean {
        val key = channelKey(channel)
        return getFavoriteChannels(context).any { channelKey(it) == key }
    }

    fun toggleChannelFavorite(context: Context, channel: Channel): Boolean {
        val key = channelKey(channel)
        val current = getFavoriteChannels(context).toMutableList()
        val existingIndex = current.indexOfFirst { channelKey(it) == key }
        val isFavorite = existingIndex >= 0
        if (isFavorite) {
            current.removeAt(existingIndex)
        } else {
            current.removeAll { channelKey(it) == key }
            current.add(0, channel)
        }
        saveChannelList(context, KEY_FAVORITE_CHANNELS, current.take(MAX_FAVORITE_CHANNELS))
        return !isFavorite
    }

    fun clearFavoriteChannels(context: Context) {
        prefs(context).edit().remove(KEY_FAVORITE_CHANNELS).apply()
    }

    fun recordContinueWatching(
        context: Context,
        movie: Movie,
        seasonNumber: Int = 1,
        episodeNumber: Int = 1
    ) {
        val current = getContinueWatching(context).toMutableList()
        val entry = ContinueWatchingEntry(
            movie = movie,
            seasonNumber = seasonNumber,
            episodeNumber = episodeNumber,
            updatedAt = System.currentTimeMillis()
        )
        current.removeAll { it.key == entry.key }
        current.add(0, entry)
        saveContinueWatching(context, current.take(MAX_CONTINUE_WATCHING))
    }

    fun removeContinueWatching(context: Context, movie: Movie) {
        val key = movieKey(movie)
        val current = getContinueWatching(context).filterNot { it.key == key }
        saveContinueWatching(context, current)
    }

    fun clearContinueWatching(context: Context) {
        prefs(context).edit().remove(KEY_CONTINUE_WATCHING).apply()
    }

    fun getContinueWatching(context: Context): List<ContinueWatchingEntry> {
        val raw = prefs(context).getString(KEY_CONTINUE_WATCHING, null).orEmpty()
        if (raw.isBlank()) return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    add(
                        ContinueWatchingEntry(
                            movie = movieFromJson(obj.optJSONObject("movie")),
                            seasonNumber = obj.optInt("seasonNumber", 1).coerceAtLeast(1),
                            episodeNumber = obj.optInt("episodeNumber", 1).coerceAtLeast(1),
                            updatedAt = obj.optLong("updatedAt", 0L)
                        )
                    )
                }
            }.sortedByDescending { it.updatedAt }
        }.getOrElse { emptyList() }
    }

    fun recordRecentChannel(context: Context, channel: Channel) {
        val current = getRecentChannels(context).toMutableList()
        val key = channelKey(channel)
        current.removeAll { channelKey(it.channel) == key }
        current.add(0, RecentChannelEntry(channel = channel, watchedAt = System.currentTimeMillis()))
        saveRecentChannels(context, current.take(MAX_RECENT_CHANNELS))
    }

    fun clearRecentChannels(context: Context) {
        prefs(context).edit().remove(KEY_RECENT_CHANNELS).apply()
    }

    fun getRecentChannels(context: Context): List<RecentChannelEntry> {
        val raw = prefs(context).getString(KEY_RECENT_CHANNELS, null).orEmpty()
        if (raw.isBlank()) return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    add(
                        RecentChannelEntry(
                            channel = channelFromJson(obj.optJSONObject("channel")),
                            watchedAt = obj.optLong("watchedAt", 0L)
                        )
                    )
                }
            }.sortedByDescending { it.watchedAt }
        }.getOrElse { emptyList() }
    }

    fun clearAllFavorites(context: Context) {
        clearFavoriteMovies(context)
        clearFavoriteChannels(context)
    }

    private fun saveMovieList(context: Context, key: String, items: List<Movie>) {
        val arr = JSONArray()
        items.forEach { arr.put(movieToJson(it)) }
        prefs(context).edit().putString(key, arr.toString()).apply()
    }

    private fun saveChannelList(context: Context, key: String, items: List<Channel>) {
        val arr = JSONArray()
        items.forEach { arr.put(channelToJson(it)) }
        prefs(context).edit().putString(key, arr.toString()).apply()
    }

    private fun saveContinueWatching(context: Context, items: List<ContinueWatchingEntry>) {
        val arr = JSONArray()
        items.forEach { entry ->
            arr.put(
                JSONObject()
                    .put("movie", movieToJson(entry.movie))
                    .put("seasonNumber", entry.seasonNumber)
                    .put("episodeNumber", entry.episodeNumber)
                    .put("updatedAt", entry.updatedAt)
            )
        }
        prefs(context).edit().putString(KEY_CONTINUE_WATCHING, arr.toString()).apply()
    }

    private fun saveRecentChannels(context: Context, items: List<RecentChannelEntry>) {
        val arr = JSONArray()
        items.forEach { entry ->
            arr.put(
                JSONObject()
                    .put("channel", channelToJson(entry.channel))
                    .put("watchedAt", entry.watchedAt)
            )
        }
        prefs(context).edit().putString(KEY_RECENT_CHANNELS, arr.toString()).apply()
    }
}

data class RecentChannelEntry(
    val channel: Channel,
    val watchedAt: Long = System.currentTimeMillis()
)

private fun parseMovieList(raw: String?): List<Movie> {
    if (raw.isNullOrBlank()) return emptyList()
    return runCatching {
        val arr = JSONArray(raw)
        buildList {
            for (i in 0 until arr.length()) {
                add(movieFromJson(arr.optJSONObject(i)))
            }
        }
    }.getOrElse { emptyList() }
}

private fun parseChannelList(raw: String?): List<Channel> {
    if (raw.isNullOrBlank()) return emptyList()
    return runCatching {
        val arr = JSONArray(raw)
        buildList {
            for (i in 0 until arr.length()) {
                add(channelFromJson(arr.optJSONObject(i)))
            }
        }
    }.getOrElse { emptyList() }
}

private fun movieToJson(movie: Movie): JSONObject = JSONObject()
    .put("id", movie.id)
    .put("title", movie.title)
    .put("overview", movie.overview)
    .put("backdropUrl", movie.backdropUrl)
    .put("posterUrl", movie.posterUrl)
    .put("year", movie.year)
    .put("rating", movie.rating)
    .put("mediaType", movie.mediaType)

private fun movieFromJson(obj: JSONObject?): Movie = Movie(
    id = obj?.optInt("id", 0) ?: 0,
    title = obj?.optString("title").orEmpty(),
    overview = obj?.optString("overview").orEmpty(),
    backdropUrl = obj?.optString("backdropUrl").orEmpty(),
    posterUrl = obj?.optString("posterUrl").orEmpty(),
    year = obj?.optString("year").orEmpty(),
    rating = obj?.optDouble("rating", 0.0) ?: 0.0,
    mediaType = obj?.optString("mediaType").orEmpty().ifBlank { "movie" }
)

private fun channelToJson(channel: Channel): JSONObject = JSONObject()
    .put("name", channel.name)
    .put("logoUrl", channel.logoUrl)
    .put("streamUrl", channel.streamUrl)
    .put("groupTitle", channel.groupTitle)
    .put("categoryId", channel.categoryId)
    .put("streamId", channel.streamId)

private fun channelFromJson(obj: JSONObject?): Channel = Channel(
    name = obj?.optString("name").orEmpty(),
    logoUrl = obj?.optString("logoUrl").orEmpty(),
    streamUrl = obj?.optString("streamUrl").orEmpty(),
    groupTitle = obj?.optString("groupTitle").orEmpty(),
    categoryId = obj?.optString("categoryId").orEmpty(),
    streamId = obj?.optString("streamId").orEmpty()
)

private fun movieKey(movie: Movie): String {
    val idPart = if (movie.id > 0) movie.id.toString() else movie.title.lowercase()
    return "${movie.mediaType.lowercase()}_$idPart"
}

private fun channelKey(channel: Channel): String = channel.streamId.ifBlank { channel.name.trim().lowercase() }
