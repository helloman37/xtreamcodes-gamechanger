package com.gamechanger.iptv.api

import com.google.gson.annotations.SerializedName

data class XtreamLiveCategoryDto(
    @SerializedName("category_id") val categoryId: String? = null,
    @SerializedName("category_name") val categoryName: String? = null,
    @SerializedName("parent_id") val parentId: Int? = null
)

data class XtreamLiveStreamDto(
    @SerializedName("stream_id") val streamId: String? = null,
    @SerializedName("name") val name: String? = null,
    @SerializedName("stream_icon") val streamIcon: String? = null,
    @SerializedName("category_id") val categoryId: String? = null,
    // Some panels provide a fully-qualified stream URL here (often .m3u8).
    @SerializedName("direct_source") val directSource: String? = null,
    // Optional metadata (not always present, but harmless to parse).
    @SerializedName("stream_type") val streamType: String? = null
)
