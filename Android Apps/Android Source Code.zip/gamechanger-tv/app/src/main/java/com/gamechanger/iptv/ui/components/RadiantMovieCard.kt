package com.gamechanger.iptv.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.gamechanger.iptv.ui.model.Movie

@Composable
fun RadiantMovieCard(
    movie: Movie,
    onClick: () -> Unit
) {
    var isFocused by remember { mutableStateOf(false) }
    val interactionSource = remember { MutableInteractionSource() }

    // "ELITE MINI CARD" (Skinny + Neon Glow)
    Card(
        modifier = Modifier
            .padding(10.dp)
            .width(122.dp)  // MOCKUP SCALE: Skinny and Elegant
            .height(184.dp) // MOCKUP SCALE
            .onFocusChanged { isFocused = it.isFocused }
            .scale(if (isFocused) 1.15f else 1.0f)
            .then(
                if (isFocused) Modifier.shadow(
                    elevation = 25.dp,
                    spotColor = Color.Cyan, // RADIANT LIGHT BLEED
                    ambientColor = Color.Cyan,
                    shape = RoundedCornerShape(10.dp)
                ) else Modifier
            )
            .focusable(interactionSource = interactionSource)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            ),
        shape = RoundedCornerShape(10.dp)
    ) {
        Box {
            AsyncImage(
                model = movie.posterUrl,
                contentDescription = null,
                contentScale = ContentScale.Crop
            )
        }
    }
}
