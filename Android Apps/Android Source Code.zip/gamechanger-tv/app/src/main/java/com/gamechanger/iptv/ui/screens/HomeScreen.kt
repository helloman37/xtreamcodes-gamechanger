package com.gamechanger.iptv.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gamechanger.iptv.ui.theme.GameChangerCyan
import com.gamechanger.iptv.ui.theme.PureBlack

@Composable
fun HomeScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PureBlack)
            .padding(48.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "HOME",
            fontSize = 64.sp,
            fontWeight = FontWeight.ExtraBold,
            color = GameChangerCyan
        )
        Text(
            text = "Logged in.",
            fontSize = 20.sp,
            color = Color.White,
            modifier = Modifier.padding(top = 12.dp)
        )
    }
}
