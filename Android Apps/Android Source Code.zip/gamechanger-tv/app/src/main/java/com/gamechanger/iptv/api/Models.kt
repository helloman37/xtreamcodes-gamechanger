package com.gamechanger.iptv.api

// Minimal placeholders so the project compiles. Replace/expand with real Xtream/TMDB schemas.

data class AccountResponse(
    val user_info: Map<String, Any?>? = null,
    val server_info: Map<String, Any?>? = null
)

data class XtreamStream(
    val stream_id: Int? = null,
    val name: String? = null,
    val stream_icon: String? = null
)

// TMDB (typed)
data class TmdbResponse(
    val page: Int? = null,
    val results: List<TmdbMovie> = emptyList()
)

data class TmdbMovie(
    val id: Int? = null,
    val title: String? = null,
    val name: String? = null,
    val overview: String? = null,
    val release_date: String? = null,
    val first_air_date: String? = null,
    val poster_path: String? = null,
    val backdrop_path: String? = null
)
