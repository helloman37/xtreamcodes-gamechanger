package com.gamechanger.admin.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector

sealed class NavItem(val route: String, val label: String, val icon: ImageVector) {
    data object Dashboard : NavItem("dashboard", "Dashboard", Icons.Filled.SpaceDashboard)
    data object Users : NavItem("users", "Users", Icons.Filled.People)
    data object Streams : NavItem("streams", "Streams", Icons.Filled.LiveTv)
    data object Anomaly : NavItem("anomaly", "Anomaly", Icons.Filled.Shield)
    data object Panic : NavItem("panic", "Panic", Icons.Filled.Warning)
}

val bottomNavItems = listOf(NavItem.Dashboard, NavItem.Users, NavItem.Streams, NavItem.Anomaly)
