package com.gamechanger.admin.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.gamechanger.admin.api.ApiRepo
import com.gamechanger.admin.api.SessionRow
import kotlinx.coroutines.*

@Composable
fun StreamsScreen() {
    var items by remember { mutableStateOf<List<SessionRow>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }

    fun load() {
        if (busy) return
        busy = true
        CoroutineScope(Dispatchers.IO).launch {
            val r = ApiRepo.sessionsList(minutes = 5, type = null)
            withContext(Dispatchers.Main) {
                items = r
                busy = false
            }
        }
    }

    LaunchedEffect(Unit) { load() }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Streams", style = MaterialTheme.typography.titleLarge)
        Text("Live sessions • kill", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = { load() }) { Text(if (busy) "..." else "REFRESH") }
            OutlinedButton(onClick = {
                CoroutineScope(Dispatchers.IO).launch {
                    val r = ApiRepo.sessionsList(minutes=5, type="live")
                    withContext(Dispatchers.Main) { items = r }
                }
            }) { Text("LIVE") }
            OutlinedButton(onClick = {
                CoroutineScope(Dispatchers.IO).launch {
                    val r = ApiRepo.sessionsList(minutes=5, type="vod")
                    withContext(Dispatchers.Main) { items = r }
                }
            }) { Text("VOD") }
            OutlinedButton(onClick = {
                CoroutineScope(Dispatchers.IO).launch {
                    val r = ApiRepo.sessionsList(minutes=5, type="series")
                    withContext(Dispatchers.Main) { items = r }
                }
            }) { Text("SER") }
        }

        Spacer(Modifier.height(12.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(items) { s ->
                Card(
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Text("${s.type.uppercase()}  #${s.id}")
                        Text("User: ${s.username ?: s.userId}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("IP: ${s.ip}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        val item = when {
                            s.channelId != null && s.channelId != 0 -> "Channel ${s.channelId}"
                            s.itemId != null && s.itemId != 0 -> "Item ${s.itemId}"
                            else -> "—"
                        }
                        Text(item, color = MaterialTheme.colorScheme.onSurfaceVariant)

                        Spacer(Modifier.height(10.dp))

                        OutlinedButton(onClick = {
                            CoroutineScope(Dispatchers.IO).launch {
                                ApiRepo.sessionKill(s.id)
                                // optimistically remove
                                withContext(Dispatchers.Main) { items = items.filterNot { it.id == s.id } }
                            }
                        }) { Text("KILL") }
                    }
                }
            }
        }
    }
}
