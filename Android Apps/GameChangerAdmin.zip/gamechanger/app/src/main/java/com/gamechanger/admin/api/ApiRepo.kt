package com.gamechanger.admin.api

import okhttp3.FormBody
import org.json.JSONArray
import org.json.JSONObject

data class UserRow(val id:Int, val username:String, val status:String? = null, val maxConnections:Int? = null, val expDate:String? = null, val email:String? = null)
data class SessionRow(val id:Int, val userId:Int, val username:String?, val ip:String, val type:String, val channelId:Int?, val itemId:Int?, val lastSeen:String)
data class AnomalyRow(val userId:Int, val username:String?, val ipCount:Int, val fpCount:Int, val errCount:Int, val hits:Int)

data class LiveStatus(
    val activeUsers:Int,
    val activeSessions:Int,
    val activeConnections:Int,
    val anomalyUsers:Int,
    val requestsTotal:Int,
    val requestsBad:Int,
    val windowMinutes:Int
)

object ApiRepo {

    suspend fun liveStatus(): LiveStatus? {
        val req = ApiClient.authGet("live_status.php")
        val res = ApiClient.http.newCall(req).execute()
        if (!res.isSuccessful) return null
        val json = JSONObject(res.body!!.string())
        if (!json.optBoolean("ok", false)) return null
        return LiveStatus(
            activeUsers = json.optInt("active_users", 0),
            activeSessions = json.optInt("active_sessions", 0),
            activeConnections = json.optInt("active_connections", 0),
            anomalyUsers = json.optInt("anomaly_users", 0),
            requestsTotal = json.optInt("requests_total", 0),
            requestsBad = json.optInt("requests_bad", 0),
            windowMinutes = json.optInt("window_minutes", 180)
        )
    }

    suspend fun usersSearch(q: String): List<UserRow> {
    val req = ApiClient.authGet("users_search.php?q=" + java.net.URLEncoder.encode(q, "UTF-8"))
    val res = ApiClient.http.newCall(req).execute()
    val bodyStr = res.body?.string() ?: ""
    if (!res.isSuccessful) return emptyList()
    val json = JSONObject(bodyStr)
    val arr = json.optJSONArray("items") ?: JSONArray()
    val out = ArrayList<UserRow>()
    for (i in 0 until arr.length()) {
        val o = arr.getJSONObject(i)
        val id = o.optInt("id", 0)
        val username = o.optString("username", "")
        val status = if (o.has("status")) o.optString("status", null) else null
        val maxConn = if (o.has("max_connections")) o.optInt("max_connections") else null
        val exp = if (o.has("exp_date")) o.optString("exp_date", null) else null
        val email = if (o.has("email")) o.optString("email", null) else null
        out.add(UserRow(id, username, status, maxConn, exp, email))
    }
    return out
}




    suspend fun userSetStatus(userId:Int, status:String): Boolean {
        val body = FormBody.Builder().add("user_id", userId.toString()).add("status", status).build()
        val req = ApiClient.authPost("users_set_status.php", body)
        val res = ApiClient.http.newCall(req).execute()
        return res.isSuccessful
    }

    suspend fun userKillSessions(userId:Int): Boolean {
        val body = FormBody.Builder().add("user_id", userId.toString()).build()
        val req = ApiClient.authPost("users_kill_sessions.php", body)
        val res = ApiClient.http.newCall(req).execute()
        return res.isSuccessful
    }

    suspend fun sessionsList(minutes:Int=5, type:String?=null): List<SessionRow> {
        val qp = StringBuilder("sessions_list.php?minutes=$minutes&limit=200")
        if (!type.isNullOrBlank()) qp.append("&type=").append(type)
        val req = ApiClient.authGet(qp.toString())
        val res = ApiClient.http.newCall(req).execute()
        if (!res.isSuccessful) return emptyList()
        val json = JSONObject(res.body!!.string())
        val arr = json.optJSONArray("items") ?: JSONArray()
        val out = ArrayList<SessionRow>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(
                SessionRow(
                    id = o.getInt("id"),
                    userId = o.optInt("user_id",0),
                    username = if (o.has("username")) o.optString("username", null) else null,
                    ip = o.optString("ip",""),
                    type = o.optString("stream_type",""),
                    channelId = if (o.isNull("channel_id")) null else o.optInt("channel_id"),
                    itemId = if (o.isNull("item_id")) null else o.optInt("item_id"),
                    lastSeen = o.optString("last_seen","")
                )
            )
        }
        return out
    }

    suspend fun sessionKill(sessionId:Int): Boolean {
        val body = FormBody.Builder().add("session_id", sessionId.toString()).build()
        val req = ApiClient.authPost("sessions_kill.php", body)
        val res = ApiClient.http.newCall(req).execute()
        return res.isSuccessful
    }

    suspend fun anomalyList(minutes:Int=180): List<AnomalyRow> {

    // Prefer the bearer-auth anomaly center endpoint (matches the web panel).
    runCatching {
        val req = ApiClient.authGet("anomaly_center.php?minutes=$minutes")
        val res = ApiClient.http.newCall(req).execute()
        if (res.isSuccessful) {
            val raw = res.body?.string().orEmpty()
            val json = JSONObject(raw)
            val arr = json.optJSONArray("rows")
                ?: json.optJSONArray("items")
                ?: json.optJSONObject("data")?.optJSONArray("rows")
                ?: JSONArray()

            val out = parseAnomalyRows(arr)
            if (out.isNotEmpty()) return out
        }
    }

    // Fallback: legacy endpoint
    return runCatching {
        val req = ApiClient.authGet("anomaly_list.php?minutes=$minutes")
        val res = ApiClient.http.newCall(req).execute()
        if (!res.isSuccessful) return emptyList()
        val raw = res.body?.string().orEmpty()
        val json = JSONObject(raw)
        val arr = json.optJSONArray("items")
            ?: json.optJSONArray("rows")
            ?: json.optJSONObject("data")?.optJSONArray("items")
            ?: JSONArray()

        parseAnomalyRows(arr)
    }.getOrDefault(emptyList())
}

private fun parseAnomalyRows(arr: JSONArray): List<AnomalyRow> {
    val out = ArrayList<AnomalyRow>(arr.length())

    fun JSONObject.pickInt(vararg keys: String): Int {
        for (k in keys) {
            if (has(k) && !isNull(k)) return optInt(k, 0)
        }
        return 0
    }

    fun JSONObject.pickStr(vararg keys: String): String? {
        for (k in keys) {
            if (has(k) && !isNull(k)) {
                val s = optString(k, "").trim()
                if (s.isNotEmpty()) return s
            }
        }
        return null
    }

    for (i in 0 until arr.length()) {
        val o = arr.optJSONObject(i) ?: continue

        val userId = when {
            o.has("user_id") -> o.optInt("user_id", 0)
            o.has("userId") -> o.optInt("userId", 0)
            o.has("id") -> o.optInt("id", 0)
            else -> 0
        }
        if (userId == 0) continue

        val username = o.pickStr("username", "user", "name")

        val ipCount = o.pickInt("unique_ips", "ip_count", "ips")
        val fpCount = o.pickInt("unique_fps", "fp_count", "fps")
        val errCount = o.pickInt("error_hits", "err_count", "errors")
        val hits = o.pickInt("hits", "total_hits", "count")

        out.add(AnomalyRow(userId, username, ipCount, fpCount, errCount, hits))
    }

    return out.sortedByDescending { it.hits }
}

suspend fun panicStatus(): JSONObject? {
        val req = ApiClient.authGet("panic_status.php")
        val res = ApiClient.http.newCall(req).execute()
        if (!res.isSuccessful) return null
        return JSONObject(res.body!!.string())
    }

    suspend fun panicToggleMaintenance(enabled: Boolean? = null): Boolean {
        val b = FormBody.Builder()
        if (enabled != null) b.add("enabled", if (enabled) "1" else "0")
        val req = ApiClient.authPost("panic_toggle_maintenance.php", b.build())
        val res = ApiClient.http.newCall(req).execute()
        return res.isSuccessful
    }

    suspend fun panicKillAllSessions(mode: String = "mark"): Boolean {
        val body = FormBody.Builder().add("mode", mode).build()
        val req = ApiClient.authPost("panic_kill_all_sessions.php", body)
        val res = ApiClient.http.newCall(req).execute()
        return res.isSuccessful
    }

    data class TokenRow(
        val id:Int,
        val createdAt:String?,
        val expiresAt:String?,
        val lastUsedAt:String?,
        val revokedAt:String?,
        val deviceId:String?,
        val deviceName:String?,
        val lastIp:String?
    )

    suspend fun tokensList(): List<TokenRow> {
        val req = ApiClient.authGet("tokens_list.php")
        val res = ApiClient.http.newCall(req).execute()
        if (!res.isSuccessful) return emptyList()
        val json = JSONObject(res.body!!.string())
        val arr = json.optJSONArray("items") ?: JSONArray()
        val out = ArrayList<TokenRow>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(
                TokenRow(
                    id = o.getInt("id"),
                    createdAt = o.optString("created_at", null),
                    expiresAt = o.optString("expires_at", null),
                    lastUsedAt = o.optString("last_used_at", null),
                    revokedAt = o.optString("revoked_at", null),
                    deviceId = o.optString("device_id", null),
                    deviceName = o.optString("device_name", null),
                    lastIp = o.optString("last_ip", null)
                )
            )
        }
        return out
    }

    suspend fun tokenRevoke(tokenId:Int): Boolean {
        val body = FormBody.Builder().add("token_id", tokenId.toString()).build()
        val req = ApiClient.authPost("token_revoke.php", body)
        val res = ApiClient.http.newCall(req).execute()
        return res.isSuccessful
    }

    suspend fun tokenRotate(): String? {
        val body = FormBody.Builder().build()
        val req = ApiClient.authPost("token_rotate.php", body)
        val res = ApiClient.http.newCall(req).execute()
        if (!res.isSuccessful) return null
        val json = JSONObject(res.body!!.string())
        return json.optString("token", null)
    }
}