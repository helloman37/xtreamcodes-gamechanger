package com.gamechanger.admin.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.gamechanger.admin.api.ApiRepo
import com.gamechanger.admin.api.UserRow
import com.gamechanger.admin.ui.components.GCPrimaryButton
import kotlinx.coroutines.*

@Composable
fun UsersScreen() {
    var q by remember { mutableStateOf("") }
    var items by remember { mutableStateOf<List<UserRow>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Users", style = MaterialTheme.typography.titleLarge)
        Text("Search • suspend • kill", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))

        OutlinedTextField(
            value = q,
            onValueChange = { q = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Search username / id") },
            singleLine = true
        )

        Spacer(Modifier.height(10.dp))

        GCPrimaryButton(
            text = if (busy) "Searching..." else "SEARCH",
            onClick = {
                if (q.isBlank() || busy) return@GCPrimaryButton
                busy = true
                CoroutineScope(Dispatchers.IO).launch {
                    val r = ApiRepo.usersSearch(q)
                    withContext(Dispatchers.Main) {
                        items = r
                        err = null
                        busy = false
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(12.dp))

        err?.let { Text(it, color = MaterialTheme.colorScheme.error) ; Spacer(Modifier.height(8.dp)) }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(items) { u ->
                Card(
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Text("${u.username}  #${u.id}")
                        Text("Status: ${(u.status ?: "—")}", color = MaterialTheme.colorScheme.onSurfaceVariant)

                        Spacer(Modifier.height(10.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedButton(
                                onClick = {
                                    CoroutineScope(Dispatchers.IO).launch {
                                        ApiRepo.userSetStatus(u.id, if ((u.status ?: "—") == "active") "suspended" else "active")
                                        val list = ApiRepo.usersSearch(q)
                                        val e: String? = null
                                        withContext(Dispatchers.Main) { items = list; err = null }
                                    }
                                }
                            ) {
                                Text(if ((u.status ?: "—") == "active") "SUSPEND" else "ENABLE")
                            }

                            OutlinedButton(
                                onClick = {
                                    CoroutineScope(Dispatchers.IO).launch {
                                        ApiRepo.userKillSessions(u.id)
                                    }
                                }
                            ) {
                                Text("KILL SESS")
                            }
                        }
                    }
                }
            }
        }
    }
}
