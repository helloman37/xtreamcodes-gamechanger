package com.gamechanger.admin.ui

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.gamechanger.admin.api.ApiClient
import com.gamechanger.admin.api.ApiRepo
import com.gamechanger.admin.ui.components.GCPrimaryButton
import kotlinx.coroutines.*

@Composable
fun PanicScreen() {
    val ctx = LocalContext.current

    var status by remember { mutableStateOf("—") }
    var maintenance by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }

    fun refresh() {
        if (busy) return
        busy = true
        CoroutineScope(Dispatchers.IO).launch {
            val js = ApiRepo.panicStatus()
            withContext(Dispatchers.Main) {
                if (js == null) {
                    msg = "Panic status failed"
                } else {
                    maintenance = js.optBoolean("maintenance", false)
                    val sess = js.optInt("active_sessions", 0)
                    status = "Maintenance: " + (if (maintenance) "ON" else "OFF") + " • Active sessions: " + sess
                    msg = null
                }
                busy = false
            }
        }
    }

    LaunchedEffect(Unit) { refresh() }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Panic Mode", style = MaterialTheme.typography.titleLarge)
        Text("Fast ops only.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(10.dp))

        Card(
            shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(Modifier.padding(14.dp)) {
                Text(status)
                msg?.let {
                    Spacer(Modifier.height(6.dp))
                    Text(it, color = MaterialTheme.colorScheme.error)
                }
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = { refresh() }) { Text(if (busy) "..." else "REFRESH") }
            }
        }

        Spacer(Modifier.height(16.dp))

        GCPrimaryButton(
            text = if (busy) "..." else "KILL ALL SESSIONS",
            onClick = {
                if (busy) return@GCPrimaryButton
                busy = true
                CoroutineScope(Dispatchers.IO).launch {
                    val ok = ApiRepo.panicKillAllSessions("mark")
                    withContext(Dispatchers.Main) {
                        msg = if (ok) "All sessions killed." else "Kill all failed."
                        busy = false
                        refresh()
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(10.dp))

        OutlinedButton(
            onClick = {
                if (busy) return@OutlinedButton
                busy = true
                CoroutineScope(Dispatchers.IO).launch {
                    val ok = ApiRepo.panicToggleMaintenance(null) // toggle
                    withContext(Dispatchers.Main) {
                        msg = if (ok) "Maintenance toggled." else "Toggle failed."
                        busy = false
                        refresh()
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (maintenance) "TURN MAINTENANCE OFF" else "TURN MAINTENANCE ON")
        }

        Spacer(Modifier.height(10.dp))

        OutlinedButton(
            onClick = {
                // local-only: clears alert last id so next poll replays (useful for testing)
                ctx.getSharedPreferences("gc_admin", Context.MODE_PRIVATE)
                    .edit().putInt("alertsLastId", 0).apply()
                msg = "Alerts cursor reset."
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("RESET ALERTS CURSOR")
        }

        Spacer(Modifier.height(16.dp))

        Text("Tokens / Devices", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))

        OutlinedButton(
            onClick = {
                if (busy) return@OutlinedButton
                busy = true
                CoroutineScope(Dispatchers.IO).launch {
                    val newTok = ApiRepo.tokenRotate()
                    withContext(Dispatchers.Main) {
                        if (newTok != null) {
                            ApiClient.token = newTok
                            ctx.getSharedPreferences("gc_admin", Context.MODE_PRIVATE)
                                .edit().putString("token", newTok).apply()
                            msg = "Token rotated."
                        } else {
                            msg = "Rotate failed."
                        }
                        busy = false
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("ROTATE THIS TOKEN") }

        Spacer(Modifier.height(10.dp))

        OutlinedButton(
            onClick = {
                if (busy) return@OutlinedButton
                busy = true
                CoroutineScope(Dispatchers.IO).launch {
                    val list = ApiRepo.tokensList()
                    withContext(Dispatchers.Main) {
                        if (list.isEmpty()) msg = "No tokens found."
                        else {
                            val top = list.take(3).joinToString(" | ") {
                                "#" + it.id + " " + (it.deviceName ?: "device") +
                                    (if (!it.revokedAt.isNullOrBlank()) " (revoked)" else "")
                            }
                            msg = "Top tokens: $top"
                        }
                        busy = false
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("CHECK TOKENS (TOP 3)") }
    }
}
