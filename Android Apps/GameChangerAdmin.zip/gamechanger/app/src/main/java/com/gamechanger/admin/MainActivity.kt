package com.gamechanger.admin


import android.content.Context
import android.os.Bundle
import android.graphics.Color
import androidx.work.*
import java.util.concurrent.TimeUnit
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.gamechanger.admin.ui.LoginScreen
import com.gamechanger.admin.ui.MainScaffold
import com.gamechanger.admin.ui.theme.GameChangerTheme
import com.gamechanger.admin.api.AlertsWorker
import com.gamechanger.admin.api.ApiClient

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Edge-to-edge: draw your background behind status/navigation bars.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }

        fun ensureAlertsWorker() {
    val req = PeriodicWorkRequestBuilder<AlertsWorker>(15, TimeUnit.MINUTES)
        .addTag("gc_alerts_worker")
        .build()
    WorkManager.getInstance(this).enqueueUniquePeriodicWork(
        "gc_alerts_worker",
        ExistingPeriodicWorkPolicy.UPDATE,
        req
    )
}

        val prefs = getSharedPreferences("gc_admin", Context.MODE_PRIVATE)
        val savedBase = prefs.getString("baseUrl", null)
        val savedToken = prefs.getString("token", null)
        val initialLoggedIn = !savedBase.isNullOrBlank() && !savedToken.isNullOrBlank()
        if (initialLoggedIn) {
            ApiClient.baseUrl = savedBase!!
            ApiClient.token = savedToken!!
        }

        setContent {
            GameChangerTheme {
                var loggedIn by remember { mutableStateOf(initialLoggedIn) }

                LaunchedEffect(loggedIn) {
                    if (loggedIn) ensureAlertsWorker()
                }

                if (!loggedIn) {
                    LoginScreen(onLogin = { _, _, _ -> loggedIn = true })
                } else {
                    MainScaffold()
                }
            }
        }
    }
}
