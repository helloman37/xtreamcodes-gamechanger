package com.gamechanger.admin.api

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.gamechanger.admin.R
import okhttp3.OkHttpClient
import org.json.JSONObject

class AlertsWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {

        val prefs = applicationContext.getSharedPreferences("gc_admin", Context.MODE_PRIVATE)
        val baseUrl = prefs.getString("baseUrl", null) ?: return Result.success()
        val token = prefs.getString("token", null) ?: return Result.success()
        var lastId = prefs.getInt("alertsLastId", 0)

        try {
            val url = "$baseUrl/api/mobile/alerts_poll.php?last_id=$lastId&window=10"
            val req = okhttp3.Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $token")
                .get()
                .build()

            val res = OkHttpClient().newCall(req).execute()
            if (!res.isSuccessful) return Result.retry()

            val json = JSONObject(res.body!!.string())
            val items = json.optJSONArray("items") ?: return Result.success()

            var maxId = lastId
            for (i in 0 until items.length()) {
                val a = items.getJSONObject(i)
                val id = a.optInt("id", 0)
                if (id > maxId) maxId = id

                val title = a.optString("title", "Alert")
                val body = a.optString("body", "")

                val n = NotificationCompat.Builder(applicationContext, "gc_alerts")
                    .setSmallIcon(android.R.drawable.stat_notify_error)
                    .setContentTitle(title)
                    .setContentText(body)
                    .setStyle(NotificationCompat.BigTextStyle().bigText(body))
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setAutoCancel(true)
                    .build()

                NotificationManagerCompat.from(applicationContext).notify(id, n)
            }

            if (maxId > lastId) {
                prefs.edit().putInt("alertsLastId", maxId).apply()
            }

            return Result.success()

        } catch (e: Throwable) {
            return Result.retry()
        }
    }
}
