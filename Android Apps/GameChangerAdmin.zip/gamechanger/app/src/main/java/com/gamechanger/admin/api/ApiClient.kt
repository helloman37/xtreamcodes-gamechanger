package com.gamechanger.admin.api

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import org.json.JSONObject

object ApiClient {

    // Simple in-memory cookie jar (no extra deps)
    private val cookieStore = java.util.concurrent.ConcurrentHashMap<String, MutableList<okhttp3.Cookie>>()

    private val cookieJar = object : okhttp3.CookieJar {
        override fun saveFromResponse(url: okhttp3.HttpUrl, cookies: List<okhttp3.Cookie>) {
            val key = url.host
            val list = cookieStore.getOrPut(key) { mutableListOf() }
            // replace cookies by name+path
            cookies.forEach { c ->
                val idx = list.indexOfFirst { it.name == c.name && it.path == c.path }
                if (idx >= 0) list[idx] = c else list.add(c)
            }
        }
        override fun loadForRequest(url: okhttp3.HttpUrl): List<okhttp3.Cookie> {
            val list = cookieStore[url.host] ?: return emptyList()
            val now = System.currentTimeMillis()
            // drop expired
            list.removeAll { it.expiresAt < now }
            return list.toList()
        }
    }

    private fun hasCookie(name: String): Boolean {
        val now = System.currentTimeMillis()
        cookieStore.values.forEach { list ->
            list.removeAll { it.expiresAt < now }
            if (list.any { it.name.equals(name, ignoreCase = true) }) return true
        }
        return false
    }

    val http: OkHttpClient = OkHttpClient.Builder()
        .cookieJar(cookieJar)
        .build()
private val httpNoRedirect: OkHttpClient = http.newBuilder()
        .followRedirects(false)
        .followSslRedirects(false)
        .build()
    var baseUrl: String = ""
        set(value) { field = normalizeBaseUrl(value) }
    var token = ""

    // Admin session cookie flag (for /admin/ajax endpoints that require require_admin()).
    var hasAdminSession: Boolean = false
        private set

    private fun normalizeBaseUrl(url: String): String {
        var u = url.trim()
        if (u.endsWith("/")) u = u.dropLast(1)
        return u
    }

    /** Last network error (best effort). */
    @Volatile var lastError: String? = null
        private set
    /** Lightweight GET for reachability checks, returns (httpCode, bodySnippet). */
    suspend fun rawGet(path: String): Pair<Int, String?> = withContext(Dispatchers.IO) {
        lastError = null
        val req = Request.Builder()
            .url(baseUrl + path)
            .get()
            .build()
        try {
            http.newCall(req).execute().use { res ->
                val body = res.body?.string()
                val snippet = body?.let { if (it.length > 300) it.substring(0, 300) else it }
                return@withContext res.code to snippet
            }
        } catch (e: Exception) {
            lastError = e.message
            return@withContext 0 to e.message
        }
    }


    suspend fun login(url: String, user: String, pass: String): Boolean = withContext(Dispatchers.IO) {
        lastError = null
        baseUrl = normalizeBaseUrl(url)
        token = ""
        hasAdminSession = false

        val form = FormBody.Builder()
            .add("username", user)
            .add("password", pass)
            .build()

        val req = Request.Builder()
            .url(baseUrl + "/api/mobile/login.php")
            .post(form)
            .build()

        try {
            http.newCall(req).execute().use { res ->
                val bodyStr = res.body?.string().orEmpty()
                if (!res.isSuccessful) {
                    lastError = "HTTP ${res.code}"
                    return@withContext false
                }
                val j = runCatching { JSONObject(bodyStr) }.getOrNull()
                val ok = j?.optBoolean("ok", false) ?: false
                if (!ok) {
                    val err = j?.optString("error", null)
                    val msg = j?.optString("message", null)
                    lastError = listOfNotNull(err, msg).joinToString(": ").ifBlank { "login_failed" }
                    return@withContext false
                }
                token = j?.optString("token", "") ?: ""
                if (token.isBlank()) {
                    lastError = "missing_token"
                    return@withContext false
                }
                // Try to establish an admin session cookie for /admin/ajax endpoints.
                hasAdminSession = runCatching { adminSignin(user, pass) }.getOrDefault(false)
                return@withContext true
            }
        } catch (e: Exception) {
            lastError = e.message
            return@withContext false
        }
    }

    private fun adminSignin(user: String, pass: String): Boolean {
    // Different installs use different admin entry points; try a few.
    val form = FormBody.Builder()
        .add("username", user)
        .add("password", pass)
        .build()

    fun tryPost(path: String): Boolean {
        val req = Request.Builder()
            .url("$baseUrl$path")
            .post(form)
            .build()

        return try {
            httpNoRedirect.newCall(req).execute().use { res ->
                // Successful login is typically a redirect (302/303) into the admin area.
                if (res.code in 300..399) return true

                // Fallback: some setups respond 200 but include dashboard/logout markers.
                val s = res.body?.string().orEmpty()
                if (s.contains("dashboard", ignoreCase = true)) return true
                if (s.contains("Logout", ignoreCase = true)) return true
                if (s.contains("nav-sidebar", ignoreCase = true)) return true
                false
            }
        } catch (_: Exception) {
            false
        }
    }

    if (tryPost("/admin/signin.php")) return true
    if (tryPost("/admin/login.php")) return true
    if (tryPost("/admin/index.php")) return true
    return false
}

    fun authGet(endpoint: String): Request {
        return Request.Builder()
            .url("$baseUrl/api/mobile/$endpoint")
            .addHeader("Authorization", "Bearer $token")
            .get()
            .build()
    }

    fun authPost(endpoint: String, body: RequestBody): Request {
        return Request.Builder()
            .url("$baseUrl/api/mobile/$endpoint")
            .addHeader("Authorization", "Bearer $token")
            .post(body)
            .build()
    }

    fun adminGet(pathWithQuery: String): Request {
        val p = if (pathWithQuery.startsWith("/")) pathWithQuery.drop(1) else pathWithQuery
        return Request.Builder()
            .url("$baseUrl/$p")
            .get()
            .build()
    }


    suspend fun ping(url: String): Pair<Boolean, String?> = withContext(Dispatchers.IO) {
        baseUrl = normalizeBaseUrl(url)

        fun tryGet(path: String): Pair<Int, String> {
            val req = Request.Builder()
                .url(baseUrl + path)
                .get()
                .build()
            return httpNoRedirect.newCall(req).execute().use { res ->
                val body = res.body?.string().orEmpty()
                res.code to body
            }
        }

        try {
            // 1) Prefer the dedicated ping endpoint if it exists
            runCatching {
                val (code, raw) = tryGet("/api/mobile/ping.php")
                if (code in 200..299) {
                    if (raw.trim().equals("ok", ignoreCase = true)) return@withContext Pair(true, null)
                    val obj = runCatching { JSONObject(raw) }.getOrNull()
                    if (obj?.optBoolean("ok", false) == true) return@withContext Pair(true, null)
                    return@withContext Pair(true, null)
                }
            }

            // 2) Fallback: admin signin page should exist on basically every panel install
            runCatching {
                val (code, body) = tryGet("/admin/signin.php")
                if (code in 200..399) return@withContext Pair(true, null)
                if (body.contains("signin", ignoreCase = true)) return@withContext Pair(true, null)
            }

            // 3) Last resort: base URL reachable (may redirect)
            val (code, _) = tryGet("/")
            if (code in 200..399) return@withContext Pair(true, null)

            Pair(false, "HTTP $code")
        } catch (e: Exception) {
            Pair(false, e.message ?: "network_error")
        }
    }

}
