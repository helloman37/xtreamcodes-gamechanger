package com.gamechanger.admin.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.gamechanger.admin.api.ApiRepo
import com.gamechanger.admin.api.AnomalyRow
import kotlinx.coroutines.*

@Composable
fun AnomalyScreen() {
    var items by remember { mutableStateOf<List<AnomalyRow>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }

    fun load() {
        if (busy) return
        busy = true
        CoroutineScope(Dispatchers.IO).launch {
            val r = ApiRepo.anomalyList(minutes=180)
            withContext(Dispatchers.Main) {
                items = r
                busy = false
            }
        }
    }

    LaunchedEffect(Unit) { load() }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Anomaly Center", style = MaterialTheme.typography.titleLarge)
        Text("Flags • quick action", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))

        Button(onClick = { load() }) { Text(if (busy) "..." else "REFRESH") }

        Spacer(Modifier.height(12.dp))

        if (!busy && items.isEmpty()) {
            Text("No anomalies in this window.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(12.dp))
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(items) { a ->
                Card(
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Text("${a.username ?: "User"}  #${a.userId}")
                        Text("IPs: ${a.ipCount}  FPs: ${a.fpCount}  Err: ${a.errCount}  Hits: ${a.hits}",
                            color = MaterialTheme.colorScheme.onSurfaceVariant)

                        Spacer(Modifier.height(10.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedButton(onClick = {
                                CoroutineScope(Dispatchers.IO).launch {
                                    ApiRepo.userSetStatus(a.userId, "suspended")
                                }
                            }) { Text("SUSPEND") }

                            OutlinedButton(onClick = {
                                CoroutineScope(Dispatchers.IO).launch {
                                    ApiRepo.userKillSessions(a.userId)
                                }
                            }) { Text("KILL SESS") }
                        }
                    }
                }
            }
        }
    }
}
