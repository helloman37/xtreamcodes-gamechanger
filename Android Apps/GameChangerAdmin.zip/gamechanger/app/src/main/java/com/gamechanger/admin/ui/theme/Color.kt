package com.gamechanger.admin.ui.theme

import androidx.compose.ui.graphics.Color

// Panel-like palette: deep dark + orange accent
val GC_BG = Color(0xFF0B0F14)
val GC_SURFACE = Color(0xFF111826)
val GC_SURFACE_2 = Color(0xFF0F1622)
val GC_CARD = Color(0xFF121B2A)
val GC_BORDER = Color(0xFF233044)

val GC_TEXT = Color(0xFFE8EEF7)
val GC_TEXT_MUTE = Color(0xFFA6B0C2)

val GC_ORANGE = Color(0xFFFF7A00)
val GC_ORANGE_2 = Color(0xFFFF9A3C)

val GC_RED = Color(0xFFFF3B30)
val GC_GREEN = Color(0xFF34C759)
val GC_YELLOW = Color(0xFFFFCC00)
