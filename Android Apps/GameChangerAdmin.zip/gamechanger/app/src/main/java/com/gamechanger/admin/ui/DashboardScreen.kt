package com.gamechanger.admin.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.gamechanger.admin.api.ApiRepo
import com.gamechanger.admin.api.LiveStatus
import com.gamechanger.admin.ui.components.StatCard
import com.gamechanger.admin.ui.theme.GC_GREEN
import com.gamechanger.admin.ui.theme.GC_ORANGE
import com.gamechanger.admin.ui.theme.GC_RED
import kotlinx.coroutines.*

@Composable
fun DashboardScreen(){

    var data by remember { mutableStateOf<LiveStatus?>(null) }
    var anomalyRows by remember { mutableStateOf<List<com.gamechanger.admin.api.AnomalyRow>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf<String?>(null) }

    fun load() {
        if (busy) return
        busy = true
        err = null
        CoroutineScope(Dispatchers.IO).launch {
            val r = ApiRepo.liveStatus()
            val a = ApiRepo.anomalyList(minutes = 180)
            withContext(Dispatchers.Main) {
                data = r
                anomalyRows = a.take(8)
                busy = false
                if (r == null) err = "Failed to load"
            }
        }
    }

    LaunchedEffect(Unit) { load() }

        val scroll = rememberScrollState()

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(scroll)
            .padding(16.dp)
    ) {

        Text("Live Overview", style = MaterialTheme.typography.titleLarge)
        Text("Quick ops snapshot", color = MaterialTheme.colorScheme.onSurfaceVariant)

        Spacer(Modifier.height(12.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = { load() }) { Text(if (busy) "..." else "REFRESH") }
            if (data != null) {
                OutlinedButton(onClick = { /* placeholder */ }) { Text("${data!!.windowMinutes}m window") }
            }
        }

        if (err != null) {
            Spacer(Modifier.height(10.dp))
            Text(err!!, color = MaterialTheme.colorScheme.error)
        }

        Spacer(Modifier.height(12.dp))

        val activeUsers = data?.activeUsers?.toString() ?: "—"
        val activeSessions = data?.activeSessions?.toString() ?: "—"
        val activeConns = data?.activeConnections?.toString() ?: "—"
                val anomalies = anomalyRows.size.toString()
        val badReq = if (data == null) "—" else "${data!!.requestsBad}/${data!!.requestsTotal}"

        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard(
                title = "Active Users",
                value = activeUsers,
                sub = "Distinct users (5m)",
                badgeText = "LIVE",
                badgeColor = GC_GREEN,
                modifier = Modifier.fillMaxWidth()
            )

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                StatCard(
                    title = "Sessions",
                    value = activeSessions,
                    sub = "Connections (5m)",
                    badgeText = "RUN",
                    badgeColor = GC_ORANGE,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Connections",
                    value = activeConns,
                    sub = "Distinct IPs (5m)",
                    badgeText = "NET",
                    badgeColor = GC_ORANGE,
                    modifier = Modifier.weight(1f)
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                StatCard(
                    title = "Anomaly Users",
                    value = anomalies,
                    sub = "Flagged (window)",
                    badgeText = "CHECK",
                    badgeColor = GC_RED,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Bad Requests",
                    value = badReq,
                    sub = "Bad/Total (window)",
                    badgeText = "OPS",
                    badgeColor = GC_ORANGE,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        
Spacer(Modifier.height(16.dp))
Text("Anomaly Details", style = MaterialTheme.typography.titleMedium)
Text("Top flagged users (last 180m)", color = MaterialTheme.colorScheme.onSurfaceVariant)
Spacer(Modifier.height(8.dp))

if (anomalyRows.isEmpty()) {
    Text("No anomalies in this window.", color = MaterialTheme.colorScheme.onSurfaceVariant)
} else {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            anomalyRows.forEach { row ->
                Column {
                    Text(row.username ?: ("User #" + row.userId), style = MaterialTheme.typography.titleSmall)
                    Text(
                        "hits ${row.hits} • ips ${row.ipCount} • fps ${row.fpCount} • errors ${row.errCount}",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Divider()
            }
        }
    }
}
Spacer(Modifier.height(10.dp))
    }
}