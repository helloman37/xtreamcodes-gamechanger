package com.gamechanger.admin.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = GC_ORANGE,
    onPrimary = Color.Black,
    secondary = GC_ORANGE_2,
    onSecondary = Color.Black,
    background = GC_BG,
    onBackground = GC_TEXT,
    surface = GC_SURFACE,
    onSurface = GC_TEXT,
    surfaceVariant = GC_SURFACE_2,
    onSurfaceVariant = GC_TEXT_MUTE,
    outline = GC_BORDER,
    error = GC_RED,
    onError = Color.White
)

@Composable
fun GameChangerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColors,
        typography = Typography,
        content = content
    )
}
