package com.gamechanger.admin

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity

class SplashActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_splash)

    // Brief branded intro before the login/compose UI
    window.decorView.postDelayed({
      startActivity(Intent(this, MainActivity::class.java))
      overridePendingTransition(0, 0)
      finish()
      overridePendingTransition(0, 0)
    }, 650)
  }
}
