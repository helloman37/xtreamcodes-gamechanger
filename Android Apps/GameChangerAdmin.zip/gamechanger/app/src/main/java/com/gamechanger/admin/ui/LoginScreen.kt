package com.gamechanger.admin.ui

import android.content.Context
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Color
import com.gamechanger.admin.R
import com.gamechanger.admin.api.ApiClient
import kotlinx.coroutines.launch

@Composable
fun LoginScreen(
    onLogin: (baseUrl: String, username: String, password: String) -> Unit
) {
    var url by remember { mutableStateOf("") }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF070B12), Color(0xFF0B1220), Color(0xFF070B12))
                )
            )
    ) {
        // Background art
        Image(
            painter = painterResource(id = R.drawable.gc_splash_bg),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(WindowInsets.systemBars.asPaddingValues())
                .padding(horizontal = 20.dp, vertical = 18.dp),
            verticalArrangement = Arrangement.Top
        ) {
            Text("Game Changer", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text("Admin Remote", fontSize = 14.sp, color = Color(0xFF9FB0C6))

            Spacer(Modifier.height(18.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
                    .background(Color(0xCC0B1220), RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    label = { Text("Panel URL") },
                    singleLine = true,
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color(0xFF0B1220),
                        unfocusedContainerColor = Color(0xFF0B1220)
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = user,
                    onValueChange = { user = it },
                    label = { Text("Username") },
                    singleLine = true,
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color(0xFF0B1220),
                        unfocusedContainerColor = Color(0xFF0B1220)
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = pass,
                    onValueChange = { pass = it },
                    label = { Text("Password") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color(0xFF0B1220),
                        unfocusedContainerColor = Color(0xFF0B1220)
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(Modifier.height(12.dp))

                Button(
                    onClick = {
                        val base = url.trim()
                        val u = user.trim()
                        msg = null
                        if (base.isEmpty()) {
                            msg = "Enter Panel URL"
                            return@Button
                        }

                        busy = true
                        scope.launch {
                            val ok = ApiClient.login(base, u, pass)
                            busy = false
                            if (ok) {
                                ctx.getSharedPreferences("gc_admin", Context.MODE_PRIVATE)
                                    .edit()
                                    .putString("baseUrl", ApiClient.baseUrl)
                                    .putString("token", ApiClient.token)
                                    .apply()
                                onLogin(ApiClient.baseUrl, u, pass)
                            } else {
                                msg = ApiClient.lastError ?: "LOGIN FAILED"
                            }
                        }
                    },
                    enabled = !busy,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF8A00)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Text("LOGIN", color = Color.Black, fontWeight = FontWeight.Bold)
                }


                if (!msg.isNullOrBlank()) {
                    Spacer(Modifier.height(10.dp))
                    Text(
                        msg!!,
                        color = if (msg == "OK") Color(0xFF6EE787) else Color(0xFFFF6B6B),
                        fontSize = 13.sp
                    )
                }
            }

            Spacer(Modifier.weight(1f))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                Text("Phone-only quick ops • v1.1", fontSize = 12.sp, color = Color(0xFF8FA0B6))
            }
        }
    }
}
