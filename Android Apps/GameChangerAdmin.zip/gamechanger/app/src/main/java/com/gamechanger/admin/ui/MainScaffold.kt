package com.gamechanger.admin.ui

import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.padding
import androidx.navigation.compose.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import com.gamechanger.admin.ui.theme.GC_ORANGE

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScaffold() {
    val navController = rememberNavController()

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Game Changer") },
                actions = {
                    IconButton(onClick = { navController.navigate(NavItem.Panic.route) }) {
                        Icon(Icons.Filled.Warning, contentDescription = "Panic", tint = GC_ORANGE)
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = navBackStackEntry?.destination?.route

                bottomNavItems.forEach { item ->
                    NavigationBarItem(
                        selected = currentRoute == item.route,
                        onClick = {
                            // Keep it simple (works across nav-compose versions)
                            navController.navigate(item.route) {
                                launchSingleTop = true
                                popUpTo(NavItem.Dashboard.route) { inclusive = false }
                            }
                        },
                        icon = { Icon(item.icon, contentDescription = item.label) },
                        label = { Text(item.label) }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = NavItem.Dashboard.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(NavItem.Dashboard.route) { DashboardScreen() }
            composable(NavItem.Users.route) { UsersScreen() }
            composable(NavItem.Streams.route) { StreamsScreen() }
            composable(NavItem.Anomaly.route) { AnomalyScreen() }
            composable(NavItem.Panic.route) { PanicScreen() }
        }
    }
}
