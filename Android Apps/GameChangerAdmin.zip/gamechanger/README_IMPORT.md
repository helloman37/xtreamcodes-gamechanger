Open this folder in Android Studio. If wrapper jar is missing, use 'Gradle sync' and it will fetch.
