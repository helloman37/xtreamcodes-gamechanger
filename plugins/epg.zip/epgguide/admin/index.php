\
<?php
// plugins/epgguide/admin/index.php
/** @var PDO $GC_PDO */
/** @var string $GC_PLUGIN_ID */
/** @var array $GC_PLUGIN_MANIFEST */

require_once __DIR__ . '/../../../helpers.php';
require_once __DIR__ . '/../../../plugins_core.php';

$pdo = $GC_PDO;

$k_hours = 'hours_ahead';
$k_perpage = 'channels_per_page';
$k_debug = 'show_debug';

$hours_ahead = (int)gc_plugin_settings_get($pdo, 'epgguide', $k_hours, 6);
if ($hours_ahead < 2) $hours_ahead = 2;
if ($hours_ahead > 24) $hours_ahead = 24;

$channels_per_page = (int)gc_plugin_settings_get($pdo, 'epgguide', $k_perpage, 120);
if ($channels_per_page < 20) $channels_per_page = 20;
if ($channels_per_page > 400) $channels_per_page = 400;

$show_debug = (int)gc_plugin_settings_get($pdo, 'epgguide', $k_debug, 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  csrf_verify();

  $hours_ahead = (int)($_POST['hours_ahead'] ?? 6);
  if ($hours_ahead < 2) $hours_ahead = 2;
  if ($hours_ahead > 24) $hours_ahead = 24;

  $channels_per_page = (int)($_POST['channels_per_page'] ?? 120);
  if ($channels_per_page < 20) $channels_per_page = 20;
  if ($channels_per_page > 400) $channels_per_page = 400;

  $show_debug = !empty($_POST['show_debug']) ? 1 : 0;

  gc_plugin_settings_set($pdo, 'epgguide', $k_hours, (string)$hours_ahead);
  gc_plugin_settings_set($pdo, 'epgguide', $k_perpage, (string)$channels_per_page);
  gc_plugin_settings_set($pdo, 'epgguide', $k_debug, (string)$show_debug);

  if (function_exists('flash_set')) flash_set('success', 'EPG Guide settings saved.');
  header('Location: /admin/plugin.php?id=epgguide');
  exit;
}
?>

<div class="card" style="padding:18px;">
  <h2 style="margin:0 0 10px;">EPG Guide</h2>
  <div class="muted" style="margin-bottom:12px;">
    This guide reads from the panel's <code>epg_programs</code> table (the same data your Live TV cards use).
    Make sure your EPG import/sync has populated it.
  </div>

  <div style="display:flex; gap:10px; flex-wrap:wrap; margin: 0 0 16px;">
    <a class="btn" href="/portal/guide/" target="_blank" rel="noopener">Open Guide</a>
    <a class="btn" href="/admin/epg_manager.php" target="_blank" rel="noopener">EPG Manager</a>
    <a class="btn" href="/admin/epg_sync.php" target="_blank" rel="noopener">Run EPG Sync</a>
  </div>

  <form method="post">
    <?= csrf_field() ?>

    <div class="row" style="display:grid; grid-template-columns: 220px 1fr; gap:12px; align-items:center; margin-bottom:12px;">
      <div><strong>Hours Ahead</strong></div>
      <div><input type="number" name="hours_ahead" min="2" max="24" value="<?= (int)$hours_ahead ?>" style="max-width:140px;"></div>
    </div>

    <div class="row" style="display:grid; grid-template-columns: 220px 1fr; gap:12px; align-items:center; margin-bottom:12px;">
      <div><strong>Channels Per Page</strong></div>
      <div><input type="number" name="channels_per_page" min="20" max="400" value="<?= (int)$channels_per_page ?>" style="max-width:140px;"></div>
    </div>

    <div class="row" style="display:grid; grid-template-columns: 220px 1fr; gap:12px; align-items:center; margin-bottom:12px;">
      <div><strong>Show Debug Line</strong></div>
      <div>
        <label style="display:inline-flex; gap:8px; align-items:center;">
          <input type="checkbox" name="show_debug" value="1" <?= $show_debug ? 'checked' : '' ?>>
          <span class="muted">Shows “EPG rows loaded / channels matched” in the header.</span>
        </label>
      </div>
    </div>

    <button class="btn primary" type="submit">Save</button>
  </form>
</div>
