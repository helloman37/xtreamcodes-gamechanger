<?php
// Route: /movie/{id}/ (numeric id)
// Variables available from dispatcher:
//   $pdo (PDO), $GC_PLUGIN_ID, $GC_PLUGIN_MANIFEST, $GC_ROUTE_MATCH

$id = $GC_ROUTE_MATCH[1] ?? null;
$id = is_string($id) ? $id : '';

$base = (string)gc_plugin_settings_get($pdo, $GC_PLUGIN_ID, 'base_url', '');
$movie_tpl = (string)gc_plugin_settings_get($pdo, $GC_PLUGIN_ID, 'movie_template', '/movie/{id}/');
$require_login = (int)gc_plugin_settings_get($pdo, $GC_PLUGIN_ID, 'require_login', 0);

if ($require_login) {
  require_once __DIR__ . '/../../../auth.php';
  require_login();
}

$base = rtrim(trim($base), '/');
if ($base === '') {
  http_response_code(503);
  header('Content-Type: text/html; charset=utf-8');
  echo '<!doctype html><meta charset="utf-8"><title>LegalVOD</title><body style="font-family:system-ui;padding:20px;">';
  echo '<h2>LegalVOD not configured</h2><p>Set the Legal Server Base URL in Admin → System → Plugins → LegalVOD → Settings.</p>';
  echo '</body>';
  return;
}

$path = str_replace('{id}', rawurlencode($id), $movie_tpl);
$path = '/' . ltrim($path, '/');
$iframe = $base . $path;

header('Content-Type: text/html; charset=utf-8');
?><!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Movie <?= htmlspecialchars($id, ENT_QUOTES, 'UTF-8') ?></title>
  <style>
    html,body{height:100%;margin:0;background:#000}
    .wrap{position:fixed;inset:0;}
    iframe{width:100%;height:100%;border:0;}
  </style>
</head>
<body>
  <div class="wrap">
    <iframe
      src="<?= htmlspecialchars($iframe, ENT_QUOTES, 'UTF-8') ?>"
      allowfullscreen
      referrerpolicy="no-referrer"
      loading="lazy"></iframe>
  </div>
</body>
</html>
