<?php
// Route: /tv/{id}/{season}/{episode}/

$id = $GC_ROUTE_MATCH[1] ?? null;
$season = $GC_ROUTE_MATCH[2] ?? null;
$episode = $GC_ROUTE_MATCH[3] ?? null;
$id = is_string($id) ? $id : '';
$season = is_string($season) ? $season : '';
$episode = is_string($episode) ? $episode : '';

$base = (string)gc_plugin_settings_get($pdo, $GC_PLUGIN_ID, 'base_url', '');
$base = rtrim($base, '/');
$tv_tpl = (string)gc_plugin_settings_get($pdo, $GC_PLUGIN_ID, 'tv_template', '/tv/{id}/{season}/{episode}/');
$require_login = (int)gc_plugin_settings_get($pdo, $GC_PLUGIN_ID, 'require_login', 0);

if ($require_login) {
  require_once __DIR__ . '/../../../auth.php';
  require_login();
}

$base = rtrim(trim($base), '/');
if ($base === '') {
  http_response_code(503);
  header('Content-Type: text/html; charset=utf-8');
  echo '<!doctype html><meta charset="utf-8"><title>LegalVOD</title><body style="font-family:system-ui;padding:20px;">';
  echo '<h2>LegalVOD not configured</h2><p>Set the Legal Server Base URL in Admin → System → Plugins → LegalVOD → Settings.</p>';
  echo '</body>';
  return;
}

$path = $tv_tpl;
$path = str_replace('{id}', rawurlencode($id), $path);
$path = str_replace('{season}', rawurlencode($season), $path);
$path = str_replace('{episode}', rawurlencode($episode), $path);
$path = '/' . ltrim($path, '/');
$iframe = $base . $path;

$season_i = max(1, (int)$season);
$episode_i = max(1, (int)$episode);
$max_season = max($season_i, 20);
$max_episode = max($episode_i, 50);

header('Content-Type: text/html; charset=utf-8');
?><!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>TV <?= htmlspecialchars($id, ENT_QUOTES, 'UTF-8') ?> S<?= htmlspecialchars($season, ENT_QUOTES, 'UTF-8') ?>E<?= htmlspecialchars($episode, ENT_QUOTES, 'UTF-8') ?></title>
  <style>
    :root{
      --bar-h:56px;
      --bg:#0a0a0a;
      --panel:rgba(10,10,10,.88);
      --line:rgba(255,255,255,.10);
      --text:rgba(255,255,255,.92);
      --muted:rgba(255,255,255,.65);
      --pill:rgba(255,255,255,.10);
    }
    html,body{height:100%;margin:0;background:#000;color:var(--text);font-family:system-ui,-apple-system,Segoe UI,Roboto,Ubuntu,Cantarell,Noto Sans,sans-serif}
    .wrap{position:fixed;inset:0;display:flex;flex-direction:column;}
    .bar{
      height:var(--bar-h);
      display:flex;
      align-items:center;
      gap:12px;
      padding:10px 14px;
      background:linear-gradient(180deg,var(--panel),rgba(0,0,0,.35));
      border-bottom:1px solid var(--line);
      backdrop-filter: blur(10px);
      -webkit-backdrop-filter: blur(10px);
      box-sizing:border-box;
    }
    .badge{
      font-weight:800;
      letter-spacing:.5px;
      padding:6px 10px;
      border-radius:999px;
      background:rgba(255,255,255,.10);
      border:1px solid var(--line);
      user-select:none;
    }
    .controls{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
    .controls label{font-size:12px;color:var(--muted)}
    .controls select{
      background:rgba(0,0,0,.35);
      color:var(--text);
      border:1px solid var(--line);
      border-radius:10px;
      padding:6px 10px;
      outline:none;
      min-width:92px;
    }
    .spacer{flex:1}
    .hint{font-size:12px;color:var(--muted)}
    .frame{flex:1;min-height:0;}
    iframe{width:100%;height:100%;border:0;display:block;background:#000;}
  </style>
</head>
<body>
  <div class="wrap">
    <div class="bar">
      <div class="badge">LegalVOD</div>

      <div class="controls">
        <label for="lvSeason">Season</label>
        <select id="lvSeason">
          <?php for ($i=1;$i<=$max_season;$i++): ?>
            <option value="<?= $i ?>" <?= $i===$season_i?'selected':'' ?>>S<?= $i ?></option>
          <?php endfor; ?>
        </select>

        <label for="lvEpisode">Episode</label>
        <select id="lvEpisode">
          <?php for ($i=1;$i<=$max_episode;$i++): ?>
            <option value="<?= $i ?>" <?= $i===$episode_i?'selected':'' ?>>E<?= $i ?></option>
          <?php endfor; ?>
        </select>
      </div>

      <div class="spacer"></div>
      <div class="hint">TV <?= htmlspecialchars($id, ENT_QUOTES, 'UTF-8') ?></div>
    </div>

    <div class="frame">
      <iframe
        id="lvFrame"
        src="<?= htmlspecialchars($iframe, ENT_QUOTES, 'UTF-8') ?>"
        allowfullscreen
        referrerpolicy="no-referrer"
        loading="lazy"></iframe>
    </div>
  </div>

  <script>
  (function(){
    const id = <?= json_encode($id) ?>;
    const base = <?= json_encode($base) ?>;
    const tpl = <?= json_encode($tv_tpl) ?>;

    const seasonSel = document.getElementById('lvSeason');
    const episodeSel = document.getElementById('lvEpisode');
    const frame = document.getElementById('lvFrame');

    function buildPath(season, episode){
      let p = String(tpl || '/tv/{id}/{season}/{episode}/');
      p = p.replace('{id}', encodeURIComponent(String(id)));
      p = p.replace('{season}', encodeURIComponent(String(season)));
      p = p.replace('{episode}', encodeURIComponent(String(episode)));
      if (!p.startsWith('/')) p = '/' + p;
      return p;
    }
    function buildSrc(season, episode){
      const b = String(base || '').replace(/\/+$/,'');
      return b + buildPath(season, episode);
    }
    function sync(){
      const s = parseInt(seasonSel.value, 10) || 1;
      const e = parseInt(episodeSel.value, 10) || 1;
      frame.src = buildSrc(s, e);

      // Update URL path for copy/paste (no reload)
      let prefix = window.location.pathname || '';
      const idx = prefix.indexOf('/tv/');
      if (idx !== -1) prefix = prefix.slice(0, idx);
      const newPath = (prefix || '') + '/tv/' + encodeURIComponent(String(id)) + '/' + s + '/' + e + '/';
      try { history.replaceState({}, '', newPath); } catch(e) {}
    }

    seasonSel.addEventListener('change', function(){
      // reset to episode 1 when changing season
      if (episodeSel) episodeSel.value = '1';
      sync();
    });
    episodeSel.addEventListener('change', sync);
  })();
  </script>
</body>
</html>
