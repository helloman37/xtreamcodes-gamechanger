<?php
// Variables provided by /admin/plugin.php wrapper:
//   $GC_PDO, $GC_PLUGIN_ID, $GC_PLUGIN_MANIFEST

$pdo = $GC_PDO;
$pid = $GC_PLUGIN_ID;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['legalvod_save'])) {
  $base = trim((string)($_POST['base_url'] ?? ''));
  $movie_tpl = trim((string)($_POST['movie_template'] ?? '/movie/{id}/'));
  $tv_tpl = trim((string)($_POST['tv_template'] ?? '/tv/{id}/{season}/{episode}/'));
  $require_login = isset($_POST['require_login']) ? 1 : 0;

  // normalize
  $base = rtrim($base, '/');
  if ($base !== '' && !preg_match('~^https?://~i', $base)) {
    flash_set('Base URL must start with http:// or https://', 'err');
  } else {
    gc_plugin_settings_set($pdo, $pid, 'base_url', $base);
    gc_plugin_settings_set($pdo, $pid, 'movie_template', $movie_tpl);
    gc_plugin_settings_set($pdo, $pid, 'tv_template', $tv_tpl);
    gc_plugin_settings_set($pdo, $pid, 'require_login', (int)$require_login);
    flash_set('Saved.', 'ok');
    header('Location: plugin.php?plugin=' . urlencode($pid));
    exit;
  }
}

$base = (string)gc_plugin_settings_get($pdo, $pid, 'base_url', '');
$movie_tpl = (string)gc_plugin_settings_get($pdo, $pid, 'movie_template', '/movie/{id}/');
$tv_tpl = (string)gc_plugin_settings_get($pdo, $pid, 'tv_template', '/tv/{id}/{season}/{episode}/');
$require_login = (int)gc_plugin_settings_get($pdo, $pid, 'require_login', 0);

function legalvod_example(string $base, string $tpl, array $vars): string {
  $url = $tpl;
  foreach ($vars as $k=>$v) {
    $url = str_replace('{' . $k . '}', (string)$v, $url);
  }
  $url = '/' . ltrim($url, '/');
  return rtrim($base, '/') . $url;
}
?>

<h2 style="margin-top:0;">LegalVOD Settings</h2>
<p class="muted" style="margin-top:-6px;">Controls the iframe target used by the public routes this plugin adds.</p>

<form method="post" style="display:grid; gap:10px; max-width:720px;">
  <input type="hidden" name="legalvod_save" value="1">

  <label>
    <div style="font-weight:900; margin-bottom:6px;">Legal Server Base URL</div>
    <input type="text" name="base_url" value="<?= e($base) ?>" placeholder="https://legalserver" style="width:100%;">
    <div class="muted" style="margin-top:6px;">No trailing slash. Example: <span class="code">https://legalserver</span></div>
  </label>

  <label>
    <div style="font-weight:900; margin-bottom:6px;">Movie Path Template</div>
    <input type="text" name="movie_template" value="<?= e($movie_tpl) ?>" placeholder="/movie/{id}/" style="width:100%;">
    <div class="muted" style="margin-top:6px;">Use <span class="code">{id}</span></div>
  </label>

  <label>
    <div style="font-weight:900; margin-bottom:6px;">TV Path Template</div>
    <input type="text" name="tv_template" value="<?= e($tv_tpl) ?>" placeholder="/tv/{id}/{season}/{episode}/" style="width:100%;">
    <div class="muted" style="margin-top:6px;">Use <span class="code">{id}</span>, <span class="code">{season}</span>, <span class="code">{episode}</span></div>
  </label>

  <label style="display:flex; gap:10px; align-items:center;">
    <input type="checkbox" name="require_login" value="1" <?= $require_login ? 'checked' : '' ?>>
    <div>
      <div style="font-weight:900;">Require user login</div>
      <div class="muted">If checked, routes will redirect to <span class="code">/login.php</span> when not logged in.</div>
    </div>
  </label>

  <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
    <button class="btn" type="submit">Save</button>
    <a class="btn gray" href="plugins.php">Back</a>
  </div>
</form>

<hr style="border:0; border-top:1px solid var(--line); margin:14px 0;">

<h3 style="margin:0 0 6px 0;">Examples</h3>
<div class="muted" style="margin-bottom:10px;">What the iframe will point at when a user visits your panel routes:</div>

<div style="display:grid; gap:8px;">
  <div><span class="code">/movie/123/</span> → <span class="code"><?= e(legalvod_example($base, $movie_tpl, ['id'=>123])) ?></span></div>
  <div><span class="code">/tv/42/1/3/</span> → <span class="code"><?= e(legalvod_example($base, $tv_tpl, ['id'=>42,'season'=>1,'episode'=>3])) ?></span></div>
</div>
