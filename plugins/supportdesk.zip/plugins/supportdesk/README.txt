Support Desk Plugin (supportdesk)

Install:
- Admin -> System -> Plugins -> Upload this ZIP
- Enable "Support Desk"
- Add rewrite rules from htaccess-snippet.txt into your web root .htaccess

Portal URL:
- /portal/support/

Admin:
- Admin -> System -> Plugins -> Support Desk (Settings)
