<?php
// plugins/supportdesk/routes/portal_view.php

require_once __DIR__ . '/../../../portal/_init.php';
require_once __DIR__ . '/_lib.php';

supportdesk_db_init($pdo);
supportdesk_require_portal_enabled($pdo);

$PORTAL_PAGE = 'support';

$ticketId = (int)($GC_ROUTE_MATCH[1] ?? 0);
if ($ticketId < 1) { http_response_code(404); echo 'Not found'; exit; }

// Load ticket (must belong to this user)
$st = $pdo->prepare("SELECT * FROM support_tickets WHERE id=? AND user_id=? LIMIT 1");
$st->execute([$ticketId, (int)$user['id']]);
$ticket = $st->fetch(PDO::FETCH_ASSOC);
if (!$ticket) { http_response_code(404); echo 'Not found'; exit; }

$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  csrf_validate();
  $action = (string)($_POST['action'] ?? '');
  if ($action === 'reply') {
    $msg = supportdesk_clean_message((string)($_POST['message'] ?? ''));
    if ($msg === '') {
      $err = 'Message required.';
    } else {
      $now = supportdesk_now();
      $pdo->beginTransaction();
      try {
        $st2 = $pdo->prepare("INSERT INTO support_messages (ticket_id, author_type, author_ref, message, created_at)
                              VALUES (?,?,?,?,?)");
        $st2->execute([$ticketId, 'user', (string)$user['id'], $msg, $now]);

        // Reopen on user reply if it was answered/closed
        $newStatus = strtolower((string)($ticket['status'] ?? 'open'));
        if (in_array($newStatus, ['answered','closed'], true)) $newStatus = 'open';

        $st3 = $pdo->prepare("UPDATE support_tickets
                              SET status=?, updated_at=?, last_message_at=?, last_author='user'
                              WHERE id=? AND user_id=?");
        $st3->execute([$newStatus, $now, $now, $ticketId, (int)$user['id']]);

        $pdo->commit();
        flash_set('Reply sent.', 'ok');
        header('Location: /portal/support/' . $ticketId . '/');
        exit;
      } catch (Throwable $t) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $err = 'Could not send reply.';
      }
    }
  } elseif ($action === 'close') {
    $now = supportdesk_now();
    $st4 = $pdo->prepare("UPDATE support_tickets SET status='closed', updated_at=?, last_message_at=? WHERE id=? AND user_id=?");
    $st4->execute([$now, $now, $ticketId, (int)$user['id']]);
    flash_set('Ticket closed.', 'ok');
    header('Location: /portal/support/' . $ticketId . '/');
    exit;
  }
}

// Reload ticket + messages
$st = $pdo->prepare("SELECT * FROM support_tickets WHERE id=? AND user_id=? LIMIT 1");
$st->execute([$ticketId, (int)$user['id']]);
$ticket = $st->fetch(PDO::FETCH_ASSOC);

$stM = $pdo->prepare("SELECT * FROM support_messages WHERE ticket_id=? ORDER BY id ASC");
$stM->execute([$ticketId]);
$msgs = $stM->fetchAll(PDO::FETCH_ASSOC) ?: [];

include __DIR__ . '/../../../portal/_layout_top.php';
?>
<div class="card" style="margin-bottom:14px;">
  <div style="display:flex; align-items:center; justify-content:space-between; gap:10px; flex-wrap:wrap;">
    <div>
      <h2 style="margin:0;">Ticket #<?= e($ticketId) ?></h2>
      <div class="muted" style="margin-top:6px;"><?= e($ticket['subject'] ?? '') ?></div>
    </div>
    <div style="display:flex; gap:8px; align-items:center;">
      <?= supportdesk_portal_status_badge((string)($ticket['status'] ?? 'open')) ?>
      <a class="btn btn-small gray" href="/portal/support/">← Back</a>
    </div>
  </div>
</div>

<div class="card">
  <h3 style="margin-top:0;">Conversation</h3>

  <?php foreach ($msgs as $m): ?>
    <?php
      $who = ($m['author_type'] ?? '') === 'admin' ? 'Support' : 'You';
      $ts  = (string)($m['created_at'] ?? '');
    ?>
    <div style="padding:10px; border:1px solid #2a2f3a; border-radius:12px; margin-bottom:10px; background:#0d0f14; color:#e6f1ff;">
      <div style="display:flex; justify-content:space-between; gap:10px; align-items:center;">
        <b style="color:#e6f1ff;"><?= e($who) ?></b>
        <span class="muted" style="font-size:12px;"><?= e($ts) ?></span>
      </div>
      <div style="margin-top:8px; line-height:1.45;"><?= supportdesk_render_message((string)($m['message'] ?? '')) ?></div>
    </div>
  <?php endforeach; ?>

  <?php if ($err): ?>
    <div class="card notice" style="margin:10px 0;"><?= e($err) ?></div>
  <?php endif; ?>

  <?php $status = strtolower((string)($ticket['status'] ?? 'open')); ?>
  <?php if ($status !== 'closed'): ?>
    <form method="post" style="margin-top:12px;">
      <?= csrf_input() ?>
      <input type="hidden" name="action" value="reply">
      <label class="muted">Reply</label>
      <textarea name="message" rows="5" required style="width:100%; padding:10px; border-radius:10px; border:1px solid #2a2f3a; background:#0d0f14; color:#e6f1ff;"></textarea>
      <div style="display:flex; gap:10px; margin-top:10px; flex-wrap:wrap;">
        <button class="btn" type="submit">Send Reply</button>
      </div>
    </form>

    <form method="post" style="margin-top:10px;">
      <?= csrf_input() ?>
      <input type="hidden" name="action" value="close">
      <button class="btn btn-small gray" type="submit" onclick="return confirm('Close this ticket?');">Close Ticket</button>
    </form>
  <?php else: ?>
    <div class="card notice" style="margin-top:12px;">
      This ticket is closed. If you still need help, open a new one.
    </div>
  <?php endif; ?>
</div>

<?php include __DIR__ . '/../../../portal/_layout_bottom.php'; ?>
