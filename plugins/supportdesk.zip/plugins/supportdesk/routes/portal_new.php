<?php
// plugins/supportdesk/routes/portal_new.php

require_once __DIR__ . '/../../../portal/_init.php';
require_once __DIR__ . '/_lib.php';

supportdesk_db_init($pdo);
supportdesk_require_portal_enabled($pdo);

$PORTAL_PAGE = 'support';

$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  csrf_validate();
  $subject = supportdesk_clean_subject((string)($_POST['subject'] ?? ''));
  $message = supportdesk_clean_message((string)($_POST['message'] ?? ''));
  $priority = strtolower(trim((string)($_POST['priority'] ?? 'normal')));
  if (!in_array($priority, ['low','normal','high'], true)) $priority = 'normal';

  if ($subject === '' || $message === '') {
    $err = 'Subject and message are required.';
  } else {
    $now = supportdesk_now();
    $pdo->beginTransaction();
    try {
      $st = $pdo->prepare("INSERT INTO support_tickets (user_id, subject, status, priority, created_at, updated_at, last_message_at, last_author)
                           VALUES (?,?,?,?,?,?,?,?)");
      $st->execute([(int)$user['id'], $subject, 'open', $priority, $now, $now, $now, 'user']);
      $ticketId = (int)$pdo->lastInsertId();

      $st2 = $pdo->prepare("INSERT INTO support_messages (ticket_id, author_type, author_ref, message, created_at)
                            VALUES (?,?,?,?,?)");
      $st2->execute([$ticketId, 'user', (string)$user['id'], $message, $now]);

      $pdo->commit();
      flash_set('Ticket created (#' . $ticketId . ').', 'ok');
      header('Location: /portal/support/' . $ticketId . '/');
      exit;
    } catch (Throwable $t) {
      if ($pdo->inTransaction()) $pdo->rollBack();
      $err = 'Could not create ticket.';
    }
  }
}

include __DIR__ . '/../../../portal/_layout_top.php';
?>
<div class="card" style="margin-bottom:14px;">
  <div style="display:flex; align-items:center; justify-content:space-between; gap:10px; flex-wrap:wrap;">
    <h2 style="margin:0;">New Support Ticket</h2>
    <a class="btn btn-small gray" href="/portal/support/">← Back</a>
  </div>
  <p class="muted" style="margin:8px 0 0 0;">Be specific. The more detail, the faster the fix.</p>
</div>

<div class="card">
  <?php if ($err): ?>
    <div class="card notice" style="margin-bottom:12px;"><?= e($err) ?></div>
  <?php endif; ?>

  <form method="post">
    <?= csrf_input() ?>
    <div style="display:grid; gap:10px;">
      <div>
        <label class="muted">Subject</label>
        <input name="subject" required placeholder="Example: Live TV freezes on Firestick" style="width:100%; padding:10px; border-radius:10px; border:1px solid #2a2f3a; background:#0d0f14; color:#e6f1ff;">
      </div>

      <div>
        <label class="muted">Priority</label>
        <select name="priority" style="width:100%; padding:10px; border-radius:10px; border:1px solid #2a2f3a; background:#0d0f14; color:#e6f1ff;">
          <option value="normal" selected>Normal</option>
          <option value="low">Low</option>
          <option value="high">High</option>
        </select>
      </div>

      <div>
        <label class="muted">Message</label>
        <textarea name="message" required rows="8" placeholder="What happened? What device? Any error text?" style="width:100%; padding:10px; border-radius:10px; border:1px solid #2a2f3a; background:#0d0f14; color:#e6f1ff;"></textarea>
      </div>

      <div style="display:flex; gap:10px;">
        <button class="btn" type="submit">Create Ticket</button>
        <a class="btn btn-small gray" href="/portal/support/">Cancel</a>
      </div>
    </div>
  </form>
</div>

<?php include __DIR__ . '/../../../portal/_layout_bottom.php'; ?>
