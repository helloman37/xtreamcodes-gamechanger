<?php
// plugins/supportdesk/routes/portal_list.php

require_once __DIR__ . '/../../../portal/_init.php';
require_once __DIR__ . '/_lib.php';

supportdesk_db_init($pdo);
supportdesk_require_portal_enabled($pdo);

$PORTAL_PAGE = 'support';

// Tickets for this user
$st = $pdo->prepare("SELECT id, subject, status, priority, last_message_at, updated_at
                     FROM support_tickets
                     WHERE user_id=?
                     ORDER BY last_message_at DESC, id DESC");
$st->execute([(int)$user['id']]);
$tickets = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];

include __DIR__ . '/../../../portal/_layout_top.php';
?>
<div class="card" style="margin-bottom:14px;">
  <div style="display:flex; align-items:center; justify-content:space-between; gap:10px; flex-wrap:wrap;">
    <h2 style="margin:0;">Support Desk</h2>
    <a class="btn" href="/portal/support/new/">+ New Ticket</a>
  </div>
  <p class="muted" style="margin:8px 0 0 0;">Need help? Open a ticket and we’ll reply here.</p>
</div>

<div class="card">
  <h3 style="margin-top:0;">My Tickets</h3>

  <?php if (!$tickets): ?>
    <p class="muted">No tickets yet.</p>
  <?php else: ?>
    <div style="overflow:auto;">
      <table style="width:100%; border-collapse:collapse;">
        <thead>
          <tr>
            <th style="text-align:left; padding:10px;">ID</th>
            <th style="text-align:left; padding:10px;">Subject</th>
            <th style="text-align:left; padding:10px;">Status</th>
            <th style="text-align:left; padding:10px;">Last Update</th>
            <th style="text-align:left; padding:10px;"></th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($tickets as $t): ?>
          <tr>
            <td style="padding:10px;"><span class="code"><?= e($t['id']) ?></span></td>
            <td style="padding:10px;"><?= e($t['subject']) ?></td>
            <td style="padding:10px;"><?= supportdesk_portal_status_badge((string)$t['status']) ?></td>
            <td style="padding:10px;" class="muted"><?= e($t['last_message_at'] ?: $t['updated_at']) ?></td>
            <td style="padding:10px; text-align:right;">
              <a class="btn btn-small gray" href="/portal/support/<?= urlencode((string)$t['id']) ?>/">View</a>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<div class="card notice" style="margin-top:14px;">
  <b>Tip:</b> If a video won’t play, include the title, the exact device, and a screenshot.
</div>

<?php include __DIR__ . '/../../../portal/_layout_bottom.php'; ?>
