<?php
// plugins/watchlist/admin/index.php
// Runs inside /admin/plugin.php wrapper. DB is available as $GC_PDO.
$pdo = $GC_PDO ?? null;
if (!$pdo || !($pdo instanceof PDO)) {
  echo "<div style='padding:12px'>DB not available.</div>";
  return;
}
require_once __DIR__ . '/../lib_watchlist.php';
wl_db_init($pdo);
$backend = function_exists('wl_backend') ? wl_backend($pdo) : 'db';

$total = 0;
try {
  if ($backend === 'db') {
    $total = (int)($pdo->query("SELECT COUNT(*) FROM watchlist_items")->fetchColumn() ?: 0);
  } elseif ($backend === 'file') {
    $dir = wl_storage_dir();
    $total = $dir ? count(glob(rtrim($dir,'/\\') . '/u*.json') ?: []) : 0;
  } else {
    $total = 0;
  }
} catch (Throwable $t) {}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['wipe_all']) && ($_POST['wipe_all'] === 'yes')) {
  try {
    $r = function_exists('wl_admin_wipe_all') ? wl_admin_wipe_all($pdo) : ['wiped'=>false];
    $total = 0;
    echo "<div class='notice' style='margin:10px 0'>Watchlist cleared (" . htmlspecialchars((string)($r['backend'] ?? 'unknown')) . ").</div>";
  } catch (Throwable $t) {
    echo "<div class='notice' style='margin:10px 0'>Failed to clear: " . htmlspecialchars($t->getMessage()) . "</div>";
  }
}
?>
<div style="padding:16px">
  <h2 style="margin:0 0 8px 0">Watchlist</h2>
  <div style="opacity:.9;margin-bottom:12px">Adds a ★ button to Live / Movies / Series / TMDB tiles. Users can view their list at <code>/portal/watchlist.php</code>.</div>
  <div style="margin:12px 0;padding:12px;border:1px solid rgba(255,255,255,.12);border-radius:12px;background:rgba(0,0,0,.15)">
    <div><b>Status:</b> OK</div>
    <div><b>Backend:</b> <?= htmlspecialchars((string)$backend) ?></div>
    <div><b>Items stored:</b> <?= (int)$total ?></div>
    <div><b>API:</b> <code>/plugins/watchlist/api.php</code></div>
  </div>

  <form method="post" onsubmit="return confirm('Clear ALL watchlists for ALL users?');">
    <input type="hidden" name="wipe_all" value="yes">
    <button class="btn danger" type="submit">Clear all watchlists</button>
  </form>
</div>
