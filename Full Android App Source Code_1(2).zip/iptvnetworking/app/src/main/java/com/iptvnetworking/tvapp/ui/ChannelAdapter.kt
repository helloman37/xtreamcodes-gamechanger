package com.iptvnetworking.tvapp.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.iptvnetworking.tvapp.databinding.ItemChannelBinding
import com.iptvnetworking.tvapp.model.Channel
import com.iptvnetworking.tvapp.util.DeviceOrientationHelper

class ChannelAdapter(
    private var channels: List<Channel>,
    private val onClick: (Channel) -> Unit,
    private val onFocused: ((Channel) -> Unit)? = null
) : RecyclerView.Adapter<ChannelAdapter.ChannelViewHolder>() {

    inner class ChannelViewHolder(val binding: ItemChannelBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChannelViewHolder {
        val binding = ItemChannelBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ChannelViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ChannelViewHolder, position: Int) {
        val channel = channels[position]
        holder.binding.channelName.text = channel.name

        val logoView = holder.binding.channelLogo
        if (!channel.logoUrl.isNullOrEmpty()) {
            Glide.with(logoView.context)
                .load(channel.logoUrl)
                .into(logoView)
        } else {
            logoView.setImageDrawable(null)
        }

        
        val isTv = DeviceOrientationHelper.isTv(holder.binding.root.context)

        // Always allow focus so DPAD / remote navigation and previews work reliably,
        // even on devices where isTv() might not correctly report TV mode.
        holder.binding.root.isFocusable = true
        holder.binding.root.isFocusableInTouchMode = true

        holder.binding.root.setOnClickListener {
            onClick(channel)
        }

        if (onFocused != null) {
            holder.binding.root.setOnFocusChangeListener { _, hasFocus ->
                if (hasFocus) {
                    onFocused.invoke(channel)
                }
            }
        } else {
            holder.binding.root.setOnFocusChangeListener(null)
        }
}

    override fun getItemCount(): Int = channels.size

    fun updateData(newList: List<Channel>) {
        channels = newList
        notifyDataSetChanged()
    }
}