package com.iptvnetworking.tvapp.prefs

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private const val PREF_NAME = "tvapp_prefs"
    private const val KEY_USERNAME = "username"
    private const val KEY_PASSWORD = "password"
    private const val KEY_EPG_URL = "epg_url"
    private const val KEY_FAVORITES = "favorites_urls"
    private const val KEY_MOVIE_SERVER_INDEX = "movie_server_index"
    private const val KEY_CHANNELS_CACHE_FINGERPRINT = "channels_cache_fingerprint"
    private const val KEY_DEVICE_ID = "device_id"


    private fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    fun saveCredentials(context: Context, username: String, password: String) {
        prefs(context).edit()
            .putString(KEY_USERNAME, username)
            .putString(KEY_PASSWORD, password)
            // Force Live TV to refresh channels after credentials/playlist change
            .putString(KEY_CHANNELS_CACHE_FINGERPRINT, "")
            .apply()
    }

    fun getUsername(context: Context): String? =
        prefs(context).getString(KEY_USERNAME, null)

    fun getPassword(context: Context): String? =
        prefs(context).getString(KEY_PASSWORD, null)


    /**
     * A stable per-installation device id used to keep the panel's "device count" consistent
     * across different playback engines (Exo vs VLC) and different User-Agents.
     */
    fun getOrCreateDeviceId(context: Context): String {
        val p = prefs(context)
        val existing = p.getString(KEY_DEVICE_ID, null)
        if (!existing.isNullOrBlank()) return existing

        val created = java.util.UUID.randomUUID().toString()
        p.edit().putString(KEY_DEVICE_ID, created).apply()
        return created
    }



    fun saveEpgUrl(context: Context, url: String?) {
        prefs(context).edit()
            .putString(KEY_EPG_URL, url ?: "")
            .apply()
    }

    fun getEpgUrl(context: Context): String? =
        prefs(context).getString(KEY_EPG_URL, "")

    fun getFavoriteUrls(context: Context): Set<String> =
        prefs(context).getStringSet(KEY_FAVORITES, emptySet()) ?: emptySet()

    fun isFavorite(context: Context, url: String): Boolean =
        getFavoriteUrls(context).contains(url)

    fun toggleFavorite(context: Context, url: String) {
        val current = getFavoriteUrls(context).toMutableSet()
        if (current.contains(url)) {
            current.remove(url)
        } else {
            current.add(url)
        }
        prefs(context).edit()
            .putStringSet(KEY_FAVORITES, current)
            .apply()
    }

    
    fun setMovieServerIndex(context: Context, index: Int) {
        // v39: only 5 server slots for Movies/TV
        val safe = index.coerceIn(1, 5)
        prefs(context).edit()
            .putInt(KEY_MOVIE_SERVER_INDEX, safe)
            .apply()
    }

    
    fun getChannelsCacheFingerprint(context: Context): String? =
        prefs(context).getString(KEY_CHANNELS_CACHE_FINGERPRINT, "")

    fun setChannelsCacheFingerprint(context: Context, fingerprint: String) {
        prefs(context).edit()
            .putString(KEY_CHANNELS_CACHE_FINGERPRINT, fingerprint)
            .apply()
    }

fun getMovieServerIndex(context: Context): Int {
        // Clamp legacy saved values (older builds allowed up to 8)
        return prefs(context).getInt(KEY_MOVIE_SERVER_INDEX, 1).coerceIn(1, 5)
    }

    fun clear(context: Context) {
        prefs(context).edit()
            .remove(KEY_USERNAME)
            .remove(KEY_PASSWORD)
            .remove(KEY_CHANNELS_CACHE_FINGERPRINT)
            .apply()
    }
}