package com.iptvnetworking.tvapp.model

import java.time.Duration
import java.time.Instant

/**
 * Simple in-memory cache for EPG data. This survives navigation between screens
 * while the app process is alive, but is cleared on app restart or when explicitly reset.
 */
object EpgCache {

    var channels: List<Channel>? = null
        private set

    var epgByChannelName: Map<String, List<EpgProgram>>? = null
        private set

    private var lastUpdated: Instant? = null

    // How long we consider the EPG "fresh" in minutes.
    private const val TTL_MINUTES: Long = 15

    fun isValid(): Boolean {
        val ts = lastUpdated ?: return false
        val ch = channels
        val epg = epgByChannelName

        if (ch.isNullOrEmpty() || epg.isNullOrEmpty()) return false

        val ageMinutes = Duration.between(ts, Instant.now()).toMinutes()
        return ageMinutes in 0..TTL_MINUTES
    }

    fun save(channels: List<Channel>, epg: Map<String, List<EpgProgram>>) {
        this.channels = channels
        this.epgByChannelName = epg
        this.lastUpdated = Instant.now()
    }

    fun clear() {
        channels = null
        epgByChannelName = null
        lastUpdated = null
    }
}
