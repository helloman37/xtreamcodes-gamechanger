package com.iptvnetworking.tvapp.util

import com.iptvnetworking.tvapp.model.Channel
import com.iptvnetworking.tvapp.model.EpgChannelInfo
import com.iptvnetworking.tvapp.model.EpgProgram
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.StringReader
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

object XmlTvParser {

    data class XmlTvData(
        val channels: List<EpgChannelInfo>,
        val programmes: List<EpgProgram>
    )

    // xmltv example: 20251208133000 +0000
    private val dateFormatter: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss")

    fun parse(xml: String): XmlTvData {
        val factory = XmlPullParserFactory.newInstance()
        factory.isNamespaceAware = false
        val parser = factory.newPullParser()
        parser.setInput(StringReader(xml))

        val channelsById = mutableMapOf<String, MutableList<String>>() // id -> display-names
        val programmes = mutableListOf<EpgProgram>()

        var eventType = parser.eventType
        var currentTag: String? = null

        var currentChannelId: String? = null
        val currentDisplayName = StringBuilder()

        var programmeChannelId: String? = null
        var programmeStart: String? = null
        var programmeStop: String? = null
        val programmeTitle = StringBuilder()
        val programmeDesc = StringBuilder()

        while (eventType != XmlPullParser.END_DOCUMENT) {
            when (eventType) {
                XmlPullParser.START_TAG -> {
                    currentTag = parser.name
                    when (currentTag) {
                        "channel" -> {
                            currentChannelId = parser.getAttributeValue(null, "id")
                            currentDisplayName.setLength(0)
                        }
                        "display-name" -> currentDisplayName.setLength(0)
                        "programme" -> {
                            programmeChannelId = parser.getAttributeValue(null, "channel")
                            programmeStart = parser.getAttributeValue(null, "start")
                            programmeStop = parser.getAttributeValue(null, "stop")
                            programmeTitle.setLength(0)
                            programmeDesc.setLength(0)
                        }
                        "title" -> programmeTitle.setLength(0)
                        "desc" -> programmeDesc.setLength(0)
                    }
                }
                XmlPullParser.TEXT -> {
                    val text = parser.text ?: ""
                    when (currentTag) {
                        "display-name" -> currentDisplayName.append(text)
                        "title" -> programmeTitle.append(text)
                        "desc" -> programmeDesc.append(text)
                    }
                }
                XmlPullParser.END_TAG -> {
                    val endTag = parser.name
                    when (endTag) {
                        "display-name" -> {
                            val id = currentChannelId
                            if (!id.isNullOrBlank()) {
                                val name = currentDisplayName.toString().trim()
                                if (name.isNotEmpty()) {
                                    val list = channelsById.getOrPut(id) { mutableListOf() }
                                    list += name
                                }
                            }
                        }
                        "channel" -> {
                            currentChannelId = null
                            currentDisplayName.setLength(0)
                        }
                        "programme" -> {
                            val chId = programmeChannelId
                            val start = parseXmltvDate(programmeStart)
                            val end = parseXmltvDate(programmeStop)
                            val title = programmeTitle.toString().ifBlank { "Unknown" }
                            val desc = programmeDesc.toString().takeIf { it.isNotBlank() }

                            if (!chId.isNullOrBlank() && start != null) {
                                programmes += EpgProgram(
                                    channelId = chId,
                                    title = title,
                                    start = start,
                                    end = end,
                                    description = desc
                                )
                            }

                            programmeChannelId = null
                            programmeStart = null
                            programmeStop = null
                            programmeTitle.setLength(0)
                            programmeDesc.setLength(0)
                        }
                    }
                    currentTag = null
                }
            }

            eventType = parser.next()
        }

        val channelInfos = channelsById.map { (id, names) ->
            EpgChannelInfo(id = id, displayNames = names.distinct())
        }

        return XmlTvData(
            channels = channelInfos,
            programmes = programmes
        )
    }

    private fun parseXmltvDate(raw: String?): ZonedDateTime? {
        if (raw.isNullOrBlank()) return null
        val trimmed = raw.trim()
        val base = if (trimmed.length >= 14) trimmed.substring(0, 14) else trimmed
        return try {
            val local = LocalDateTime.parse(base, dateFormatter)
            local.atZone(ZoneId.systemDefault())
        } catch (_: Exception) {
            null
        }
    }

    fun buildEpgByChannelName(
        channels: List<Channel>,
        xmlTvData: XmlTvData
    ): Map<String, List<EpgProgram>> {

        fun normalize(text: String?): String =
            text?.lowercase()
                ?.replace("[^a-z0-9]".toRegex(), "")
                ?.trim()
                ?: ""

        // index xmltv channels by normalized id + display-names
        val channelIdByNormalizedName = mutableMapOf<String, String>()
        for (info in xmlTvData.channels) {
            val idNorm = normalize(info.id)
            if (idNorm.isNotEmpty()) {
                channelIdByNormalizedName.putIfAbsent(idNorm, info.id)
            }
            for (name in info.displayNames) {
                val n = normalize(name)
                if (n.isNotEmpty()) {
                    channelIdByNormalizedName.putIfAbsent(n, info.id)
                }
            }
        }

        val programmesById = xmlTvData.programmes.groupBy { it.channelId }
        val result = mutableMapOf<String, List<EpgProgram>>()

        // map each M3U channel (by name) to xmltv channel
        for (channel in channels) {
            val norm = normalize(channel.name)
            val epgId = channelIdByNormalizedName[norm]
            val programmes = if (epgId != null) {
                programmesById[epgId].orEmpty().sortedBy { it.start }
            } else {
                emptyList()
            }
            if (programmes.isNotEmpty()) {
                result[channel.name] = programmes
            }
        }

        return result
    }
}
