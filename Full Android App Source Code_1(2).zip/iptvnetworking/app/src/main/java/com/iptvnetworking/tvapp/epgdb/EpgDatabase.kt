package com.iptvnetworking.tvapp.epgdb

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        EpgProgramEntity::class,
        EpgMetaEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class EpgDatabase : RoomDatabase() {

    abstract fun epgDao(): EpgDao

    companion object {
        @Volatile
        private var INSTANCE: EpgDatabase? = null

        fun getInstance(context: Context): EpgDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    EpgDatabase::class.java,
                    "epg.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
