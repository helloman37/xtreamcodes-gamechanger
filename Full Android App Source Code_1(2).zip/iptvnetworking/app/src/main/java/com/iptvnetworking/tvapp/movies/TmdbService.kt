package com.iptvnetworking.tvapp.movies

import retrofit2.http.GET
import retrofit2.http.Query
import retrofit2.http.Path

data class TmdbMovieResponse(
    val results: List<TmdbMovie> = emptyList()
)

data class TmdbMovie(
    val id: Int,
    val title: String?,
    val overview: String?,
    val poster_path: String?,
    val release_date: String?,
    val original_language: String? = null
)

data class TmdbTvResponse(
    val results: List<TmdbTvShow> = emptyList()
)

data class TmdbTvShow(
    val id: Int,
    val name: String?,
    val overview: String?,
    val poster_path: String?,
    val first_air_date: String?,
    val original_language: String? = null
)

data class TmdbTvSeason(
    val season_number: Int?,
    val episode_count: Int?,
    val name: String?
)

data class TmdbTvDetails(
    val id: Int?,
    val name: String?,
    val overview: String?,
    val seasons: List<TmdbTvSeason>?
)

data class TmdbTvEpisode(
    val id: Int?,
    val episode_number: Int?,
    val name: String?
)

data class TmdbSeasonDetails(
    val id: Int?,
    val name: String?,
    val episodes: List<TmdbTvEpisode>?
)

interface TmdbService {

    @GET("discover/movie")
    suspend fun discoverMovies(
        @Query("api_key") apiKey: String,
        @Query("sort_by") sortBy: String = "primary_release_date.desc",
        @Query("with_genres") withGenres: String? = null,
        @Query("primary_release_year") year: Int? = null,
        @Query("region") region: String? = null,
        @Query("with_origin_country") originCountry: String? = null,
        @Query("include_adult") includeAdult: Boolean = false,
        @Query("with_original_language") originalLanguage: String? = "en",
        @Query("page") page: Int = 1
    ): TmdbMovieResponse

    @GET("search/movie")
    suspend fun searchMovies(
        @Query("api_key") apiKey: String,
        @Query("query") query: String,
        @Query("year") year: Int? = null,
        @Query("region") region: String? = null,
        @Query("with_origin_country") originCountry: String? = null,
        @Query("include_adult") includeAdult: Boolean = false,
        @Query("with_original_language") originalLanguage: String? = "en",
        @Query("page") page: Int = 1
    ): TmdbMovieResponse


    // Trending movies
    @GET("trending/movie/{time_window}")
    suspend fun trendingMovies(
        @Path("time_window") timeWindow: String = "day",
        @Query("api_key") apiKey: String,
        @Query("page") page: Int = 1
    ): TmdbMovieResponse


    // Movie recommendations for a given movie
    @GET("movie/{movie_id}/recommendations")
    suspend fun getMovieRecommendations(
        @Path("movie_id") movieId: Int,
        @Query("api_key") apiKey: String,
        @Query("page") page: Int = 1
    ): TmdbMovieResponse

    // TV recommendations for a given series
    @GET("tv/{tv_id}/recommendations")
    suspend fun getTvRecommendations(
        @Path("tv_id") tvId: Int,
        @Query("api_key") apiKey: String,
        @Query("page") page: Int = 1
    ): TmdbTvResponse

    // TV endpoints
    @GET("discover/tv")
    suspend fun discoverTv(
        @Query("api_key") apiKey: String,
        @Query("sort_by") sortBy: String = "popularity.desc",
        @Query("include_adult") includeAdult: Boolean = false,
        @Query("with_original_language") originalLanguage: String? = "en",
        @Query("page") page: Int = 1
    ): TmdbTvResponse

    @GET("search/tv")
    suspend fun searchTv(
        @Query("api_key") apiKey: String,
        @Query("query") query: String,
        @Query("include_adult") includeAdult: Boolean = false,
        @Query("with_original_language") originalLanguage: String? = "en",
        @Query("page") page: Int = 1
    ): TmdbTvResponse

    // single TV details (seasons)
    @GET("tv/{tv_id}")
    suspend fun getTvDetails(
        @Path("tv_id") tvId: Int,
        @Query("api_key") apiKey: String
    ): TmdbTvDetails

    // specific season details (episodes)
    @GET("tv/{tv_id}/season/{season_number}")
    suspend fun getSeasonDetails(
        @Path("tv_id") tvId: Int,
        @Path("season_number") seasonNumber: Int,
        @Query("api_key") apiKey: String
    ): TmdbSeasonDetails
}
