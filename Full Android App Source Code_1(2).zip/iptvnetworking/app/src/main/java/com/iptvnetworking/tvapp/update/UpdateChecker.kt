package com.iptvnetworking.tvapp.update

import com.google.gson.JsonParser
import com.iptvnetworking.tvapp.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

/**
 * Simple updater helper that checks a JSON file on your server for a newer APK.
 *
 * Put your update.json URL in UPDATE_URL below.
 *
 * Backward-compatible schema (optional update):
 * {
 *   "versionCode": 22,
 *   "apkUrl": "https://yourdomain.com/iptv/iptvnetworking_v22.apk",
 *   "changelog": "Bug fixes and improvements"
 * }
 *
 * Recommended schema (supports forced updates):
 * {
 *   "latestVersionCode": 22,
 *   "minVersionCode": 22,
 *   "apkUrl": "https://yourdomain.com/iptv/iptvnetworking_v22.apk",
 *   "changelog": "Security update",
 *   "force": true
 * }
 *
 * Rules:
 * - The app will show an update prompt if latestVersionCode/versionCode > current.
 * - The update is treated as forced if:
 *     - force == true OR
 *     - minVersionCode > current.
 */
object UpdateChecker {

    // CHANGE THIS to your real update.json URL
    const val UPDATE_URL: String = "https://iptvnetworking.com/update.json"

    private val client = OkHttpClient()

    data class UpdateInfo(
        val latestVersionCode: Int,
        val minVersionCode: Int,
        val apkUrl: String,
        val changelog: String?,
        val isForce: Boolean
    )

    /**
     * Returns UpdateInfo if an update is available or required.
     */
    suspend fun checkForUpdate(): UpdateInfo? {
        return withContext(Dispatchers.IO) {
            try {
                val request = Request.Builder()
                    .url(UPDATE_URL)
                    .build()

                client.newCall(request).execute().use { response ->
                    val body = response.body?.string() ?: return@withContext null
                    val json = JsonParser.parseString(body).asJsonObject

                    val currentCode = BuildConfig.VERSION_CODE

                    val remoteLatest = when {
                        json.has("latestVersionCode") -> json.get("latestVersionCode").asInt
                        json.has("versionCode") -> json.get("versionCode").asInt
                        else -> return@withContext null
                    }

                    val remoteMin = when {
                        json.has("minVersionCode") -> json.get("minVersionCode").asInt
                        else -> 0
                    }

                    val forceFlag =
                        if (json.has("force") && !json.get("force").isJsonNull)
                            json.get("force").asBoolean
                        else
                            false

                    val apkUrl =
                        if (json.has("apkUrl") && !json.get("apkUrl").isJsonNull)
                            json.get("apkUrl").asString
                        else
                            ""

                    if (apkUrl.isBlank()) return@withContext null

                    val isForce = forceFlag || (remoteMin > 0 && currentCode < remoteMin)
                    val isUpdateAvailable = remoteLatest > currentCode

                    return@withContext if (isUpdateAvailable || isForce) {
                        UpdateInfo(
                            latestVersionCode = remoteLatest,
                            minVersionCode = remoteMin,
                            apkUrl = apkUrl,
                            changelog =
                                if (json.has("changelog") && !json.get("changelog").isJsonNull)
                                    json.get("changelog").asString
                                else
                                    null,
                            isForce = isForce
                        )
                    } else {
                        null
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                null
            }
        }
    }
}
