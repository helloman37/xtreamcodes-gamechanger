package com.iptvnetworking.tvapp.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.iptvnetworking.tvapp.databinding.ItemCategoryBinding
import com.iptvnetworking.tvapp.util.DeviceOrientationHelper

class CategoryAdapter(
    private val categories: List<String>,
    private val onClick: (String) -> Unit
) : RecyclerView.Adapter<CategoryAdapter.CategoryViewHolder>() {

    private var selected = 0

    inner class CategoryViewHolder(val binding: ItemCategoryBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CategoryViewHolder {
        val binding = ItemCategoryBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return CategoryViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CategoryViewHolder, position: Int) {
        val name = categories[position]
        holder.binding.categoryName.text = name

        val isSelected = position == selected
        holder.binding.categoryName.setTextColor(
            if (isSelected) 0xFFFFFFFF.toInt() else 0xFFCCCCCC.toInt()
        )

        val isTv = DeviceOrientationHelper.isTv(holder.binding.root.context)
        holder.binding.root.isFocusable = isTv
        holder.binding.root.isFocusableInTouchMode = isTv

        holder.binding.root.setOnClickListener {
            val old = selected
            selected = position
            notifyItemChanged(old)
            notifyItemChanged(selected)
            onClick(name)
        }
    }

    override fun getItemCount(): Int = categories.size
}
