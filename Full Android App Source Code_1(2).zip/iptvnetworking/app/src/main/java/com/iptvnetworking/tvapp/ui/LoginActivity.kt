package com.iptvnetworking.tvapp.ui

import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.iptvnetworking.tvapp.util.DeviceOrientationHelper
import com.iptvnetworking.tvapp.databinding.ActivityLoginBinding
import com.iptvnetworking.tvapp.network.ApiClient
import com.iptvnetworking.tvapp.prefs.Prefs
import com.google.gson.JsonParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        DeviceOrientationHelper.applyPhoneLoginPortrait(this)

        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Default focus on username field
        binding.usernameInput.requestFocus()
        binding.usernameInput.post {
            binding.usernameInput.requestFocus()
        }

        // IME: Enter/Done on username moves to password
        binding.usernameInput.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_NEXT ||
                actionId == EditorInfo.IME_ACTION_DONE ||
                (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
            ) {
                binding.passwordInput.requestFocus()
                true
            } else {
                false
            }
        }

        // IME: Enter/Done on password triggers login
        binding.passwordInput.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE ||
                actionId == EditorInfo.IME_ACTION_GO ||
                (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
            ) {
                binding.loginButton.performClick()
                true
            } else {
                false
            }
        }

        // Manual login button
        binding.loginButton.setOnClickListener {
            val username = binding.usernameInput.text.toString().trim()
            val password = binding.passwordInput.text.toString().trim()

            if (username.isEmpty() || password.isEmpty()) {
                binding.statusText.text = "Please enter username and password."
                return@setOnClickListener
            }

            // Basic debounce to avoid spamming the endpoint
            binding.loginButton.isEnabled = false
            binding.statusText.text = "Checking account..."

            lifecycleScope.launch {
                val maxAttempts = 3
                var attempt = 1
                var ok = false

                while (attempt <= maxAttempts && !ok) {
                    ok = checkCredentials(username, password)
                    if (!ok && attempt < maxAttempts) {
                        // Small delay between retries so slower panels (or emulators like BlueStacks)
                        // get a chance to respond without the user mashing the login button.
                        binding.statusText.text = "Retrying... ($attempt/$maxAttempts)"
                        delay(800)
                    }
                    attempt++
                }

                binding.loginButton.isEnabled = true

                if (ok) {
                    Prefs.saveCredentials(this@LoginActivity, username, password)
                    binding.statusText.text = "Login successful."
                    goToChannelList()
                } else {
                    binding.statusText.text = "Login failed. Please verify your details."
                }
            }
        }

        // Auto-login: if we have saved credentials, verify that the account
        // is still active/valid. If the panel reports an expired or inactive
        // account, clear the saved credentials so the app behaves as logged out.
        val savedUser = Prefs.getUsername(this)
        val savedPass = Prefs.getPassword(this)

        if (!savedUser.isNullOrEmpty() && !savedPass.isNullOrEmpty()) {
            lifecycleScope.launch {
                binding.statusText.text = "Checking your account..."
                val (ok, shouldClear) = checkCredentialsWithReason(savedUser, savedPass)
                if (ok) {
                    binding.statusText.text = "Welcome back. Logging you in..."
                    goToChannelList()
                } else {
                    if (shouldClear) {
                        Prefs.clear(this@LoginActivity)
                    }
                    binding.statusText.text = "Your account could not be verified. Please log in again."
                }
            }
            return
        }

    }


    private suspend fun checkCredentialsWithReason(
        username: String,
        password: String
    ): Pair<Boolean, Boolean> {
        return try {
            val responseText = withContext(Dispatchers.IO) {
                val deviceId = Prefs.getOrCreateDeviceId(this@LoginActivity)
                val body = ApiClient.api.getAccountInfo(username, password, deviceId)
                body.string()
            }

            val root = JsonParser.parseString(responseText).asJsonObject
            val userInfo = root.getAsJsonObject("user_info") ?: return false to false

            val auth = userInfo.get("auth")?.asString
val status = userInfo.get("status")?.asString

val statusNormalized = status?.trim()?.lowercase()
val isInactive = statusNormalized == "inactive" ||
        statusNormalized == "banned" ||
        statusNormalized == "disabled"
val isExpired = statusNormalized == "expired"

val isValid = auth == "1" && !isInactive && !isExpired
val shouldClear = isExpired || isInactive

            isValid to shouldClear
        } catch (e: Exception) {
            e.printStackTrace()
            false to false
        }
    }

    private suspend fun checkCredentials(username: String, password: String): Boolean {
        val (isValid, _) = checkCredentialsWithReason(username, password)
        return isValid
    }


    private fun goToChannelList() {
        val intent = Intent(this, HomeActivity::class.java)
        startActivity(intent)
        finish()
    }
}