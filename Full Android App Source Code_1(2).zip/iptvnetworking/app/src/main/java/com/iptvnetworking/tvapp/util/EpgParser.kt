package com.iptvnetworking.tvapp.util

import com.iptvnetworking.tvapp.model.EpgProgram

/**
 * Legacy stub for backwards compatibility with older builds that referenced EpgParser.
 *
 * The new implementation uses XmlTvParser instead. This stub keeps the project compiling
 * even if some old code still imports EpgParser, but it always returns an empty EPG map.
 */
object EpgParser {

    /**
     * Parse an EPG XML string and return programmes grouped by channel name/key.
     * This stub implementation just returns an empty map.
     */
    fun parse(xml: String): Map<String, List<EpgProgram>> = emptyMap()
}
