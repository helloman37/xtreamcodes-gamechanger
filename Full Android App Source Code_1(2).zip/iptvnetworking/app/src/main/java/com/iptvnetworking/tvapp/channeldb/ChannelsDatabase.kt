package com.iptvnetworking.tvapp.channeldb

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        ChannelEntity::class,
        ChannelsMetaEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class ChannelsDatabase : RoomDatabase() {

    abstract fun channelsDao(): ChannelsDao

    companion object {
        @Volatile
        private var INSTANCE: ChannelsDatabase? = null

        fun getInstance(context: Context): ChannelsDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    ChannelsDatabase::class.java,
                    "channels.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
