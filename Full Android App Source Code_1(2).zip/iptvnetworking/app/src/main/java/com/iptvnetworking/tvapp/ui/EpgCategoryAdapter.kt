package com.iptvnetworking.tvapp.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.iptvnetworking.tvapp.databinding.ItemEpgCategoryChipBinding
import com.iptvnetworking.tvapp.util.DeviceOrientationHelper

class EpgCategoryAdapter(
    private var categories: List<String>,
    private val onClick: (String) -> Unit
) : RecyclerView.Adapter<EpgCategoryAdapter.EpgCategoryViewHolder>() {

    private var selected = 0

    inner class EpgCategoryViewHolder(val binding: ItemEpgCategoryChipBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EpgCategoryViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = ItemEpgCategoryChipBinding.inflate(inflater, parent, false)
        return EpgCategoryViewHolder(binding)
    }

    override fun onBindViewHolder(holder: EpgCategoryViewHolder, position: Int) {
        val name = categories[position]
        val context = holder.binding.root.context
        val isTv = DeviceOrientationHelper.isTv(context)

        holder.binding.categoryName.text = name

        val isSelected = position == selected
        holder.binding.categoryName.alpha = if (isSelected) 1f else 0.7f

        holder.binding.root.isFocusable = isTv
        holder.binding.root.isFocusableInTouchMode = isTv

        holder.binding.root.setOnClickListener {
            val old = selected
            selected = position
            notifyItemChanged(old)
            notifyItemChanged(selected)
            onClick(name)
        }
    }

    override fun getItemCount(): Int = categories.size

    fun updateCategories(newCategories: List<String>) {
        categories = newCategories
        selected = 0
        notifyDataSetChanged()
    }
}
