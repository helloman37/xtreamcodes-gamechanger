package com.iptvnetworking.tvapp.movies

import android.content.Context
import com.iptvnetworking.tvapp.prefs.Prefs

/**
 * Central place for movie / TV configuration.
 *
 * Update these values with your own TMDB API key and streaming server URLs.
 */
object MovieConfig {

    /**
     * Your TMDB API key.
     *
     * The various TMDB helper screens (home hero, Movies, TV Shows, TV detail)
     * all read from this value. Set it once here.
     */
    const val TMDB_API_KEY: String = "59a35acc07b72f0e91aa657cdb259beb"

    /**
     * Default region for TMDB discover/search requests.
     * Keep this as "US" or change to your main audience region code.
     */
    const val DEFAULT_REGION: String = "US"

    /**
     * Base URL for movie playback.
     *
     * Example:
     *   "https://player.videasy.net/movie/{id}"
     *
     * buildMovieUrl(movieId) will output:
     *   that URL with {id} replaced with the TMDB movie id.
     */
    const val MOVIE_EMBED_BASE: String = "https://vidlink.pro/movie/{id}"

    /**
     * Base URL for TV playback.
     *
     * Example:
     *   "https://player.videasy.net/tv/{id}/{season}/{episode}/"
     *
     * buildTvUrl(id, season, episode) will output:
     *   that URL with {id}, {season}, {episode} replaced.
     */
    const val TV_EMBED_BASE: String = "https://vidlink.pro/tv/{id}/{season}/{episode}/"

    /**
     * Optional multi-server presets for Movies and TV.
     *
     * These are used by the server dropdown on Movies / TV Shows pages.
     * Edit these to your preferred providers.
     */
    val MOVIE_EMBED_BASES: List<String> = listOf(
        MOVIE_EMBED_BASE,
        "https://player.videasy.net/movie/{id}",
        "https://vidfast.pro/movie/{id}",
        "https://vidsrc.cc/v2/embed/movie/{id}",
        "https://www.vidking.net/embed/movie/{tmdbId}"
    )

    val TV_EMBED_BASES: List<String> = listOf(
        TV_EMBED_BASE,
        "https://player.videasy.net/tv/{id}/{season}/{episode}/",
        "https://vidfast.pro/tv/{id}/{season}/{episode}/",
        "https://vidsrc.cc/v2/embed/tv/{id}/{season}/{episode}/",
        "https://www.vidking.net/embed/tv/{tmdbId}/{season}/{episode}/"
    )

    /**
     * Apply brace-style and dollar-style placeholders to a server template.
     *
     * Supported ID tokens:
     *   {id}, {tmdbId}, {tmdb_id}
     *   ${mi}, ${mt}, ${si}
     *
     * Supported TV tokens:
     *   {season}, {season_number}, {episode}, {episode_number}
     *   ${season}, ${episode}
     */
    private fun applyTokens(
        baseRaw: String,
        tmdbId: Int,
        season: Int? = null,
        episode: Int? = null
    ): String {
        var base = baseRaw.trim()
        if (base.isBlank()) return ""

        // ID aliases
        base = base
            .replace("{id}", tmdbId.toString())
            .replace("{tmdbId}", tmdbId.toString())
            .replace("{tmdb_id}", tmdbId.toString())
            .replace("\${mi}", tmdbId.toString())
            .replace("\${mt}", tmdbId.toString())
            .replace("\${si}", tmdbId.toString())

        // Season aliases
        if (season != null) {
            base = base
                .replace("{season}", season.toString())
                .replace("{season_number}", season.toString())
                .replace("\${season}", season.toString())
        }

        // Episode aliases
        if (episode != null) {
            base = base
                .replace("{episode}", episode.toString())
                .replace("{episode_number}", episode.toString())
                .replace("\${episode}", episode.toString())
        }

        return base.trim()
    }

    /**
     * Build the full Movie URL from TMDB movie ID.
     *
     * Uses the currently selected server index from Prefs.
     */
    fun buildMovieUrl(context: Context, tmdbId: Int): String {
        val index = (Prefs.getMovieServerIndex(context) - 1)
            .coerceIn(0, MOVIE_EMBED_BASES.lastIndex)
        val base = MOVIE_EMBED_BASES[index]
        return applyTokens(base, tmdbId)
    }

    /**
     * Build the full Movie URL from TMDB movie ID using the default base.
     */
    fun buildMovieUrl(tmdbId: Int): String {
        return applyTokens(MOVIE_EMBED_BASE, tmdbId)
    }

    /**
     * Build the full TV URL from TMDB ID, season, and episode numbers.
     *
     * Uses the currently selected server index from Prefs.
     */
    fun buildTvUrl(context: Context, tmdbId: Int, season: Int, episode: Int): String {
        val index = (Prefs.getMovieServerIndex(context) - 1)
            .coerceIn(0, TV_EMBED_BASES.lastIndex)
        val base = TV_EMBED_BASES[index]
        return applyTokens(base, tmdbId, season, episode)
    }

    /**
     * Build the full TV URL using the default base.
     *
     * Example result:
     *   https://player.videasy.net/tv/123/1/2/
     */
    fun buildTvUrl(tmdbId: Int, season: Int, episode: Int): String {
        return applyTokens(TV_EMBED_BASE, tmdbId, season, episode)
    }
}
