package com.iptvnetworking.tvapp.util

import com.iptvnetworking.tvapp.model.Channel

object M3UParser {

    private fun getAttr(line: String, key: String): String? {
        val pattern = key + "=\""
        val idx = line.indexOf(pattern, ignoreCase = true)
        if (idx == -1) return null
        val start = idx + pattern.length
        val end = line.indexOf('"', start)
        if (end == -1) return null
        return line.substring(start, end).trim()
    }

    fun parse(m3u: String): List<Channel> {
        val channels = mutableListOf<Channel>()
        var currentName: String? = null
        var currentLogo: String? = null
        var currentGroup: String? = null
        var index = 1

        m3u.lineSequence().forEach { raw ->
            val line = raw.trim()
            if (line.isEmpty()) return@forEach

            if (line.startsWith("#EXTINF", ignoreCase = true)) {
                val namePart = line.substringAfter(",", missingDelimiterValue = "").trim()
                val name = if (namePart.isNotEmpty()) namePart else "Channel $index"
                currentName = name

                currentLogo = getAttr(line, "tvg-logo")
                currentGroup = getAttr(line, "group-title")
            } else if (!line.startsWith("#") && currentName != null) {
                channels.add(
                    Channel(
                        name = currentName!!,
                        url = line,
                        logoUrl = currentLogo,
                        group = currentGroup
                    )
                )
                index++
                currentName = null
                currentLogo = null
                currentGroup = null
            }
        }

        return channels
    }
}
