package com.iptvnetworking.tvapp.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.iptvnetworking.tvapp.util.DeviceOrientationHelper
import com.bumptech.glide.Glide
import com.iptvnetworking.tvapp.databinding.ItemMovieBinding
import com.iptvnetworking.tvapp.movies.TmdbMovie

class MovieAdapter(
    private var items: List<TmdbMovie>,
    private val onClick: (TmdbMovie) -> Unit
) : RecyclerView.Adapter<MovieAdapter.MovieViewHolder>() {

    inner class MovieViewHolder(val binding: ItemMovieBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MovieViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = ItemMovieBinding.inflate(inflater, parent, false)
        return MovieViewHolder(binding)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: MovieViewHolder, position: Int) {
        val movie = items[position]
        val ctx = holder.binding.root.context

        holder.binding.movieTitle.text = movie.title ?: ""
        holder.binding.movieYear.text = movie.release_date?.take(4) ?: ""

        val posterPath = movie.poster_path
        if (!posterPath.isNullOrEmpty()) {
            val sizePath = if (DeviceOrientationHelper.isTv(ctx)) "w342" else "w185"
            val url = "https://image.tmdb.org/t/p/$sizePath$posterPath"
            Glide.with(ctx)
                .load(url)
                .centerCrop()
                .into(holder.binding.moviePoster)
        } else {
            holder.binding.moviePoster.setImageDrawable(null)
        }

        
        val isTv = DeviceOrientationHelper.isTv(ctx)
        holder.binding.root.isFocusable = isTv
        holder.binding.root.isFocusableInTouchMode = isTv

        holder.binding.root.setOnClickListener {
            onClick(movie)
        }
}

    fun submitList(newItems: List<TmdbMovie>) {
        items = newItems
        notifyDataSetChanged()
    }
}
