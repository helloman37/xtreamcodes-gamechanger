package com.iptvnetworking.tvapp.epgdb

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Simple single-row metadata table for EPG refresh state.
 */
@Entity(tableName = "epg_meta")
data class EpgMetaEntity(
    @PrimaryKey
    val key: String = "epg",

    val lastUpdatedMillis: Long
)
