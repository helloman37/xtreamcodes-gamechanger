package com.iptvnetworking.tvapp.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.iptvnetworking.tvapp.util.DeviceOrientationHelper
import com.bumptech.glide.Glide
import com.iptvnetworking.tvapp.databinding.ItemTvShowBinding
import com.iptvnetworking.tvapp.movies.TmdbTvShow

class TvShowAdapter(
    private var items: List<TmdbTvShow>,
    private val onClick: (TmdbTvShow) -> Unit
) : RecyclerView.Adapter<TvShowAdapter.TvShowViewHolder>() {

    inner class TvShowViewHolder(val binding: ItemTvShowBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TvShowViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = ItemTvShowBinding.inflate(inflater, parent, false)
        return TvShowViewHolder(binding)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: TvShowViewHolder, position: Int) {
        val tv = items[position]
        holder.binding.tvTitle.text = tv.name ?: "Untitled"
        holder.binding.tvYear.text = tv.first_air_date?.take(4) ?: ""

        val posterPath = tv.poster_path
        if (!posterPath.isNullOrBlank()) {
            val ctx = holder.binding.tvPoster.context
            val sizePath = if (DeviceOrientationHelper.isTv(ctx)) "w342" else "w185"
            val url = "https://image.tmdb.org/t/p/$sizePath$posterPath"
            Glide.with(ctx)
                .load(url)
                .into(holder.binding.tvPoster)
        } else {
            holder.binding.tvPoster.setImageDrawable(null)
        }

        
        val isTv = DeviceOrientationHelper.isTv(holder.binding.root.context)
        holder.binding.root.isFocusable = isTv
        holder.binding.root.isFocusableInTouchMode = isTv

        holder.binding.root.setOnClickListener {
            onClick(tv)
        }
}

    fun submitList(newItems: List<TmdbTvShow>) {
        items = newItems
        notifyDataSetChanged()
    }
}
