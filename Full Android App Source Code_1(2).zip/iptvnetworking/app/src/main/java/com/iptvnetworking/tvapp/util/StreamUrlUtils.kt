package com.iptvnetworking.tvapp.util

import android.net.Uri

/**
 * Helpers for mutating stream URLs safely.
 *
 * NOTE: Many IPTV M3U playlists sometimes append a "|" header suffix (e.g. "...m3u8|User-Agent=...&Referer=...").
 * For query parameters like device_id, we must mutate ONLY the URL part (before the '|')
 * and then re-attach the suffix unchanged.
 */
object StreamUrlUtils {

    data class UrlParts(
        val url: String,
        val headers: Map<String, String> = emptyMap()
    )

    fun withDeviceId(rawUrl: String, deviceId: String): String {
        if (rawUrl.isBlank() || deviceId.isBlank()) return rawUrl
        return withQueryParam(rawUrl, "device_id", deviceId)
    }

    fun withQueryParam(rawUrl: String, key: String, value: String): String {
        if (rawUrl.isBlank() || key.isBlank() || value.isBlank()) return rawUrl

        val (urlPart, suffix) = splitPipeSuffix(rawUrl)

        return try {
            val uri = Uri.parse(urlPart)
            // Avoid duplicating the param
            if (uri.getQueryParameter(key) != null) return rawUrl

            val rebuilt = uri.buildUpon()
                .appendQueryParameter(key, value)
                .build()
                .toString()

            rebuilt + (suffix ?: "")
        } catch (_: Throwable) {
            // Fallback: naive concat
            val joiner = if (urlPart.contains("?")) "&" else "?"
            val rebuilt = urlPart + joiner + key + "=" + Uri.encode(value)
            rebuilt + (suffix ?: "")
        }
    }

    private fun splitPipeSuffix(rawUrl: String): Pair<String, String?> {
        val idx = rawUrl.indexOf('|')
        return if (idx >= 0) {
            val urlPart = rawUrl.substring(0, idx)
            val suffix = rawUrl.substring(idx) // includes '|'
            urlPart to suffix
        } else {
            rawUrl to null
        }
    }

    /**
     * Parses "...|Header1=Value&Header2=Value" style URLs commonly found in M3U playlists.
     * Returns the real URL (no pipe suffix) and a header map.
     */
    fun splitUrlAndHeaders(rawUrl: String): UrlParts {
        val (urlPart, suffix) = splitPipeSuffix(rawUrl)
        if (suffix.isNullOrBlank() || suffix.length <= 1) return UrlParts(url = urlPart)

        // Drop the leading '|'
        val rawHeaderString = suffix.substring(1)
        val map = LinkedHashMap<String, String>()

        rawHeaderString.split('&').forEach { piece ->
            val trimmed = piece.trim()
            if (trimmed.isEmpty()) return@forEach
            val eq = trimmed.indexOf('=')
            if (eq <= 0) return@forEach

            val key = trimmed.substring(0, eq).trim()
            val value = trimmed.substring(eq + 1).trim()
            if (key.isNotEmpty()) {
                map[key] = Uri.decode(value)
            }
        }

        return UrlParts(url = urlPart, headers = map)
    }
}
