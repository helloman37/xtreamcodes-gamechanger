package com.iptvnetworking.tvapp.util

import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream
import java.util.Locale

object AdBlocker {

    // Very small built-in list; extend with whatever domains your movie host uses for ads.
    private val adHosts = listOf(
        "doubleclick.net",
        "googlesyndication.com",
        "googletagservices.com",
        "adservice.google.com",
        "adsystem.com",
        "/ads?",
        "/ads/",
        "adserver.",
        "advertising"
    )

    fun isAdUrl(url: String): Boolean {
        val lower = url.lowercase(Locale.US)
        return adHosts.any { lower.contains(it) }
    }

    fun createEmptyResponse(): WebResourceResponse {
        return WebResourceResponse(
            "text/plain",
            "utf-8",
            ByteArrayInputStream("".toByteArray())
        )
    }
}
