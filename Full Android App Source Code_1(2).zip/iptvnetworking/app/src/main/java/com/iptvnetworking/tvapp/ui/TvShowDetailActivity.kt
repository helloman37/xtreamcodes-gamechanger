package com.iptvnetworking.tvapp.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import android.widget.AdapterView
import androidx.appcompat.app.AppCompatActivity
import com.iptvnetworking.tvapp.R
import com.iptvnetworking.tvapp.util.DeviceOrientationHelper
import com.iptvnetworking.tvapp.util.CacheUtils
import com.iptvnetworking.tvapp.util.SubscriptionGuard
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.iptvnetworking.tvapp.databinding.ActivityTvShowDetailBinding
import com.iptvnetworking.tvapp.movies.MovieConfig
import com.iptvnetworking.tvapp.movies.TmdbClient
import com.iptvnetworking.tvapp.movies.TmdbTvShow
import com.iptvnetworking.tvapp.prefs.Prefs
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class TvEpisodeItem(
    val episodeNumber: Int,
    val name: String?
)

class TvShowDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTvShowDetailBinding
    private lateinit var recommendedAdapter: RecommendedTvShowAdapter

    private var tvId: Int = 0
    private var tvName: String = ""
    private var posterPath: String = ""

    private var seasons: List<Int> = emptyList()
    private var episodes: List<TvEpisodeItem> = emptyList()


    private var launchingWebPlayback: Boolean = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Mirror the main section behaviour: clear app cache whenever entering this screen.
        CacheUtils.clearAppCache(this)

        // Phone UX: TV show details should remain in landscape while browsing TV shows.
        DeviceOrientationHelper.applyPhonePostLoginLandscape(this)
        binding = ActivityTvShowDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        tvId = intent.getIntExtra(EXTRA_TV_ID, 0)
        tvName = intent.getStringExtra(EXTRA_TV_NAME) ?: ""
        posterPath = intent.getStringExtra(EXTRA_POSTER_PATH).orEmpty()

        binding.tvTitle.text = if (tvName.isNotBlank()) tvName else "TV Series"

        binding.btnBack.setOnClickListener {
            finish()
        }

        // Load banner image if we have a poster path
        if (posterPath.isNotBlank()) {
            val url = "https://image.tmdb.org/t/p/w500$posterPath"
            Glide.with(this)
                .load(url)
                .into(binding.imgBanner)
        } else {
            binding.imgBanner.setImageDrawable(null)
        }

        if (tvId <= 0) {
            Toast.makeText(this, "Missing TV ID.", Toast.LENGTH_SHORT).show()
            binding.spinnerSeason.isEnabled = false
            binding.spinnerEpisode.isEnabled = false
            binding.serverSpinner.isEnabled = false
            binding.btnWatch.isEnabled = false
            hideRecommendedRow()
            return
        }

        setupServerSpinner()
        setupRecommendedRow()

        // Enforce subscription before loading seasons/episodes.
        lifecycleScope.launch {
            val ok = SubscriptionGuard.checkAndEnforce(this@TvShowDetailActivity)
            if (ok) {
                loadSeasons()
                loadRecommendations()
            } else {
                hideRecommendedRow()
            }
        }

        binding.btnWatch.setOnClickListener {
            val seasonIndex = binding.spinnerSeason.selectedItemPosition
            val episodeIndex = binding.spinnerEpisode.selectedItemPosition

            val seasonNumber = seasons.getOrNull(seasonIndex)
            val episodeItem = episodes.getOrNull(episodeIndex)

            if (seasonNumber == null || episodeItem == null) {
                Toast.makeText(this, "Select a season and episode.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val url = MovieConfig.buildTvUrl(this, tvId, seasonNumber, episodeItem.episodeNumber)
            if (url.isBlank()) {
                Toast.makeText(this, "Please change server to watch.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Free season/episode list references where possible before opening the heavy WebView player.
            // RecyclerView adapters cleared if present, to free resources before opening player
            // binding.seasonsRecyclerView.adapter = null
            // binding.episodesRecyclerView.adapter = null

            val intent = Intent(this, MovieWebViewActivity::class.java).apply {
                putExtra(MovieWebViewActivity.EXTRA_TITLE, tvName)
                putExtra(MovieWebViewActivity.EXTRA_URL, url)
            }
            startActivity(intent)
            // Keep this detail screen in the back stack so BACK returns to the TV show details.
        }
    }


    override fun onResume() {
        super.onResume()

        launchingWebPlayback = false
        // Keep cache/cookies from accumulating between launches.
        CacheUtils.clearAppCache(this)

        lifecycleScope.launch {
            SubscriptionGuard.checkAndEnforce(this@TvShowDetailActivity, showMessage = false)
        }
        refreshServerSelection()
    }

    override fun onStop() {
        // Don't nuke cache when opening the GeckoView player; it can break the return-to-detail flow.
        if (!launchingWebPlayback) {
            lifecycleScope.launch(Dispatchers.IO) {
                CacheUtils.clearAppCache(this@TvShowDetailActivity)
            }
        }
        super.onStop()
    }

    private fun setupServerSpinner() {
        val names = resources.getStringArray(R.array.movie_server_names).toList()
        val adapter = ArrayAdapter(this, R.layout.item_spinner_tv, names)
        adapter.setDropDownViewResource(getPhoneAwareDropDownLayout())
        binding.serverSpinner.adapter = adapter

        refreshServerSelection()

        binding.serverSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                Prefs.setMovieServerIndex(this@TvShowDetailActivity, position + 1)
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun refreshServerSelection() {
        val names = resources.getStringArray(R.array.movie_server_names)
        val savedIndex = (Prefs.getMovieServerIndex(this) - 1).coerceIn(0, names.lastIndex)
        binding.serverSpinner.setSelection(savedIndex, false)
    }

    private fun setupRecommendedRow() {
        recommendedAdapter = RecommendedTvShowAdapter(emptyList()) { show ->
            openTvDetail(show)
        }
        binding.recommendedRecycler.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        binding.recommendedRecycler.adapter = recommendedAdapter
        hideRecommendedRow()
    }

    private fun showRecommendedLoading() {
        binding.recommendedLabel.visibility = View.VISIBLE
        binding.recommendedProgress.visibility = View.VISIBLE
        binding.recommendedRecycler.visibility = View.GONE
    }

    private fun hideRecommendedRow() {
        binding.recommendedLabel.visibility = View.GONE
        binding.recommendedProgress.visibility = View.GONE
        binding.recommendedRecycler.visibility = View.GONE
    }

    private fun showRecommendations(items: List<TmdbTvShow>) {
        if (items.isEmpty()) {
            hideRecommendedRow()
            return
        }
        binding.recommendedLabel.visibility = View.VISIBLE
        binding.recommendedProgress.visibility = View.GONE
        binding.recommendedRecycler.visibility = View.VISIBLE
        recommendedAdapter.submitList(items)
    }

    private fun loadRecommendations() {
        val apiKey = MovieConfig.TMDB_API_KEY
        if (apiKey.isBlank() || tvId <= 0) {
            hideRecommendedRow()
            return
        }

        showRecommendedLoading()

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val response = TmdbClient.api.getTvRecommendations(tvId, apiKey, page = 1)

                val recs = response.results
                    .filter { it.id != tvId }
                    .filter { it.original_language == null || it.original_language == "en" }
                    .distinctBy { it.id }
                    .take(12)

                withContext(Dispatchers.Main) {
                    showRecommendations(recs)
                }
            } catch (e: Exception) {
                e.printStackTrace()
                withContext(Dispatchers.Main) {
                    hideRecommendedRow()
                }
            }
        }
    }

    private fun openTvDetail(tv: TmdbTvShow) {
        val intent = Intent(this, TvShowDetailActivity::class.java).apply {
            putExtra(EXTRA_TV_ID, tv.id)
            putExtra(EXTRA_TV_NAME, tv.name ?: "")
            putExtra(EXTRA_POSTER_PATH, tv.poster_path ?: "")
        }
        startActivity(intent)
        finish()
    }

    private suspend fun loadSeasons() {
        val apiKey = MovieConfig.TMDB_API_KEY
        if (apiKey.isBlank()) {
            withContext(Dispatchers.Main) {
                                Toast.makeText(this@TvShowDetailActivity, "Set TMDB_API_KEY in MovieConfig first.", Toast.LENGTH_LONG).show()
            }
            return
        }

        try {
            val response = withContext(Dispatchers.IO) {
                TmdbClient.api.getTvDetails(tvId, apiKey)
            }

            val seasonList = response.seasons
                ?.mapNotNull { it.season_number }
                ?.filter { it > 0 }
                ?.sorted()
                ?: emptyList()

            seasons = seasonList
            val overview = response.overview ?: ""

            withContext(Dispatchers.Main) {
                binding.tvDetails.text = overview

                if (seasons.isEmpty()) {
                                        Toast.makeText(this@TvShowDetailActivity, "No seasons found for this series.", Toast.LENGTH_LONG).show()
                    return@withContext
                }

                val labels = seasons.map { "Season $it" }
                val adapter = ArrayAdapter(
                    this@TvShowDetailActivity,
                    R.layout.item_spinner_tv,
                    labels
                ).apply {
                    setDropDownViewResource(getPhoneAwareDropDownLayout())
                }
                binding.spinnerSeason.adapter = adapter

                binding.spinnerSeason.setOnItemSelectedListener(object : android.widget.AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(
                        parent: android.widget.AdapterView<*>?,
                        view: View?,
                        position: Int,
                        id: Long
                    ) {
                        val seasonNumber = seasons.getOrNull(position) ?: return
                        lifecycleScope.launch {
                            loadEpisodes(seasonNumber)
                        }
                    }

                    override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {
                        // no-op
                    }
                })

                // Load first season episodes by default
                val firstSeason = seasons.first()
                lifecycleScope.launch {
                    loadEpisodes(firstSeason)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            withContext(Dispatchers.Main) {
                                Toast.makeText(this@TvShowDetailActivity, "Failed to load seasons.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private suspend fun loadEpisodes(seasonNumber: Int) {
        val apiKey = MovieConfig.TMDB_API_KEY
        if (apiKey.isBlank()) {
            return
        }

        try {
            val seasonResponse = withContext(Dispatchers.IO) {
                TmdbClient.api.getSeasonDetails(tvId, seasonNumber, apiKey)
            }

            val episodeList = seasonResponse.episodes
                ?.mapNotNull { ep ->
                    val num = ep.episode_number
                    if (num != null && num > 0) {
                        TvEpisodeItem(num, ep.name)
                    } else {
                        null
                    }
                }
                ?.sortedBy { it.episodeNumber }
                ?: emptyList()

            episodes = episodeList

            withContext(Dispatchers.Main) {
                val labels = if (episodes.isEmpty()) {
                    listOf("No episodes")
                } else {
                    episodes.map { ep ->
                        val namePart = ep.name?.takeIf { it.isNotBlank() } ?: "Episode ${ep.episodeNumber}"
                        "E${ep.episodeNumber} • $namePart"
                    }
                }

                val adapter = ArrayAdapter(
                    this@TvShowDetailActivity,
                    R.layout.item_spinner_tv,
                    labels
                ).apply {
                    setDropDownViewResource(getPhoneAwareDropDownLayout())
                }
                binding.spinnerEpisode.adapter = adapter

                            }
        } catch (e: Exception) {
            e.printStackTrace()
            withContext(Dispatchers.Main) {
                                Toast.makeText(this@TvShowDetailActivity, "Failed to load episodes.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun getPhoneAwareDropDownLayout(): Int {
        return if (DeviceOrientationHelper.isTv(this)) {
            R.layout.item_spinner_tv_dropdown
        } else {
            R.layout.item_spinner_phone_dropdown
        }
    }

    companion object {
        const val EXTRA_TV_ID = "extra_tv_id"
        const val EXTRA_TV_NAME = "extra_tv_name"
        const val EXTRA_POSTER_PATH = "extra_poster_path"
    }
}