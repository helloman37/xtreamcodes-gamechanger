package com.iptvnetworking.tvapp.ui

import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.iptvnetworking.tvapp.util.DeviceOrientationHelper
import com.iptvnetworking.tvapp.util.CacheUtils
import com.iptvnetworking.tvapp.util.SubscriptionGuard
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.iptvnetworking.tvapp.databinding.ActivityTvShowsBinding
import com.iptvnetworking.tvapp.movies.MovieConfig
import com.iptvnetworking.tvapp.movies.TmdbClient
import com.iptvnetworking.tvapp.movies.TmdbTvShow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
// Main TV Shows screen no longer needs a server selector (server is chosen on the detail page).

class TvShowsActivity : AppCompatActivity() {

    // Limit TMDB pages for TV as well so it doesn't hammer the API.
    // Keep discover light; search can dig a little deeper.
    private val maxDiscoverPages = 2
    private val maxSearchPages = 5
    private val recommendedMaxItems = 40

    private lateinit var binding: ActivityTvShowsBinding
    private lateinit var adapter: TvShowAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Clear cache every time TV Shows is entered.
        CacheUtils.clearAppCache(this)

        // Phone UX: TV Shows should be locked to landscape for better viewing.
        DeviceOrientationHelper.applyPhonePostLoginLandscape(this)
        binding = ActivityTvShowsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = TvShowAdapter(emptyList()) { tv ->
            openTvDetail(tv)
        }
        val spanCount = if (DeviceOrientationHelper.isTv(this)) 5 else 2
        binding.tvShowsRecyclerView.layoutManager = GridLayoutManager(this, spanCount)
        binding.tvShowsRecyclerView.adapter = adapter

        binding.titleText.text = "TV Shows"

        // Validate subscription when entering TV Shows.
        lifecycleScope.launch {
            val ok = SubscriptionGuard.checkAndEnforce(this@TvShowsActivity)
            if (ok) {
                loadDiscoverTv()
            }
        }

        // DPAD / keyboard friendly search
        binding.searchButton.setOnClickListener {
            performSearch()
        }

        binding.searchInput.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH ||
                actionId == EditorInfo.IME_ACTION_DONE ||
                (event?.keyCode == KeyEvent.KEYCODE_DPAD_CENTER && event.action == KeyEvent.ACTION_DOWN)
            ) {
                performSearch()
                true
            } else {
                false
            }
        }

        // Initial load: show TMDB recommended TV shows (up to 40 mixed years).
    }
    override fun onResume() {
        super.onResume()
        CacheUtils.clearAppCache(this)

        // Re-validate account on returning to this screen.
        lifecycleScope.launch {
            SubscriptionGuard.checkAndEnforce(this@TvShowsActivity, showMessage = false)
        }
    }


    override fun onStop() {
        // Clear cache whenever leaving TV Shows for another section.
        CacheUtils.clearAppCache(this)
        super.onStop()
    }
    private fun performSearch() {
    val query = binding.searchInput.text?.toString()?.trim().orEmpty()
    hideKeyboard()

    if (query.isEmpty()) {
        // No query: show discover grid (mixed from current year backwards)
        binding.errorText.visibility = View.GONE
        binding.errorText.text = ""
        loadDiscoverTv()
    } else {
        binding.errorText.visibility = View.GONE
        binding.errorText.text = ""
        searchTv(query)
    }
}

    private fun loadDiscoverTv() {
        val apiKey = MovieConfig.TMDB_API_KEY
        if (apiKey.isBlank()) {
            binding.errorText.visibility = View.VISIBLE
            binding.errorText.text = "Edit MovieConfig.TMDB_API_KEY with your TMDB key."
            Toast.makeText(this, "Set TMDB_API_KEY in MovieConfig first.", Toast.LENGTH_LONG).show()
            return
        }

        binding.errorText.visibility = View.GONE
        binding.errorText.text = ""
        binding.progressBar.visibility = View.VISIBLE

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val allShows = mutableListOf<TmdbTvShow>()
                var page = 1
                val maxPages = maxDiscoverPages

                while (page <= maxPages) {
                    val response = TmdbClient.api.discoverTv(
                        apiKey = apiKey,
                        sortBy = "popularity.desc",
                        page = page
                    )
                    val results = response.results
                    if (results.isEmpty()) break
                    allShows.addAll(results)
                    page++
                }

                
                val shows = allShows
                    .filter { it.original_language == null || it.original_language == "en" }
                    .filter { show ->
                        val year = show.first_air_date?.take(4)?.toIntOrNull() ?: 0
                        year in 1900..2025
                    }
                    .distinctBy { it.id }
                    .shuffled()
                    .take(recommendedMaxItems)
                withContext(Dispatchers.Main) {
                    binding.progressBar.visibility = View.GONE
                    if (shows.isEmpty()) {
                        binding.errorText.visibility = View.VISIBLE
                        binding.errorText.text = "TMDB returned no TV shows. Check API key."
                    } else {
                        binding.errorText.visibility = View.GONE
                        binding.errorText.text = ""
                        adapter.submitList(shows)
                        binding.tvShowsRecyclerView.post {
                            val first = binding.tvShowsRecyclerView.getChildAt(0)
                            if (DeviceOrientationHelper.isTv(this@TvShowsActivity)) {
                            first?.requestFocus()
                        }
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                withContext(Dispatchers.Main) {
                    binding.progressBar.visibility = View.GONE
                    binding.errorText.visibility = View.VISIBLE
                    binding.errorText.text =
                        "Failed to load TV shows: ${e.localizedMessage ?: "Unknown error"}"
                    Toast.makeText(
                        this@TvShowsActivity,
                        "Failed to load TV shows: ${e.localizedMessage ?: "Unknown error"}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    private fun searchTv(query: String) {
        val apiKey = MovieConfig.TMDB_API_KEY
        if (apiKey.isBlank()) {
            binding.errorText.visibility = View.VISIBLE
            binding.errorText.text = "Edit MovieConfig.TMDB_API_KEY with your TMDB key."
            Toast.makeText(this, "Set TMDB_API_KEY in MovieConfig first.", Toast.LENGTH_LONG).show()
            return
        }

        binding.errorText.visibility = View.GONE
        binding.errorText.text = ""
        binding.progressBar.visibility = View.VISIBLE

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val allShows = mutableListOf<TmdbTvShow>()
                var page = 1
                val maxPages = maxSearchPages

                while (page <= maxPages) {
                    val response = TmdbClient.api.searchTv(
                        apiKey = apiKey,
                        query = query,
                        page = page
                    )
                    val results = response.results
                    if (results.isEmpty()) break
                    allShows.addAll(results)
                    page++
                }

                
val shows = allShows
    .filter { it.original_language == null || it.original_language == "en" }
    .sortedWith(
        compareByDescending<TmdbTvShow> {
            it.first_air_date?.take(4)?.toIntOrNull() ?: 0
        }.thenByDescending {
            it.name ?: ""
        }
    )

                withContext(Dispatchers.Main) {
                    binding.progressBar.visibility = View.GONE
                    if (shows.isEmpty()) {
                        binding.errorText.visibility = View.VISIBLE
                        binding.errorText.text = "No results for \"$query\"."
                    } else {
                        binding.errorText.visibility = View.GONE
                        binding.errorText.text = ""
                        adapter.submitList(shows)
                        binding.tvShowsRecyclerView.post {
                            val first = binding.tvShowsRecyclerView.getChildAt(0)
                            if (DeviceOrientationHelper.isTv(this@TvShowsActivity)) {
                            first?.requestFocus()
                        }
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                withContext(Dispatchers.Main) {
                    binding.progressBar.visibility = View.GONE
                    binding.errorText.visibility = View.VISIBLE
                    binding.errorText.text =
                        "Failed to search TV shows: ${e.localizedMessage ?: "Unknown error"}"
                    Toast.makeText(
                        this@TvShowsActivity,
                        "Failed to search TV shows: ${e.localizedMessage ?: "Unknown error"}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    private fun openTvDetail(tv: TmdbTvShow) {
        val intent = Intent(this, TvShowDetailActivity::class.java).apply {
            putExtra(TvShowDetailActivity.EXTRA_TV_ID, tv.id)
            putExtra(TvShowDetailActivity.EXTRA_TV_NAME, tv.name ?: "")
            putExtra(TvShowDetailActivity.EXTRA_POSTER_PATH, tv.poster_path ?: "")
        }
        startActivity(intent)
    }


    private fun hideKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as? android.view.inputmethod.InputMethodManager
        currentFocus?.windowToken?.let { token ->
            imm?.hideSoftInputFromWindow(token, 0)
        }
    }
}