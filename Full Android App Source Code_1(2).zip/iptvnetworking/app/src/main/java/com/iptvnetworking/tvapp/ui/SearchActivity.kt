package com.iptvnetworking.tvapp.ui

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.appcompat.app.AppCompatActivity
import com.iptvnetworking.tvapp.util.DeviceOrientationHelper
import androidx.recyclerview.widget.GridLayoutManager
import com.iptvnetworking.tvapp.databinding.ActivitySearchBinding
import com.iptvnetworking.tvapp.model.Channel
import com.iptvnetworking.tvapp.model.ChannelStore

class SearchActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySearchBinding
    private lateinit var adapter: SearchResultAdapter
    private var allChannels: List<Channel> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        DeviceOrientationHelper.applyPhonePostLoginLandscape(this)
        binding = ActivitySearchBinding.inflate(layoutInflater)
        setContentView(binding.root)

        allChannels = ChannelStore.channels

        adapter = SearchResultAdapter(allChannels) { channel ->
            // Remember index so zapping works from player
            val idx = allChannels.indexOf(channel).takeIf { it >= 0 } ?: 0
            ChannelStore.currentIndex = idx

            val intent = Intent(this, PlayerActivity::class.java).apply {
                putExtra("url", channel.url)
                putExtra("name", channel.name)
            }
            startActivity(intent)
        }

        binding.searchResults.layoutManager =
            GridLayoutManager(this, 4)
        binding.searchResults.adapter = adapter

        binding.searchInput.requestFocus()

        binding.searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filterChannels(s?.toString().orEmpty())
            }

            override fun afterTextChanged(s: Editable?) {
            }
        })
    }

    private fun filterChannels(query: String) {
        if (query.isBlank()) {
            adapter.updateData(allChannels)
            return
        }

        val lower = query.lowercase()
        val filtered = allChannels.filter { ch ->
            ch.name.lowercase().contains(lower) ||
                    (ch.group ?: "").lowercase().contains(lower)
        }
        adapter.updateData(filtered)
    }
}
