package com.iptvnetworking.tvapp.util

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.widget.Toast
import com.google.gson.JsonParser
import com.iptvnetworking.tvapp.network.ApiClient
import com.iptvnetworking.tvapp.prefs.Prefs
import com.iptvnetworking.tvapp.ui.LoginActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Centralized subscription validation.
 *
 * This uses the Xtream Codes-style player_api.php endpoint because it returns
 * clear account status and expiration fields. If your panel only supports using
 * get.php for validation, you can still keep this guard as-is since expired
 * accounts will usually fail auth on player_api as well.
 */
object SubscriptionGuard {

    data class Result(
        val isValid: Boolean,
        val shouldClear: Boolean,
        val isExpired: Boolean = false,
        val isInactive: Boolean = false
    )

    /**
     * Checks user subscription status remotely.
     */
    suspend fun checkAccount(context: Context, username: String, password: String): Result {
        return try {
            val responseText = withContext(Dispatchers.IO) {
                val deviceId = Prefs.getOrCreateDeviceId(context)
                val body = ApiClient.api.getAccountInfo(username, password, deviceId)
                body.string()
            }

            val root = JsonParser.parseString(responseText).asJsonObject
            val userInfo = root.getAsJsonObject("user_info")
                // If the API doesn't return expected structure, don't force logout.
                ?: return Result(isValid = true, shouldClear = false)

            val auth = userInfo.get("auth")?.asString
val status = userInfo.get("status")?.asString

val statusNormalized = status?.trim()?.lowercase()
val isInactive = statusNormalized == "inactive" ||
        statusNormalized == "banned" ||
        statusNormalized == "disabled"
val isExpired = statusNormalized == "expired"

// If auth is present, respect it. If it's missing but status looks active,
// allow access to avoid unnecessary logouts on odd panels.
val authOk = auth?.trim()?.let { it == "1" }
    ?: (statusNormalized == null || statusNormalized == "active")

val isValid = authOk && !isInactive && !isExpired
val shouldClear = isInactive || isExpired

            Result(isValid = isValid, shouldClear = shouldClear, isExpired = isExpired, isInactive = isInactive)
        } catch (e: Exception) {
            e.printStackTrace()
            // Network/parsing error: be permissive to avoid noisy logouts.
            Result(isValid = true, shouldClear = false)
        }
    }

    /**
     * Convenience helper used by Activities.
     *
     * Returns true if the account is valid. If invalid due to expiration or inactive status,
     * this will clear saved credentials and take the user back to Login.
     */
    suspend fun checkAndEnforce(activity: Activity, showMessage: Boolean = true): Boolean {
        val username = Prefs.getUsername(activity)
        val password = Prefs.getPassword(activity)

        if (username.isNullOrEmpty() || password.isNullOrEmpty()) {
            redirectToLogin(activity, showMessage = false)
            return false
        }

        val result = checkAccount(activity, username, password)

        if (!result.isValid && result.shouldClear) {
            Prefs.clear(activity)

            if (showMessage) {
                val msg = when {
                    result.isExpired -> "Subscription expired. Please log in again."
                    result.isInactive -> "Account inactive. Please contact support."
                    else -> "Account not active. Please log in again."
                }
                Toast.makeText(activity, msg, Toast.LENGTH_LONG).show()
            }

            redirectToLogin(activity, showMessage = false)
            return false
        }

        // If API says invalid but we shouldn't clear (rare), still block entry.
        if (!result.isValid) {
            if (showMessage) {
                Toast.makeText(activity, "Account could not be verified.", Toast.LENGTH_SHORT).show()
            }
            redirectToLogin(activity, showMessage = false)
            return false
        }

        return true
    }

    private fun redirectToLogin(activity: Activity, showMessage: Boolean) {
        if (showMessage) {
            Toast.makeText(activity, "Please log in.", Toast.LENGTH_SHORT).show()
        }

        val intent = Intent(activity, LoginActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        activity.startActivity(intent)
        activity.finish()
    }
}
