package com.iptvnetworking.tvapp.network

import okhttp3.ResponseBody
import retrofit2.http.GET
import retrofit2.http.Query

interface ApiService {

    @GET("get.php")
    suspend fun getChannels(
        @Query("username") username: String,
        @Query("password") password: String,
        @Query("device_id") deviceId: String? = null,
        @Query("type") type: String = "m3u_plus",
        @Query("output") output: String = "ts"
    ): ResponseBody

    @GET("player_api.php")
    suspend fun getAccountInfo(
        @Query("username") username: String,
        @Query("password") password: String,
        @Query("device_id") deviceId: String? = null
    ): ResponseBody
}
