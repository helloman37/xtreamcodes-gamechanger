package com.iptvnetworking.tvapp.ui

import android.content.Context
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View

import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.common.C
import androidx.media3.common.util.Util
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer

import com.bumptech.glide.Glide
import com.google.android.gms.cast.MediaInfo
import com.google.android.gms.cast.MediaMetadata
import com.google.android.gms.cast.framework.CastButtonFactory
import com.google.android.gms.cast.framework.CastContext
import com.google.android.gms.cast.framework.Session
import com.google.android.gms.cast.framework.SessionManagerListener
import com.iptvnetworking.tvapp.databinding.ActivityPlayerBinding
import com.iptvnetworking.tvapp.model.ChannelStore
import com.iptvnetworking.tvapp.util.DeviceOrientationHelper
import com.iptvnetworking.tvapp.util.CacheUtils
import com.iptvnetworking.tvapp.prefs.Prefs
import com.iptvnetworking.tvapp.util.StreamUrlUtils
import com.iptvnetworking.tvapp.util.UserAgentUtils

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

import kotlin.math.abs
import androidx.lifecycle.lifecycleScope
import com.iptvnetworking.tvapp.epgdb.EpgDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import android.app.PictureInPictureParams
import android.os.Build
import android.util.Rational
import android.content.res.Configuration

class PlayerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPlayerBinding
    private var player: ExoPlayer? = null

    // LibVLC fallback player
    private var libVlc: LibVLC? = null
    private var vlcPlayer: MediaPlayer? = null

    private var currentUrl: String? = null
    private var currentHeaders: Map<String, String> = emptyMap()
    private var retryCount = 0
    private val maxRetries = 3

    private val overlayHideHandler = Handler(Looper.getMainLooper())
    private var overlayHideRunnable: Runnable? = null

    private val vlcReloadHandler = Handler(Looper.getMainLooper())
    private var vlcRestartScheduled = false

    private var castContext: CastContext? = null
    private var currentChannelName: String = "Channel"

    // Gesture/volume state (phone side)
    private lateinit var audioManager: AudioManager
    private var maxVolume: Int = 0
    private var initialVolume: Int = 0
    private var initialTouchX: Float = 0f
    private var initialTouchY: Float = 0f
    private var isLeftSideGesture: Boolean = true
    private var channelStepPx: Float = 0f
    private var accumulatedChannelSteps: Int = 0

    private val sessionManagerListener = object : SessionManagerListener<Session> {
        override fun onSessionStarted(session: Session, sessionId: String) {
            currentUrl?.let { url ->
                loadMediaToCast(url, currentChannelName)
            }
        }

        override fun onSessionResumed(session: Session, wasSuspended: Boolean) {
            currentUrl?.let { url ->
                loadMediaToCast(url, currentChannelName)
            }
        }

        override fun onSessionEnded(session: Session, error: Int) {
            // no-op for now
        }

        override fun onSessionSuspended(session: Session, reason: Int) {}
        override fun onSessionStarting(session: Session) {}
        override fun onSessionStartFailed(session: Session, error: Int) {}
        override fun onSessionEnding(session: Session) {}
        override fun onSessionResuming(session: Session, sessionId: String) {}
        override fun onSessionResumeFailed(session: Session, error: Int) {}
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        DeviceOrientationHelper.applyPhonePostLoginLandscape(this)
        binding = ActivityPlayerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        channelStepPx = resources.displayMetrics.density * 80f // ~80dp per channel step

        try {
            castContext = CastContext.getSharedInstance(this)
            CastButtonFactory.setUpMediaRouteButton(applicationContext, binding.castButton)
            castContext?.sessionManager?.addSessionManagerListener(sessionManagerListener, Session::class.java)
        } catch (e: Exception) {
            e.printStackTrace()
            binding.castButton.visibility = View.GONE
        }

        setupGestureControls()

        val urlFromIntent = intent.getStringExtra("url")
        val nameFromIntent = intent.getStringExtra("name") ?: "Channel"
        currentChannelName = nameFromIntent

        if (ChannelStore.channels.isEmpty() || urlFromIntent == null) {
            title = nameFromIntent
            if (urlFromIntent != null) {
                initPlayer(urlFromIntent)
                showChannelInfoOverlay(nameFromIntent)
            }
        } else {
            val idx = ChannelStore.currentIndex
            val channel = ChannelStore.channels.getOrNull(idx)
            if (channel != null) {
                title = channel.name
                initPlayer(channel.url)
                showChannelInfoOverlay(channel.name, channel.logoUrl)
            } else {
                val safeUrl = urlFromIntent
                title = nameFromIntent
                initPlayer(safeUrl)
                showChannelInfoOverlay(nameFromIntent)
            }
        }
    }

    private fun setupGestureControls() {
        // A transparent overlay view exists in activity_player.xml
        binding.gestureOverlay.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    initialTouchX = event.x
                    initialTouchY = event.y
                    isLeftSideGesture = initialTouchX < v.width / 2f

                    if (isLeftSideGesture) {
                        initialVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                    } else {
                        accumulatedChannelSteps = 0
                    }
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val deltaY = initialTouchY - event.y // positive when swiping up
                    if (isLeftSideGesture) {
                        handleVolumeSwipe(deltaY, v.height)
                    } else {
                        handleChannelSwipe(deltaY)
                    }
                    true
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    accumulatedChannelSteps = 0
                    true
                }

                else -> false
            }
        }
    }

    private fun handleVolumeSwipe(deltaY: Float, viewHeight: Int) {
        if (viewHeight <= 0 || maxVolume <= 0) return

        // Convert swipe distance into a volume target relative to the initial volume
        val volumeDelta = ((deltaY / viewHeight.toFloat()) * maxVolume).toInt()
        val target = (initialVolume + volumeDelta).coerceIn(0, maxVolume)

        // FLAG_SHOW_UI shows the system volume HUD so users get feedback
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, target, AudioManager.FLAG_SHOW_UI)
    }

    private fun handleChannelSwipe(deltaY: Float) {
        if (ChannelStore.channels.isEmpty() || channelStepPx <= 0f) return

        val steps = (deltaY / channelStepPx).toInt()
        if (steps == accumulatedChannelSteps) return

        val diff = steps - accumulatedChannelSteps
        val times = abs(diff)

        repeat(times) {
            if (diff > 0) {
                // Swipe up => previous channel
                playRelative(-1)
            } else {
                // Swipe down => next channel
                playRelative(1)
            }
        }

        accumulatedChannelSteps = steps
    }

    
    private fun initPlayer(url: String) {
        // Always append a stable device_id so the panel counts Exo + VLC as the same device.
        val deviceId = Prefs.getOrCreateDeviceId(applicationContext)
        val rawUrl = StreamUrlUtils.withDeviceId(url, deviceId)
        val parts = StreamUrlUtils.splitUrlAndHeaders(rawUrl)

        currentUrl = parts.url
        currentHeaders = parts.headers
        retryCount = 0
        // Primary playback uses ExoPlayer; LibVLC is kept as a fallback.
        startExo(parts.url, parts.headers)
    }


    private fun setBufferingVisible(visible: Boolean) {
        try {
            binding.bufferingIndicator.visibility = if (visible) View.VISIBLE else View.GONE
        } catch (_: Throwable) {
        }
    }

private fun startExo(url: String, headers: Map<String, String>) {
        // Ensure VLC is stopped if we were using it before
        releaseVlc()

        binding.playerView.visibility = View.VISIBLE
        binding.playerView.useController = false
        binding.vlcVideoLayout.visibility = View.GONE

        player?.release()

        setBufferingVisible(true)

        val uaFromPlaylist = headers.entries.firstOrNull { it.key.equals("User-Agent", ignoreCase = true) }?.value
        val ua = uaFromPlaylist ?: UserAgentUtils.build(this)

        val requestProps = headers.filterKeys { !it.equals("User-Agent", ignoreCase = true) }

        val dataSourceFactory = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setUserAgent(ua)

        if (requestProps.isNotEmpty()) {
            dataSourceFactory.setDefaultRequestProperties(requestProps)
        }

        val mediaSourceFactory = DefaultMediaSourceFactory(this)
            .setDataSourceFactory(dataSourceFactory)

        val exo = ExoPlayer.Builder(this)
            .setMediaSourceFactory(mediaSourceFactory)
            .build()

        player = exo
        binding.playerView.player = exo

        exo.addListener(object : Player.Listener {

            override fun onPlaybackStateChanged(playbackState: Int) {
                when (playbackState) {
                    Player.STATE_BUFFERING -> setBufferingVisible(true)
                    Player.STATE_READY -> setBufferingVisible(false)
                    Player.STATE_ENDED -> setBufferingVisible(false)
                    Player.STATE_IDLE -> setBufferingVisible(false)
                }
            }

            override fun onIsLoadingChanged(isLoading: Boolean) {
                if (isLoading) {
                    setBufferingVisible(true)
                } else if (player?.playbackState == Player.STATE_READY) {
                    setBufferingVisible(false)
                }
            }

            override fun onRenderedFirstFrame() {
                setBufferingVisible(false)
            }

            override fun onPlayerError(error: PlaybackException) {
                // keep indicator visible while switching to VLC fallback
                setBufferingVisible(true)
                handlePlayerError(error)
            }
        })

        val mediaItem = buildAdaptiveAwareMediaItem(url)
        exo.setMediaItem(mediaItem)
        exo.prepare()
        exo.playWhenReady = true
    }

    private fun buildAdaptiveAwareMediaItem(url: String): MediaItem {
        val uri = Uri.parse(url)
        val builder = MediaItem.Builder().setUri(uri)

        // If the URL has a standard adaptive extension, DefaultMediaSourceFactory
        // will pick the right MediaSource automatically. Setting the MIME type
        // here is mainly a safety net for "weird" URLs without extensions.
        when (Util.inferContentType(uri)) {
            C.CONTENT_TYPE_DASH -> builder.setMimeType(MimeTypes.APPLICATION_MPD)
            C.CONTENT_TYPE_HLS -> builder.setMimeType(MimeTypes.APPLICATION_M3U8)
            C.CONTENT_TYPE_SS -> builder.setMimeType(MimeTypes.APPLICATION_SS)
        }

        return builder.build()
    }

    private fun handlePlayerError(error: PlaybackException? = null) {
        // ExoPlayer is the primary Live TV player.
        // If Exo fails for any reason, fall back to LibVLC for this channel.
        val url = currentUrl
        val headers = currentHeaders
        if (url != null) {
            startVlc(url, headers)
        } else {
            // If we somehow don't have a URL, just let the VLC auto-restart logic handle it.
            scheduleVlcRestart()
        }
    }

    private fun scheduleVlcRestart() {
        val url = currentUrl ?: return

        if (vlcRestartScheduled) return
        vlcRestartScheduled = true

        vlcReloadHandler.postDelayed({
            vlcRestartScheduled = false
            val safeUrl = currentUrl ?: return@postDelayed
            startVlc(safeUrl, currentHeaders)
        }, 1500)
    }

    private fun startVlc(url: String, headers: Map<String, String>) {
        setBufferingVisible(true)
        // Fully stop any existing VLC instance and Exo player
        releaseVlc()

        player?.release()
        player = null
        binding.playerView.player = null
        binding.playerView.visibility = View.GONE

        // Show VLC surface
        binding.vlcVideoLayout.visibility = View.VISIBLE

        if (libVlc == null) {
            val options = arrayListOf(
                "--network-caching=1500",
                "--clock-jitter=0",
                "--clock-synchro=0",
                "--no-drop-late-frames",
                "--no-skip-frames"
            )
            libVlc = LibVLC(this, options)
        }

        val vlc = libVlc ?: return
        val mp = MediaPlayer(vlc)
        vlcPlayer = mp

        // Attach VLC to the layout
        mp.attachViews(binding.vlcVideoLayout, null, false, false)

        // Auto-restart when the stream ends or errors out
        mp.setEventListener { event ->
            when (event.type) {
                MediaPlayer.Event.Opening -> {
                    setBufferingVisible(true)
                }
                MediaPlayer.Event.Buffering -> {
                    // VLC reports buffering as a % float. Show indicator until it settles.
                    try {
                        val pct = event.buffering
                        setBufferingVisible(pct < 100f)
                    } catch (_: Throwable) {
                        setBufferingVisible(true)
                    }
                }
                MediaPlayer.Event.Playing -> {
                    setBufferingVisible(false)
                }
                MediaPlayer.Event.Paused,
                MediaPlayer.Event.Stopped -> {
                    setBufferingVisible(false)
                }
                MediaPlayer.Event.EndReached,
                MediaPlayer.Event.EncounteredError -> {
                    setBufferingVisible(true)
                    scheduleVlcRestart()
                }
            }
        }

        val media = Media(vlc, Uri.parse(url))

        // Keep VLC's HTTP fingerprint aligned with Exo's so the panel doesn't treat fallback as a new device.
        val uaFromPlaylist = headers.entries.firstOrNull { it.key.equals("User-Agent", ignoreCase = true) }?.value
        val ua = uaFromPlaylist ?: UserAgentUtils.build(this)
        runCatching { media.addOption(":http-user-agent=$ua") }

        val referer = headers.entries.firstOrNull {
            it.key.equals("Referer", ignoreCase = true) || it.key.equals("Referrer", ignoreCase = true)
        }?.value
        if (!referer.isNullOrBlank()) {
            runCatching { media.addOption(":http-referrer=$referer") }
        }

        media.setHWDecoderEnabled(true, false)
        mp.media = media
        media.release()

        mp.play()
    }

    private fun releaseVlc() {
        setBufferingVisible(false)
        // Stop any pending auto-restart attempts
        vlcReloadHandler.removeCallbacksAndMessages(null)
        vlcRestartScheduled = false

        try {
            vlcPlayer?.stop()
        } catch (_: Throwable) {}

        try {
            vlcPlayer?.detachViews()
        } catch (_: Throwable) {}

        try {
            vlcPlayer?.release()
        } catch (_: Throwable) {}

        vlcPlayer = null

        try {
            libVlc?.release()
        } catch (_: Throwable) {}

        libVlc = null
    }

    private suspend fun fetchCurrentProgramTitle(channelName: String): String? {
        return try {
            val dao = EpgDatabase.getInstance(this).epgDao()
            val now = System.currentTimeMillis()
            val programs = dao.getProgramsForChannel(channelName)
            if (programs.isEmpty()) {
                null
            } else {
                val current = programs.firstOrNull { p ->
                    now >= p.startMillis && (p.endMillis == null || now < p.endMillis)
                }
                (current ?: programs.first()).title
            }
        } catch (_: Throwable) {
            null
        }
    }


    private fun showChannelInfoOverlay(channelName: String, logoUrl: String? = null) {
        val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())

        // Keep a local copy of the channel name for any future use.
        currentChannelName = channelName

        binding.channelInfoName.text = channelName
        binding.channelInfoTime.text = timeFormat.format(Date())

        binding.channelInfoWatchingLabel.visibility = View.VISIBLE
        binding.channelInfoWatchingTitle.text = ""

        lifecycleScope.launch(Dispatchers.IO) {
            val title = fetchCurrentProgramTitle(channelName)
            withContext(Dispatchers.Main) {
                // If EPG is missing or blank, fall back to the channel name
                val safeTitle = if (!title.isNullOrBlank()) title else channelName
                binding.channelInfoWatchingTitle.text = safeTitle
            }
        }

        if (!logoUrl.isNullOrEmpty()) {
            binding.channelInfoLogo.visibility = View.VISIBLE
            Glide.with(this)
                .load(logoUrl)
                .into(binding.channelInfoLogo)
        } else {
            binding.channelInfoLogo.setImageDrawable(null)
            binding.channelInfoLogo.visibility = View.GONE
        }

        binding.channelInfoOverlay.visibility = View.VISIBLE

        overlayHideRunnable?.let { overlayHideHandler.removeCallbacks(it) }

        val runnable = Runnable {
            binding.channelInfoOverlay.visibility = View.GONE
        }
        overlayHideRunnable = runnable
        overlayHideHandler.postDelayed(runnable, 4000L)
    }


    private fun playRelative(delta: Int) {
        val list = ChannelStore.channels
        if (list.isEmpty()) return

        var idx = ChannelStore.currentIndex + delta
        if (idx < 0) idx = list.size - 1
        if (idx >= list.size) idx = 0
        ChannelStore.currentIndex = idx

        val channel = list.getOrNull(idx) ?: return

        try {
            title = channel.name
            currentChannelName = channel.name
            initPlayer(channel.url)
            showChannelInfoOverlay(channel.name, channel.logoUrl)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Clear cache only when leaving the player back to the browsing UI.
     * Avoid clearing when entering Picture-in-Picture (PiP) because that would interrupt playback.
     */
    private fun clearCacheOnExitToLists() {
        val inPip = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) && isInPictureInPictureMode
        if (inPip) return
        try {
            CacheUtils.clearAppCache(this)
        } catch (_: Throwable) {
        }
    }



    override fun onBackPressed() {
        try {
            // Ensure all playback resources are released before leaving
            releasePlayer()
        } catch (_: Throwable) {
        }

        // User is explicitly leaving playback back to the lists/guide.
        clearCacheOnExitToLists()

        super.onBackPressed()
    }

override fun onUserLeaveHint() {
    super.onUserLeaveHint()
    enterPipIfPossible()
}

private fun enterPipIfPossible() {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
    try {
        val params = PictureInPictureParams.Builder()
            .setAspectRatio(Rational(16, 9))
            .build()
        enterPictureInPictureMode(params)
    } catch (_: Throwable) { }
}

override fun onPictureInPictureModeChanged(
    isInPictureInPictureMode: Boolean,
    newConfig: android.content.res.Configuration
) {
    super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
    // Keep it clean in PiP
    if (isInPictureInPictureMode) {
        try {
            binding.channelInfoOverlay.visibility = android.view.View.GONE
            binding.castButton.visibility = android.view.View.GONE
        } catch (_: Throwable) { }
    } else {
        try {
            binding.castButton.visibility = android.view.View.VISIBLE
        } catch (_: Throwable) { }
    }
}

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        return when (keyCode) {
            KeyEvent.KEYCODE_DPAD_UP,
            KeyEvent.KEYCODE_CHANNEL_UP -> {
                playRelative(-1)
                true
            }

            KeyEvent.KEYCODE_DPAD_DOWN,
            KeyEvent.KEYCODE_CHANNEL_DOWN -> {
                playRelative(1)
                true
            }

            else -> super.onKeyDown(keyCode, event)
        }
    }

    override fun onStop() {
        super.onStop()
        releasePlayer()
    }

    override fun onDestroy() {
        // Capture finshing state early so we only clear cache on real exits (not config changes)
        val finishing = isFinishing
        super.onDestroy()
        castContext?.sessionManager?.removeSessionManagerListener(sessionManagerListener, Session::class.java)
        releasePlayer()

        if (finishing) {
            clearCacheOnExitToLists()
        }
    }

    private fun loadMediaToCast(url: String, title: String) {
        val ctx = castContext ?: return
        val session = ctx.sessionManager.currentCastSession ?: return
        val remoteMediaClient = session.remoteMediaClient ?: return

        val metadata = MediaMetadata(MediaMetadata.MEDIA_TYPE_MOVIE).apply {
            putString(MediaMetadata.KEY_TITLE, title)
        }

        val mediaInfo = MediaInfo.Builder(url)
            .setStreamType(MediaInfo.STREAM_TYPE_BUFFERED)
            .setContentType("application/x-mpegURL")
            .setMetadata(metadata)
            .build()

        remoteMediaClient.load(mediaInfo, true, 0)
        player?.pause()
    }

    private fun releasePlayer() {
        setBufferingVisible(false)
        overlayHideRunnable?.let { overlayHideHandler.removeCallbacks(it) }
        overlayHideRunnable = null

        player?.release()
        player = null

        currentUrl = null
        retryCount = 0

        // Also stop LibVLC if it was used
        releaseVlc()
    }
}
