package com.iptvnetworking.tvapp.util

import android.content.Context
import java.io.File

/**
 * Utility for clearing app cache folders.
 *
 * This targets cache directories only, so user credentials, favorites,
 * and other preferences remain intact.
 */
object CacheUtils {

    fun clearAppCache(context: Context) {
        try {
            deleteDir(context.cacheDir)
        } catch (_: Exception) {
        }

        try {
            deleteDir(context.externalCacheDir)
        } catch (_: Exception) {
        }
    }

    private fun deleteDir(dir: File?) {
        if (dir == null) return
        if (!dir.exists()) return

        val children = dir.listFiles()
        if (children != null) {
            for (child in children) {
                if (child.isDirectory) {
                    deleteDir(child)
                } else {
                    runCatching { child.delete() }
                }
            }
        }        // Keep the root cache directory; only delete its contents.
    }
}
