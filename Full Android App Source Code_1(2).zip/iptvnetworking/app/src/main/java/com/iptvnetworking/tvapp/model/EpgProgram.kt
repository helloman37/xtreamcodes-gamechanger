package com.iptvnetworking.tvapp.model

import java.time.ZonedDateTime

data class EpgProgram(
    val channelId: String,
    val title: String,
    val start: ZonedDateTime,
    val end: ZonedDateTime?,
    val description: String?
)

data class EpgChannelInfo(
    val id: String,
    val displayNames: List<String>
)
