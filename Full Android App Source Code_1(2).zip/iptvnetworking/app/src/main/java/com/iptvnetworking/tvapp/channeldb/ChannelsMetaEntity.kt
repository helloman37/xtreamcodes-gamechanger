package com.iptvnetworking.tvapp.channeldb

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "channels_meta")
data class ChannelsMetaEntity(
    @PrimaryKey val key: String = "channels",
    val lastUpdatedMillis: Long
)
