package com.iptvnetworking.tvapp.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.iptvnetworking.tvapp.util.DeviceOrientationHelper
import androidx.lifecycle.lifecycleScope
import com.iptvnetworking.tvapp.databinding.ActivityMyAccountBinding
import com.iptvnetworking.tvapp.network.ApiClient
import com.iptvnetworking.tvapp.prefs.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.google.gson.JsonParser
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MyAccountActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMyAccountBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        DeviceOrientationHelper.applyPhonePostLoginLandscape(this)
        binding = ActivityMyAccountBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val isTvDevice = DeviceOrientationHelper.isTv(this)
        binding.btnLogout.isFocusable = isTvDevice
        binding.btnLogout.isFocusableInTouchMode = isTvDevice


        binding.btnBack.setOnClickListener {
            finish()
        }

        binding.btnLogout.setOnClickListener {
            Prefs.clear(this)
            val intent = android.content.Intent(this, LoginActivity::class.java).apply {
                flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK or
                        android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK
            }
            startActivity(intent)
        }

        val username = Prefs.getUsername(this)
        val password = Prefs.getPassword(this)

        if (username.isNullOrEmpty() || password.isNullOrEmpty()) {
            binding.tvUsername.text = "Not logged in"
            binding.tvExpiration.text = "Unknown"
            return
        }

        binding.tvUsername.text = username
        binding.tvExpiration.text = "Loading..."

        lifecycleScope.launch {
            loadAccountInfo(username, password)
        }
    }

    private suspend fun loadAccountInfo(username: String, password: String) {
        val responseText = try {
            withContext(Dispatchers.IO) {
                val deviceId = Prefs.getOrCreateDeviceId(this@MyAccountActivity)
                val body = ApiClient.api.getAccountInfo(username, password, deviceId)
                body.string()
            }
        } catch (e: Exception) {
            e.printStackTrace()
            binding.tvExpiration.text = "Network error"
            return
        }

        val expFromJson = parseExpirationFromJson(responseText)
        if (expFromJson != null) {
            binding.tvExpiration.text = formatExpiration(expFromJson)
        } else {
            // If we couldn't parse a field, show raw response so it's at least visible
            binding.tvExpiration.text = responseText.take(80)
        }
    }

    // Parse exp_date from the Xtream Codes style JSON:
    // {"user_info":{"exp_date":"1700000000", ...}, ...}
    // Returns 0L to represent "unlimited".
    private fun parseExpirationFromJson(responseText: String): Long? {
        return try {
            val root = JsonParser.parseString(responseText).asJsonObject
            val userInfo = root.getAsJsonObject("user_info") ?: return null
            val expElement = userInfo.get("exp_date") ?: return null

            val expStr = expElement.asString

            if (expStr.equals("unlimited", ignoreCase = true)) {
                0L
            } else {
                expStr.toLongOrNull()
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun formatExpiration(expTimestamp: Long): String {
        return if (expTimestamp == 0L) {
            "Unlimited"
        } else {
            try {
                val date = Date(expTimestamp * 1000)
                val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
                sdf.format(date)
            } catch (e: Exception) {
                e.printStackTrace()
                expTimestamp.toString()
            }
        }
    }
}
