package com.iptvnetworking.tvapp.ui

import android.content.Intent
import android.app.AlertDialog
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.appcompat.app.AppCompatActivity
import com.iptvnetworking.tvapp.BuildConfig
import com.iptvnetworking.tvapp.util.DeviceOrientationHelper
import com.iptvnetworking.tvapp.util.CacheUtils
import com.iptvnetworking.tvapp.util.SubscriptionGuard
import android.os.Handler
import android.os.Looper
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.iptvnetworking.tvapp.databinding.ActivityHomeBinding
import com.iptvnetworking.tvapp.R
import com.iptvnetworking.tvapp.model.Channel
import com.iptvnetworking.tvapp.model.ChannelStore
import com.iptvnetworking.tvapp.network.ApiClient
import com.iptvnetworking.tvapp.prefs.Prefs
import com.iptvnetworking.tvapp.util.M3UParser
import com.iptvnetworking.tvapp.update.UpdateChecker
import com.iptvnetworking.tvapp.movies.MovieConfig
import com.iptvnetworking.tvapp.movies.TmdbClient
import com.iptvnetworking.tvapp.movies.TmdbMovie
import com.iptvnetworking.tvapp.movies.TmdbTvShow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Calendar


enum class HeroType {
    MOVIE,
    TV
}

data class HeroItem(
    val type: HeroType,
    val movie: TmdbMovie? = null,
    val tv: TmdbTvShow? = null,
    val date: String? = null
)

class HomeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHomeBinding
    private val allChannels = mutableListOf<Channel>()
    private val heroItems = mutableListOf<HeroItem>()
    private var currentHeroItem: HeroItem? = null

    private var heroIndex: Int = 0
    private val heroRotateHandler = Handler(Looper.getMainLooper())
    private val heroRotateRunnable = object : Runnable {
        override fun run() {
            if (heroItems.isNotEmpty()) {
                heroIndex = (heroIndex + 1) % heroItems.size
                updateHeroFromItems()
            }
            if (heroItems.size > 1) {
                heroRotateHandler.postDelayed(this, 10_000L)
            }
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Clear cache every time Home is entered.
        CacheUtils.clearAppCache(this)

        DeviceOrientationHelper.applyPhonePostLoginPortrait(this)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val isTvDevice = DeviceOrientationHelper.isTv(this)
        if (!isTvDevice) {
            val oneTapButtons = listOf(
                binding.btnHomeTvChannels,
                binding.btnHomeEpg,
                binding.btnHomeMovies,
                binding.btnHomeTvShows,
                binding.btnHomeAccount,
                binding.heroWatchButton
            )
            oneTapButtons.forEach { btn ->
                btn.isFocusable = false
                btn.isFocusableInTouchMode = false
            }
        }

        // Check for app updates when landing on Home
        lifecycleScope.launch {
            val info = UpdateChecker.checkForUpdate()
            if (info != null) {
                showUpdateDialog(info)
            }
        }


        binding.btnHomeTvChannels.setOnClickListener {
            startActivity(Intent(this, ChannelListActivity::class.java))
        }

        binding.btnHomeEpg.setOnClickListener {
            startActivity(Intent(this, EpgActivity::class.java))
        }

        binding.btnHomeMovies.setOnClickListener {
            lifecycleScope.launch {
                val ok = SubscriptionGuard.checkAndEnforce(this@HomeActivity)
                if (ok) {
                    startActivity(Intent(this@HomeActivity, MoviesActivity::class.java))
                }
            }
        }


        binding.btnHomeTvShows.setOnClickListener {
            lifecycleScope.launch {
                val ok = SubscriptionGuard.checkAndEnforce(this@HomeActivity)
                if (ok) {
                    startActivity(Intent(this@HomeActivity, TvShowsActivity::class.java))
                }
            }
        }

        binding.btnHomeAccount.setOnClickListener {
            startActivity(Intent(this, MyAccountActivity::class.java))
        }
        binding.heroWatchButton.setOnClickListener {
            val item = currentHeroItem
            if (item != null) {
                // Hero items are TMDB-driven Movies/TV. Validate subscription before opening VOD screens.
                lifecycleScope.launch {
                    val ok = SubscriptionGuard.checkAndEnforce(this@HomeActivity)
                    if (ok) {
                        openHeroItem(item)
                    }
                }
            } else if (allChannels.isNotEmpty()) {
                openChannel(allChannels[0], allChannels)
            } else {
                startActivity(Intent(this, ChannelListActivity::class.java))
            }
        }

        // focus start
        if (DeviceOrientationHelper.isTv(this)) {
            binding.btnHomeTvChannels.requestFocus()
        }

        updateClock()

        val username = Prefs.getUsername(this)
        val password = Prefs.getPassword(this)
        if (username.isNullOrEmpty() || password.isNullOrEmpty()) {
            // no creds, send back to login
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        val user = username
        val pass = password

        lifecycleScope.launch {
            try {
                val fetched = withContext(Dispatchers.IO) {
                    val deviceId = Prefs.getOrCreateDeviceId(this@HomeActivity)
                    val body = ApiClient.api.getChannels(user!!, pass!!, deviceId, type = "m3u")
                    val text = body.string()
                    M3UParser.parse(text)
                }
                allChannels.clear()
                allChannels.addAll(fetched)
                // Hero banner is now driven only by TMDB content; no live-channel fallback
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        // Load hero movies from TMDB to promote VOD content
        loadHeroMovies()
    }

    override fun onResume() {
        super.onResume()
        CacheUtils.clearAppCache(this)
        if (heroItems.size > 1) {
            startHeroRotation()
        }
    }

    override fun onPause() {
        super.onPause()
        stopHeroRotation()
    }

    override fun onStop() {
        // Clear cache whenever leaving Home for another section.
        CacheUtils.clearAppCache(this)
        super.onStop()
    }


    private fun updateClock() {
        val fmt = SimpleDateFormat("h:mm a", Locale.getDefault())
        binding.homeClock.text = fmt.format(Date())
    }

    private fun updateHeroFromFirst() {
        // If a hero item has been set (movie or TV), don't override it with a channel
        if (currentHeroItem != null) {
            return
        }
        val first = allChannels.firstOrNull()
        if (first != null) {
            binding.heroTitle.text = first.name
            binding.heroSubtitle.text = first.group ?: "Live channel"
        }
    }
    
    private fun loadHeroMovies() {
        val apiKey = MovieConfig.TMDB_API_KEY
        if (apiKey.isBlank()) {
            // TMDB not configured; leave hero as default
            return
        }

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                // Grab multiple pages of popular movies and TV, then shuffle them
                val allMovies = mutableListOf<TmdbMovie>()
                val allTv = mutableListOf<TmdbTvShow>()
                val maxPages = 3
                var page = 1

                while (page <= maxPages) {
                    val response = TmdbClient.api.discoverMovies(
                        apiKey = apiKey,
                        sortBy = "popularity.desc",
                        year = null,
                        region = MovieConfig.DEFAULT_REGION,
                        originCountry = "US",
                        page = page
                    )
                    if (response.results.isEmpty()) break
                    allMovies.addAll(response.results)
                    page++
                }

                page = 1
                while (page <= maxPages) {
                    val response = TmdbClient.api.discoverTv(
                        apiKey = apiKey,
                        sortBy = "popularity.desc",
                        page = page
                    )
                    if (response.results.isEmpty()) break
                    allTv.addAll(response.results)
                    page++
                }

                if (allMovies.isEmpty() && allTv.isEmpty()) {
                    withContext(Dispatchers.Main) {
                        heroItems.clear()
                        currentHeroItem = null
                        binding.heroTitle.text = ""
                        binding.heroSubtitle.text = ""
                        binding.heroDescription.text = ""
                        binding.heroImage.setImageDrawable(null)
                    }
                    return@launch
                }

                val movieItems = allMovies
                    .filter { !it.poster_path.isNullOrEmpty() }
                    .map { movie ->
                        HeroItem(
                            type = HeroType.MOVIE,
                            movie = movie,
                            date = movie.release_date
                        )
                    }

                val tvItems = allTv
                    .filter { !it.poster_path.isNullOrEmpty() }
                    .map { tv ->
                        HeroItem(
                            type = HeroType.TV,
                            tv = tv,
                            date = tv.first_air_date
                        )
                    }

                val combined = (movieItems + tvItems).toMutableList()
                combined.shuffle()

                withContext(Dispatchers.Main) {
                    if (combined.isEmpty()) {
                        heroItems.clear()
                        currentHeroItem = null
                        binding.heroTitle.text = ""
                        binding.heroSubtitle.text = ""
                        binding.heroDescription.text = ""
                        binding.heroImage.setImageDrawable(null)
                        return@withContext
                    }

                    heroItems.clear()
                    heroItems.addAll(combined)
                    heroIndex = 0
                    updateHeroFromItems()
                    startHeroRotation()
                }
            } catch (e: Exception) {
                e.printStackTrace()
                // On error, clear hero so we don't show stale placeholders
                withContext(Dispatchers.Main) {
                    heroItems.clear()
                    currentHeroItem = null
                    binding.heroTitle.text = ""
                    binding.heroSubtitle.text = ""
                    binding.heroDescription.text = ""
                    binding.heroImage.setImageDrawable(null)
                }
            }
        }
    }


private fun parseYear(date: String?): Int? {
        if (date.isNullOrBlank()) return null
        return date.take(4).toIntOrNull()
    }

    private fun startHeroRotation() {
        heroRotateHandler.removeCallbacks(heroRotateRunnable)
        if (heroItems.size > 1) {
            heroRotateHandler.postDelayed(heroRotateRunnable, 10_000L)
        }
    }

    private fun stopHeroRotation() {
        heroRotateHandler.removeCallbacks(heroRotateRunnable)
    }



    private fun updateHeroFromItems() {
        if (heroItems.isEmpty()) {
            currentHeroItem = null
            binding.heroTitle.text = ""
            binding.heroSubtitle.text = ""
            binding.heroDescription.text = ""
            binding.heroImage.setImageDrawable(null)
            return
        }

        if (heroIndex !in heroItems.indices) {
            heroIndex = 0
        }

        val item = heroItems[heroIndex]
        currentHeroItem = item

        var title = ""
        var subtitle = ""
        var description = ""
        var posterPath: String? = null

        when (item.type) {
            HeroType.MOVIE -> {
                val movie = item.movie
                title = movie?.title ?: ""
                subtitle = movie?.release_date?.take(4) ?: "Movie"
                description = movie?.overview.orEmpty()
                posterPath = movie?.poster_path
            }
            HeroType.TV -> {
                val tv = item.tv
                title = tv?.name ?: ""
                subtitle = tv?.first_air_date?.take(4) ?: "TV Series"
                description = tv?.overview.orEmpty()
                posterPath = tv?.poster_path
            }
        }

        // Trim very long descriptions so they fit in the overlay
        if (description.length > 160) {
            description = description.substring(0, 157) + "..."
        }

        // Use "Title (Year)" when we have a 4-digit year, otherwise fall back to title/subtitle.
        val displayTitle = if (subtitle.length == 4 && subtitle.all { it.isDigit() }) {
            if (title.isNotBlank()) "$title ($subtitle)" else subtitle
        } else {
            if (title.isNotBlank()) title else subtitle
        }

        binding.heroTitle.text = displayTitle
        binding.heroSubtitle.text = "Trending now"
        binding.heroDescription.text = description

        if (!posterPath.isNullOrEmpty()) {
            val sizePath = if (DeviceOrientationHelper.isTv(this)) "w780" else "w500"
            val imageUrl = "https://image.tmdb.org/t/p/$sizePath$posterPath"
            Glide.with(this)
                .load(imageUrl)
                .centerCrop()
                .into(binding.heroImage)
        } else {
            binding.heroImage.setImageDrawable(null)
        }
    }


private fun openHeroItem(item: HeroItem) {
        when (item.type) {
            HeroType.MOVIE -> {
                val movie = item.movie ?: return
                openHeroMovie(movie)
            }
            HeroType.TV -> {
                val tv = item.tv ?: return
                val intent = Intent(this, TvShowDetailActivity::class.java).apply {
                    putExtra(TvShowDetailActivity.EXTRA_TV_ID, tv.id)
                    putExtra(TvShowDetailActivity.EXTRA_TV_NAME, tv.name ?: "")
                    putExtra(TvShowDetailActivity.EXTRA_POSTER_PATH, tv.poster_path ?: "")
                }
                startActivity(intent)
            }
        }
    }

private fun openHeroMovie(movie: TmdbMovie) {
        val url = MovieConfig.buildMovieUrl(this, movie.id)
        if (url.isBlank()) {
            Toast.makeText(
this, "Movie URL is not configured.", Toast.LENGTH_SHORT).show()
            return
        }

        val intent = Intent(this, MovieWebViewActivity::class.java).apply {
            putExtra(MovieWebViewActivity.EXTRA_TITLE, movie.title ?: "")
            putExtra(MovieWebViewActivity.EXTRA_URL, url)
        }
        startActivity(intent)
    }


    private fun showUpdateDialog(info: UpdateChecker.UpdateInfo) {
        val title = if (info.isForce) "Update required" else "Update available"

        val message = buildString {
            if (info.isForce) {
                append("A new version is required to continue.\n\n")
            } else {
                append("A new version is available.\n\n")
            }

            append("Latest version code: ${info.latestVersionCode}\n")
            if (info.minVersionCode > 0) {
                append("Minimum required code: ${info.minVersionCode}\n")
            }

            if (!info.changelog.isNullOrEmpty()) {
                append("\nChanges:\n")
                append(info.changelog)
            }
        }

        val builder = AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("Update") { _, _ ->
                startUpdateDownload(info.apkUrl)
            }

        if (info.isForce) {
            builder
                .setCancelable(false)
                .setNegativeButton("Exit") { _, _ ->
                    finishAffinity()
                }
        } else {
            builder
                .setCancelable(true)
                .setNegativeButton("Later", null)
        }

        builder.show()
    }


private fun isValidUpdateApk(file: File): Boolean {
    return try {
        if (!file.exists()) return false
        // Guard against HTML/error pages or tiny partial downloads
        if (file.length() < 100 * 1024) return false

        val pm = packageManager

        val info = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.getPackageArchiveInfo(
                file.absolutePath,
                PackageManager.PackageInfoFlags.of(0)
            )
        } else {
            @Suppress("DEPRECATION")
            pm.getPackageArchiveInfo(file.absolutePath, 0)
        } ?: return false

        // Ensure we are updating THIS app, not some wrong package.
        if (info.packageName != packageName) return false

        // Ensure the update is actually newer than the currently installed version.
        val newVersionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            info.longVersionCode
        } else {
            @Suppress("DEPRECATION")
            info.versionCode.toLong()
        }

        if (newVersionCode <= BuildConfig.VERSION_CODE.toLong()) return false

        // Reject APKs that require a higher SDK than this device supports to avoid
        // "There was a problem parsing the package" during install.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            val minSdk = info.applicationInfo?.minSdkVersion ?: 0
            if (minSdk > Build.VERSION.SDK_INT) return false
        }

        true
    } catch (_: Exception) {
        false
    }
}


    private fun startUpdateDownload(apkUrl: String) {
    lifecycleScope.launch {
        // build a simple progress dialog with a horizontal bar
        val progressView = layoutInflater.inflate(R.layout.update_progress_dialog, null)
        val progressBar = progressView.findViewById<android.widget.ProgressBar>(R.id.updateProgressBar)
        val progressText = progressView.findViewById<android.widget.TextView>(R.id.updateProgressText)

        progressBar.isIndeterminate = true
        progressText.text = "Preparing download..."

        val dialog = AlertDialog.Builder(this@HomeActivity)
            .setTitle("Downloading update")
            .setView(progressView)
            .setCancelable(false)
            .create()

        dialog.show()

        val apkFile = withContext(Dispatchers.IO) {
            try {
                val client = OkHttpClient()
                val request = Request.Builder()
                    .url(apkUrl)
                    .build()

                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) return@withContext null

                    val body = response.body ?: return@withContext null
                    val contentLength = body.contentLength()

                    val file = File(cacheDir, "iptv_update.apk")

                    body.byteStream().use { input ->
                        FileOutputStream(file).use { fos ->
                            val buffer = ByteArray(8 * 1024)
                            var totalRead = 0L

                            if (contentLength > 0) {
                                // switch to determinate once we know size
                                withContext(Dispatchers.Main) {
                                    progressBar.isIndeterminate = false
                                    progressBar.max = 100
                                }
                            }

                            while (true) {
                                val bytesRead = input.read(buffer)
                                if (bytesRead == -1) break
                                fos.write(buffer, 0, bytesRead)
                                totalRead += bytesRead

                                if (contentLength > 0) {
                                    val percent = (100 * totalRead / contentLength)
                                        .toInt()
                                        .coerceIn(0, 100)

                                    withContext(Dispatchers.Main) {
                                        progressBar.progress = percent
                                        progressText.text = "Downloading... ${percent}%"
                                    }
                                }
                            }

                            fos.flush()
                        }
                    }

                    file
                }
            } catch (e: Exception) {
                e.printStackTrace()
                null
            }
        }

        dialog.dismiss()

        if (apkFile == null) {
            Toast.makeText(this@HomeActivity, "Update download failed", Toast.LENGTH_LONG).show()
            return@launch
        }

        if (!isValidUpdateApk(apkFile)) {
            Toast.makeText(
                this@HomeActivity,
                "Downloaded update isn't a valid or compatible APK. Check your update link and ensure it points to your signed 32-bit APK.",
                Toast.LENGTH_LONG
            ).show()
            return@launch
        }

        val uri = FileProvider.getUriForFile(
            this@HomeActivity,
            "com.iptvnetworking.tvapp.fileprovider",
            apkFile
        )

        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        try {
            startActivity(intent)
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this@HomeActivity, "No installer available", Toast.LENGTH_LONG).show()
        }
    }
}


    private fun openChannel(channel: Channel, sourceList: List<Channel>) {
        val index = sourceList.indexOf(channel).coerceAtLeast(0)
        ChannelStore.currentIndex = index
        ChannelStore.channels = sourceList

        val intent = Intent(this, PlayerActivity::class.java).apply {
            putExtra("name", channel.name)
            putExtra("url", channel.url)
        }
        startActivity(intent)
    }
}
