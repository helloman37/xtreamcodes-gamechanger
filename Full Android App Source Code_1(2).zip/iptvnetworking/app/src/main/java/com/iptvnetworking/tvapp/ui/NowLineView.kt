package com.iptvnetworking.tvapp.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import androidx.core.content.ContextCompat
import com.iptvnetworking.tvapp.R

/**
 * Lightweight overlay that draws a vertical "NOW" line over the EPG grid.
 *
 * This EPG is a 4-column window (not a full scrollable timeline), so the line
 * is positioned by the host Activity using a 0..1 fraction of the visible time range.
 */
class NowLineView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(context, R.color.epg_now_line)
        strokeWidth = context.resources.displayMetrics.density * 2f
        style = Paint.Style.STROKE
    }

    private var programLeftPx: Float? = null
    private var programRightPx: Float? = null
    private var fraction: Float? = null

    init {
        // Don't block touches/focus; it's purely decorative.
        isClickable = false
        isFocusable = false
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
    }

    fun setProgramArea(leftPx: Int, rightPx: Int) {
        programLeftPx = leftPx.toFloat()
        programRightPx = rightPx.toFloat()
        invalidate()
    }

    /** 0..1 across the visible time range */
    fun setFraction(value: Float?) {
        fraction = value
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val left = programLeftPx ?: return
        val right = programRightPx ?: return
        val f = fraction ?: return

        val clamped = f.coerceIn(0f, 1f)
        val x = left + (right - left) * clamped

        // Draw a straight vertical line through the grid area.
        canvas.drawLine(x, 0f, x, height.toFloat(), paint)
    }
}
