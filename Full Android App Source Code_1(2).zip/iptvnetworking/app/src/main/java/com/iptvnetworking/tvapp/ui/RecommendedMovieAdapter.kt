package com.iptvnetworking.tvapp.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.iptvnetworking.tvapp.databinding.ItemRecommendedMovieBinding
import com.iptvnetworking.tvapp.movies.TmdbMovie
import com.iptvnetworking.tvapp.util.DeviceOrientationHelper

class RecommendedMovieAdapter(
    private var items: List<TmdbMovie>,
    private val onClick: (TmdbMovie) -> Unit
) : RecyclerView.Adapter<RecommendedMovieAdapter.RecommendedMovieViewHolder>() {

    inner class RecommendedMovieViewHolder(val binding: ItemRecommendedMovieBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecommendedMovieViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = ItemRecommendedMovieBinding.inflate(inflater, parent, false)
        return RecommendedMovieViewHolder(binding)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: RecommendedMovieViewHolder, position: Int) {
        val movie = items[position]
        val ctx = holder.binding.root.context

        holder.binding.recTitle.text = movie.title ?: ""

        val posterPath = movie.poster_path
        if (!posterPath.isNullOrBlank()) {
            val sizePath = if (DeviceOrientationHelper.isTv(ctx)) "w342" else "w185"
            val url = "https://image.tmdb.org/t/p/$sizePath$posterPath"
            Glide.with(ctx)
                .load(url)
                .centerCrop()
                .into(holder.binding.recPoster)
        } else {
            holder.binding.recPoster.setImageDrawable(null)
        }

        val isTv = DeviceOrientationHelper.isTv(ctx)
        holder.binding.root.isFocusable = isTv
        holder.binding.root.isFocusableInTouchMode = isTv

        holder.binding.root.setOnClickListener {
            onClick(movie)
        }
    }

    fun submitList(newItems: List<TmdbMovie>) {
        items = newItems
        notifyDataSetChanged()
    }
}
