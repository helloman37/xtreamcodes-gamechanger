package com.iptvnetworking.tvapp.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.iptvnetworking.tvapp.databinding.ItemSearchChannelBinding
import com.iptvnetworking.tvapp.model.Channel

class SearchResultAdapter(
    private var channels: List<Channel>,
    private val onClick: (Channel) -> Unit
) : RecyclerView.Adapter<SearchResultAdapter.SearchResultViewHolder>() {

    inner class SearchResultViewHolder(val binding: ItemSearchChannelBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SearchResultViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = ItemSearchChannelBinding.inflate(inflater, parent, false)
        return SearchResultViewHolder(binding)
    }

    override fun onBindViewHolder(holder: SearchResultViewHolder, position: Int) {
        val channel = channels[position]

        holder.binding.channelName.text = channel.name

        if (!channel.logoUrl.isNullOrEmpty()) {
            holder.binding.channelLogo.visibility = android.view.View.VISIBLE
            Glide.with(holder.itemView)
                .load(channel.logoUrl)
                .into(holder.binding.channelLogo)
        } else {
            holder.binding.channelLogo.setImageDrawable(null)
            holder.binding.channelLogo.visibility = android.view.View.INVISIBLE
        }

        holder.binding.root.setOnClickListener {
            onClick(channel)
        }
    }

    override fun getItemCount(): Int = channels.size

    fun updateData(newList: List<Channel>) {
        channels = newList
        notifyDataSetChanged()
    }
}
