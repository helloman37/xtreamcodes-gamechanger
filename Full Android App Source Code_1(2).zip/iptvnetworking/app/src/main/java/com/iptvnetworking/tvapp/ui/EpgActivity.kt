package com.iptvnetworking.tvapp.ui

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.iptvnetworking.tvapp.databinding.ActivityEpgBinding
import com.iptvnetworking.tvapp.model.Channel
import com.iptvnetworking.tvapp.model.ChannelStore
import com.iptvnetworking.tvapp.model.EpgProgram
import com.iptvnetworking.tvapp.network.ApiClient
import com.iptvnetworking.tvapp.prefs.Prefs
import com.iptvnetworking.tvapp.epgdb.EpgDatabase
import com.iptvnetworking.tvapp.epgdb.EpgRepository
import com.iptvnetworking.tvapp.util.DeviceOrientationHelper
import com.iptvnetworking.tvapp.util.M3UParser
import com.iptvnetworking.tvapp.util.XmlTvParser
import com.iptvnetworking.tvapp.util.StreamUrlUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import android.widget.ArrayAdapter
import androidx.core.widget.addTextChangedListener
import com.iptvnetworking.tvapp.channeldb.ChannelsRepository
import java.time.Duration
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

class EpgActivity : AppCompatActivity() {

    private companion object {
        private const val ALL_CATEGORY = "Categories"
    }


    private lateinit var binding: ActivityEpgBinding
    private lateinit var epgAdapter: EpgRowAdapter
    private val allChannels = mutableListOf<Channel>()
    private var hasLoadedEpg: Boolean = false

    // UI clock for the time header + NOW line overlay
    private val uiHandler = Handler(Looper.getMainLooper())
    private var clockRunnable: Runnable? = null
    private val headerTimeFormatter: DateTimeFormatter = DateTimeFormatter.ofPattern("h:mm a")
    private val slotMinutes: Long = 120L
    private val visibleRangeMinutes: Long = slotMinutes * 4L

    private var currentCategory: String = ALL_CATEGORY
    private var currentQuery: String = ""
    private var categories: List<String> = listOf(ALL_CATEGORY)
private val epgRepo by lazy {
        val db = EpgDatabase.getInstance(applicationContext)
        EpgRepository(db.epgDao())
    }

    private val httpClient by lazy { OkHttpClient() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        DeviceOrientationHelper.applyPhonePostLoginLandscape(this)
        binding = ActivityEpgBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecycler()
        setupUi()
        startTimeHeaderAndNowLine()

        
        setupFilters()
        lifecycleScope.launch {
            loadChannelsAndEpg()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        clockRunnable?.let { uiHandler.removeCallbacks(it) }
    }

    private fun startTimeHeaderAndNowLine() {
        // Wait for layout so we can align the NOW line with the program columns.
        binding.root.post {
            alignNowLineToProgramColumns()
            updateTimeHeaderAndNowLine()

            val r = object : Runnable {
                override fun run() {
                    updateTimeHeaderAndNowLine()
                    uiHandler.postDelayed(this, 30_000L)
                }
            }
            clockRunnable = r
            uiHandler.postDelayed(r, 30_000L)
        }
    }

    private fun alignNowLineToProgramColumns() {
        try {
            val containerLoc = IntArray(2)
            val slot1Loc = IntArray(2)
            val slot4Loc = IntArray(2)

            binding.epgGridContainer.getLocationInWindow(containerLoc)
            binding.epgTimeSlot1.getLocationInWindow(slot1Loc)
            binding.epgTimeSlot4.getLocationInWindow(slot4Loc)

            val left = (slot1Loc[0] - containerLoc[0]).coerceAtLeast(0)
            val right = (slot4Loc[0] - containerLoc[0] + binding.epgTimeSlot4.width)
                .coerceAtLeast(left + 1)

            binding.nowLineView.setProgramArea(left, right)
        } catch (_: Throwable) {
            // If anything goes sideways (rare), just skip the line.
        }
    }

    private fun updateTimeHeaderAndNowLine() {
        try {
            val now = ZonedDateTime.now()
            val startHour = (now.hour / 2) * 2
            val windowStart = now.withHour(startHour).withMinute(0).withSecond(0).withNano(0)

            binding.epgTimeSlot1.text = windowStart.format(headerTimeFormatter)
            binding.epgTimeSlot2.text = windowStart.plusHours(2).format(headerTimeFormatter)
            binding.epgTimeSlot3.text = windowStart.plusHours(4).format(headerTimeFormatter)
            binding.epgTimeSlot4.text = windowStart.plusHours(6).format(headerTimeFormatter)

            val minutesSince = Duration.between(windowStart, now)
                .toMinutes()
                .coerceIn(0L, visibleRangeMinutes)

            val fraction = minutesSince.toFloat() / visibleRangeMinutes.toFloat()
            binding.nowLineView.setFraction(fraction)
        } catch (_: Throwable) {
            // Never crash the guide for a decorative header/line.
        }
    }

    private fun setupRecycler() {
        binding.epgRecycler.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)

        epgAdapter = EpgRowAdapter(
            channels = emptyList(),
            onClick = { channel -> openChannel(channel) },
            onFocused = { _ -> /* reserved for future detailed side panel */ }
        )

        binding.epgRecycler.adapter = epgAdapter
    }

    private fun setupUi() {
        binding.backButton.setOnClickListener {
            finish()
        }

        // Manual refresh to re-fetch channel list and XMLTV data.
        binding.refreshButton.setOnClickListener {
            Toast.makeText(this, "Refreshing...", Toast.LENGTH_SHORT).show()
            hasLoadedEpg = false
            lifecycleScope.launch {
                loadChannelsAndEpg()
            }
        }
    }

    private suspend fun loadChannelsAndEpg() {
        val username = Prefs.getUsername(this)
        val password = Prefs.getPassword(this)

        if (username.isNullOrEmpty() || password.isNullOrEmpty()) {
            Toast.makeText(this, "Please log in again", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        try {
            // 1) Load channel list (shared cache with Live TV)
val channelsRepo = ChannelsRepository(this)

val cachedChannels = withContext(Dispatchers.IO) { channelsRepo.getCachedChannels() }
val channelsStale = withContext(Dispatchers.IO) { channelsRepo.isStale(12) }

val channels = if (cachedChannels.isNotEmpty() && !channelsStale) {
    cachedChannels
} else {
    val fresh = withContext(Dispatchers.IO) {
        val deviceId = Prefs.getOrCreateDeviceId(applicationContext)
        ApiClient.api.getChannels(username, password, deviceId, type = "m3u").use { body ->
            val text = body.string()
            M3UParser.parse(text)
        }
    }
    if (fresh.isNotEmpty()) {
        withContext(Dispatchers.IO) { channelsRepo.saveChannels(fresh) }
        fresh
    } else {
        cachedChannels
    }
}

if (channels.isEmpty()) {
    Toast.makeText(this, "No channels available", Toast.LENGTH_LONG).show()
    return
}

ChannelStore.channels = channels
allChannels.clear()
allChannels.addAll(channels)
updateCategoryDropdown(allChannels)
applyFilters()


            // 1.5) Try DB-cached EPG first for instant UI
            val cachedEpg = withContext(Dispatchers.IO) {
                epgRepo.getEpgByChannelName()
            }
            if (cachedEpg.isNotEmpty()) {
                epgAdapter.updateEpg(cachedEpg)
                hasLoadedEpg = true
            }

            // 2) Load EPG xmltv and wire it into the adapter
            val shouldRefresh = withContext(Dispatchers.IO) {
                // 12-hour TTL for disk cache
                epgRepo.isStale(ttlMinutes = 180) // 3-hour TTL so guide refreshes more often
            }
            if (!shouldRefresh && hasLoadedEpg) {
                return
            }

            val epgUrl = buildEpgUrl(username, password)
            if (epgUrl == null) {
                // No EPG configured; just show the channel list
                return
            }

            val epgMap = withContext(Dispatchers.IO) {
                val request = Request.Builder()
                    .url(epgUrl)
                    .build()

                httpClient.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) return@use emptyMap<String, List<EpgProgram>>()

                    val xml = response.body?.string().orEmpty()
                    if (xml.isBlank()) return@use emptyMap<String, List<EpgProgram>>()

                    val xmlTvData = XmlTvParser.parse(xml)
                    XmlTvParser.buildEpgByChannelName(channels, xmlTvData)
                }
            }

            if (epgMap.isNotEmpty()) {
                epgAdapter.updateEpg(epgMap)
                hasLoadedEpg = true

                // Persist to DB for next launch
                withContext(Dispatchers.IO) {
                    epgRepo.replaceAll(epgMap)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            if (!hasLoadedEpg) {
                Toast.makeText(this, "Failed to load EPG", Toast.LENGTH_LONG).show()
            }
        }
    }

    /**
     * Build the EPG URL using either the value from Settings or the default:
     *   http://test.iptvnetworking.com/channels/epg.xml
     * and append Xtream Codes style XMLTV params (?username=...&password=...) if
     * they are not already present.
     */
    private fun buildEpgUrl(username: String, password: String): String? {
        val fromPrefs = Prefs.getEpgUrl(this)?.takeIf { it.isNotBlank() }
        val base = fromPrefs ?: "http://panel.iptvnetworking.com/xmltv.php"

        if (base.isBlank()) return null

        val deviceId = Prefs.getOrCreateDeviceId(applicationContext)

        // If user already included username/password params, just ensure device_id is present.
        if (base.contains("username=", ignoreCase = true) ||
            base.contains("password=", ignoreCase = true)
        ) {
            return StreamUrlUtils.withDeviceId(base, deviceId)
        }

        val separator = if (base.contains("?")) "&" else "?"
        val withCreds = "$base${separator}username=$username&password=$password"
        return StreamUrlUtils.withDeviceId(withCreds, deviceId)
    }
private fun setupFilters() {
        // Make the category dropdown reliably open on tap/focus
binding.categoryDropdown.setOnClickListener {
    try { binding.categoryDropdown.showDropDown() } catch (_: Throwable) { }
}
binding.categoryDropdown.setOnFocusChangeListener { _, hasFocus ->
    if (hasFocus) {
        try { binding.categoryDropdown.showDropDown() } catch (_: Throwable) { }
    }
}

try {
        binding.epgSearchButton.setOnClickListener {
            binding.searchBox.requestFocus()
            applyFilters()
        }
    } catch (_: Throwable) { }

// Category dropdown is populated after channels load.
    binding.categoryDropdown.setOnItemClickListener { _, _, position, _ ->
        if (position in categories.indices) {
            currentCategory = categories[position]
            applyFilters()
        }
    }

    binding.searchBox.addTextChangedListener { text ->
        currentQuery = text?.toString().orEmpty()
        applyFilters()
    }
}

private fun updateCategoryDropdown(channels: List<Channel>) {
    val seen = LinkedHashSet<String>()
    for (c in channels) {
        val g = c.group?.trim()
        if (!g.isNullOrEmpty()) {
            seen.add(g)
        }
    }

    categories = listOf(ALL_CATEGORY) + seen.toList()

    val adapter = ArrayAdapter(
        this,
        android.R.layout.simple_list_item_1,
        categories
    )
    binding.categoryDropdown.setAdapter(adapter)

    // Default selection
    if (currentCategory !in categories) {
        currentCategory = ALL_CATEGORY
    }
    binding.categoryDropdown.setText(currentCategory, false)
}

private fun applyFilters() {
    val category = currentCategory
    val query = currentQuery.trim().lowercase()

    val filtered = allChannels.filter { ch ->
        val group = ch.group?.trim().orEmpty()
        val matchesCategory = category == ALL_CATEGORY || group.equals(category, ignoreCase = true)
        val matchesQuery = query.isEmpty() || ch.name.lowercase().contains(query)
        matchesCategory && matchesQuery
    }

    epgAdapter.updateData(filtered)

    // Keep EPG mapping intact; adapter will pick programmes by channel name.
}

    private fun openChannel(channel: Channel) {
        val index = allChannels.indexOf(channel).coerceAtLeast(0)
        ChannelStore.channels = allChannels
        ChannelStore.currentIndex = index

        val intent = Intent(this, PlayerActivity::class.java).apply {
            putExtra("name", channel.name)
            putExtra("url", channel.url)
        }
        startActivity(intent)
    }
}