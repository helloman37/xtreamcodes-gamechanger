package com.iptvnetworking.tvapp.model

// Legacy stub file.
// Real EPG models are defined in EpgProgram.kt (EpgProgram, EpgChannelInfo).
// Kept empty to avoid duplicate class declarations when updating older projects.
