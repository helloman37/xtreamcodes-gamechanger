package com.iptvnetworking.tvapp.util

import android.content.Context
import com.iptvnetworking.tvapp.BuildConfig
import com.iptvnetworking.tvapp.prefs.Prefs

/**
 * Generates a consistent User-Agent used by BOTH Exo and VLC so the panel
 * sees one stable fingerprint when the app falls back between players.
 */
object UserAgentUtils {

    fun build(context: Context): String {
        val deviceId = Prefs.getOrCreateDeviceId(context)
        val version = BuildConfig.VERSION_NAME
        return "MyTvApp/$version (Android; device_id=$deviceId)"
    }
}
