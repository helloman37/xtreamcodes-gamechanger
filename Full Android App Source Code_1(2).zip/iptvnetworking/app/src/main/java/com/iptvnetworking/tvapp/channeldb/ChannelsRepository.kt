package com.iptvnetworking.tvapp.channeldb

import android.content.Context
import com.iptvnetworking.tvapp.model.Channel
import java.util.concurrent.TimeUnit

class ChannelsRepository(private val context: Context) {

    private val dao by lazy { ChannelsDatabase.getInstance(context).channelsDao() }

    suspend fun getCachedChannels(): List<Channel> {
        return dao.getAllChannels().map { it.toModel() }
    }

    suspend fun isStale(ttlHours: Long = 12): Boolean {
        val meta = dao.getMeta("channels") ?: return true
        val age = System.currentTimeMillis() - meta.lastUpdatedMillis
        return age > TimeUnit.HOURS.toMillis(ttlHours)
    }

    suspend fun clearAll() {
        dao.clearChannels()
        dao.clearMeta("channels")
    }

    suspend fun saveChannels(channels: List<Channel>) {
        val entities = channels.mapIndexed { idx, c ->
            ChannelEntity(
                url = c.url,
                name = c.name,
                logoUrl = c.logoUrl,
                `group` = c.group,
                orderIndex = idx
            )
        }
        dao.replaceAll(entities, System.currentTimeMillis())
    }
}

private fun ChannelEntity.toModel(): Channel {
    return Channel(
        name = name,
        url = url,
        logoUrl = logoUrl,
        group = `group`
    )
}
