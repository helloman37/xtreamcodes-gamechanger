package com.iptvnetworking.tvapp.ui

import android.os.Bundle
import android.os.SystemClock
import android.os.Handler
import android.os.Looper
import android.content.Context
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.InputDevice
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.iptvnetworking.tvapp.databinding.ActivityMovieWebviewBinding
import com.iptvnetworking.tvapp.util.DeviceOrientationHelper
import com.iptvnetworking.tvapp.util.CacheUtils
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import com.iptvnetworking.tvapp.util.SubscriptionGuard
import androidx.lifecycle.lifecycleScope
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSessionSettings
import kotlin.math.max
import kotlin.math.min

class MovieWebViewActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_URL = "extra_url"
        const val EXTRA_TITLE = "extra_title"

        @Volatile
        private var sharedRuntime: GeckoRuntime? = null

        private fun obtainRuntime(context: Context): GeckoRuntime {
            val appContext = context.applicationContext
            return sharedRuntime ?: synchronized(this) {
                sharedRuntime ?: GeckoRuntime.create(appContext).also { sharedRuntime = it }
            }
        }
    }

    private lateinit var binding: ActivityMovieWebviewBinding
    private lateinit var session: GeckoSession

    // Virtual cursor for TV remotes
    private var cursorX: Float = 0f
    private var cursorY: Float = 0f
    private val cursorStep: Float = 40f
    private val cursorHideDelay = 3000L
    private val cursorHandler by lazy { Handler(Looper.getMainLooper()) }
    private val cursorHideRunnable = Runnable {
        if (isTvDevice) {
            binding.cursorView.visibility = View.GONE
        }
    }

    private val isTvDevice: Boolean by lazy { DeviceOrientationHelper.isTv(this) }

    // We only want to clear cache when this GeckoView activity is truly exiting.
    // onStop() can fire for many reasons (player/dialog on top), so gate it.
    @Volatile
    private var exitCacheCleared: Boolean = false

    private fun clearCacheOnExit() {
        if (exitCacheCleared) return
        exitCacheCleared = true
        // Deleting cache can be slow; do it off the UI thread.
        lifecycleScope.launch(Dispatchers.IO) {
            CacheUtils.clearAppCache(this@MovieWebViewActivity)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // NOTE: Cache clearing happens ONLY when exiting this screen.
        binding = ActivityMovieWebviewBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Phones/tablets get landscape; TVs keep whatever the system wants.
        DeviceOrientationHelper.applyPhonePostLoginLandscape(this)

        // Enforce active subscription before loading any VOD content.
        lifecycleScope.launch {
            val ok = SubscriptionGuard.checkAndEnforce(this@MovieWebViewActivity)
            if (!ok) return@launch

            val url = intent.getStringExtra(EXTRA_URL) ?: ""
            val title = intent.getStringExtra(EXTRA_TITLE) ?: ""

            if (url.isBlank()) {
                Toast.makeText(this@MovieWebViewActivity, "No URL provided", Toast.LENGTH_SHORT).show()
                finish()
                return@launch
            }

            // Title is currently unused in this screen UI, but kept for future overlays.
            @Suppress("UNUSED_VARIABLE")
            val safeTitle = title

            initGecko(url)

            if (isTvDevice) {
                // On TV, center the virtual cursor over the page once layout is ready.
                binding.cursorView.post {
                    val w = binding.geckoView.width
                    val h = binding.geckoView.height
                    if (w > 0 && h > 0) {
                        cursorX = w / 2f
                        cursorY = h / 2f
                    }
                    binding.cursorView.visibility = View.VISIBLE
                    updateCursor()
                    scheduleCursorHide()
                }
            } else {
                // On phones/tablets, the cursor is never shown.
                binding.cursorView.visibility = View.GONE
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Silent re-check when returning to this playback screen.
        lifecycleScope.launch {
            SubscriptionGuard.checkAndEnforce(this@MovieWebViewActivity, showMessage = false)
        }
    }
    private fun initGecko(url: String) {
        val runtime = obtainRuntime(this)

        // On touch devices (phones/tablets), make the GeckoView content easier
        // to read and tap by gently increasing font size and enabling better
        // zoom behaviour when supported by this GeckoView version.
        if (!isTvDevice) {
            try {
                val runtimeSettings = runtime.javaClass
                    .getMethod("getSettings")
                    .invoke(runtime)

                if (runtimeSettings != null) {
                    val settingsClass = runtimeSettings.javaClass

                    // Try to respect system font scale or fall back to a small bump.
                    try {
                        settingsClass
                            .getMethod(
                                "setAutomaticFontSizeAdjustment",
                                Boolean::class.javaPrimitiveType
                            )
                            .invoke(runtimeSettings, true)
                    } catch (_: Throwable) {
                        try {
                            settingsClass
                                .getMethod(
                                    "setFontSizeFactor",
                                    Float::class.javaPrimitiveType
                                )
                                .invoke(runtimeSettings, 1.15f)
                        } catch (_: Throwable) {
                        }
                    }

                    // Help users zoom into small controls on touch devices.
                    try {
                        settingsClass
                            .getMethod(
                                "setForceUserScalableEnabled",
                                Boolean::class.javaPrimitiveType
                            )
                            .invoke(runtimeSettings, true)
                    } catch (_: Throwable) {
                    }

                    try {
                        settingsClass
                            .getMethod(
                                "setInputAutoZoomEnabled",
                                Boolean::class.javaPrimitiveType
                            )
                            .invoke(runtimeSettings, true)
                    } catch (_: Throwable) {
                    }

                    // Improve readability on non mobile-friendly pages.
                    try {
                        settingsClass
                            .getMethod(
                                "setFontInflationEnabled",
                                Boolean::class.javaPrimitiveType
                            )
                            .invoke(runtimeSettings, true)
                    } catch (_: Throwable) {
                    }
                }
            } catch (_: Throwable) {
            }
        }

        val builder = GeckoSessionSettings.Builder()

        // Use private mode for VOD web playback so no persistent web cache/cookies
        // survive between sections or between content launches.
        // Reflection keeps this resilient across GeckoView API changes.
        try {
            builder.javaClass
                .getMethod("usePrivateMode", Boolean::class.javaPrimitiveType)
                .invoke(builder, true)
        } catch (_: Throwable) {
        }

                // Always prefer the mobile UA + mobile viewport so pages stay touch‑friendly
        // on phones/tablets and still render well on TVs.
        // Using reflection keeps this resilient across GeckoView API changes.
        try {
            builder.javaClass
                .getMethod("userAgentMode", Int::class.javaPrimitiveType)
                .invoke(builder, GeckoSessionSettings.USER_AGENT_MODE_MOBILE)
        } catch (_: Throwable) {
            // Ignore if not supported by this GeckoView version.
        }

        try {
            builder.javaClass
                .getMethod("viewportMode", Int::class.javaPrimitiveType)
                .invoke(builder, GeckoSessionSettings.VIEWPORT_MODE_MOBILE)
        } catch (_: Throwable) {
            // Ignore if not supported by this GeckoView version.
        }

        val settings = builder.build()

        session = GeckoSession(settings)

        // Second-layer attempt in case the Builder API differs.
        try {
            session.settings.javaClass
                .getMethod("setUserAgentMode", Int::class.javaPrimitiveType)
                .invoke(session.settings, GeckoSessionSettings.USER_AGENT_MODE_MOBILE)
        } catch (_: Throwable) {
        }

        try {
            session.settings.javaClass
                .getMethod("setViewportMode", Int::class.javaPrimitiveType)
                .invoke(session.settings, GeckoSessionSettings.VIEWPORT_MODE_MOBILE)
        } catch (_: Throwable) {
        }

        // Attempt to enforce private mode on the session settings as well.
        try {
            session.settings.javaClass
                .getMethod("setUsePrivateMode", Boolean::class.javaPrimitiveType)
                .invoke(session.settings, true)
        } catch (_: Throwable) {
        }


        session.progressDelegate = object : GeckoSession.ProgressDelegate {
            override fun onPageStart(session: GeckoSession, url: String) {
                binding.progressBar.visibility = View.VISIBLE
            }

            override fun onPageStop(session: GeckoSession, success: Boolean) {
                binding.progressBar.visibility = View.GONE
            }
        }

        session.open(runtime)
        binding.geckoView.setSession(session)
        session.loadUri(url)
    }

    private fun updateCursor() {
        binding.cursorView.translationX = cursorX
        binding.cursorView.translationY = cursorY
    }

    private fun scheduleCursorHide() {
        if (!isTvDevice) return
        cursorHandler.removeCallbacks(cursorHideRunnable)
        cursorHandler.postDelayed(cursorHideRunnable, cursorHideDelay)
    }
    private fun sendClickToGecko() {
        // Use the center of the cursor icon as the click hotspot.
        val cx = cursorX + (binding.cursorView.width / 2f)
        val cy = cursorY + (binding.cursorView.height / 2f)

        val now = SystemClock.uptimeMillis()
        val downTime = now

        val down = MotionEvent.obtain(
            downTime,
            now,
            MotionEvent.ACTION_DOWN,
            cx,
            cy,
            0
        )

        val up = MotionEvent.obtain(
            downTime,
            now + 80,
            MotionEvent.ACTION_UP,
            cx,
            cy,
            0
        )

        // Ensure GeckoView treats these as touch events.
        down.source = InputDevice.SOURCE_TOUCHSCREEN
        up.source = InputDevice.SOURCE_TOUCHSCREEN

        binding.geckoView.dispatchTouchEvent(down)
        binding.geckoView.dispatchTouchEvent(up)

        down.recycle()
        up.recycle()
    }


    
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        // On TV devices, intercept DPAD keys here so GeckoView doesn't swallow them.
        if (isTvDevice && event.action == KeyEvent.ACTION_DOWN) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_DPAD_LEFT -> {
                    cursorX = max(0f, cursorX - cursorStep)
                    binding.cursorView.visibility = View.VISIBLE
                    updateCursor()
                    scheduleCursorHide()
                    return true
                }
                KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    val maxX = (binding.geckoView.width - binding.cursorView.width).toFloat()
                    cursorX = min(maxX, cursorX + cursorStep)
                    binding.cursorView.visibility = View.VISIBLE
                    updateCursor()
                    scheduleCursorHide()
                    return true
                }
                KeyEvent.KEYCODE_DPAD_UP -> {
                    cursorY = max(0f, cursorY - cursorStep)
                    binding.cursorView.visibility = View.VISIBLE
                    updateCursor()
                    scheduleCursorHide()
                    return true
                }
                KeyEvent.KEYCODE_DPAD_DOWN -> {
                    val maxY = (binding.geckoView.height - binding.cursorView.height).toFloat()
                    cursorY = min(maxY, cursorY + cursorStep)
                    binding.cursorView.visibility = View.VISIBLE
                    updateCursor()
                    scheduleCursorHide()
                    return true
                }
                KeyEvent.KEYCODE_DPAD_CENTER,
                KeyEvent.KEYCODE_ENTER -> {
                    binding.cursorView.visibility = View.VISIBLE
                    updateCursor()
                    sendClickToGecko()
                    scheduleCursorHide()
                    return true
                }
                KeyEvent.KEYCODE_BACK -> {
                    handleBack()
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        // On non‑TV devices just let the default handling work, but still
        // consume BACK to close the activity.
        if (!isTvDevice && keyCode == KeyEvent.KEYCODE_BACK) {
            handleBack()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun handleBack() {
        // First try to navigate back within GeckoView.
        if (this::session.isInitialized) {
            try {
                val can = session.javaClass.getMethod("canGoBack").invoke(session) as? Boolean ?: false
                if (can) {
                    session.javaClass.getMethod("goBack").invoke(session)
                    return
                }
            } catch (_: Throwable) {
                // Fall through to closing the activity.
            }
        }
        // Only clear cache when we are truly exiting GeckoView.
        clearCacheOnExit()
        finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        handleBack()
    }

    override fun onStop() {
        // onStop() happens when something comes in front of us (player, dialogs, etc.).
        // Only clear cache when we're actually finishing this activity.
        if (isFinishing && !isChangingConfigurations) {
            clearCacheOnExit()
        }
        super.onStop()
    }
    override fun onDestroy() {
        if (isFinishing && !isChangingConfigurations) {
            clearCacheOnExit()
        }
        if (this::session.isInitialized) {
            session.close()
        }
        super.onDestroy()
    }
}
