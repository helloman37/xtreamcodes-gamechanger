package com.iptvnetworking.tvapp.channeldb

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "channels")
data class ChannelEntity(
    @PrimaryKey val url: String,
    val name: String,
    val logoUrl: String? = null,
    val `group`: String? = null,
    val orderIndex: Int = 0
)
