package com.iptvnetworking.tvapp.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.iptvnetworking.tvapp.R
import com.iptvnetworking.tvapp.databinding.ActivityMovieDetailBinding
import com.iptvnetworking.tvapp.movies.MovieConfig
import com.iptvnetworking.tvapp.movies.TmdbClient
import com.iptvnetworking.tvapp.movies.TmdbMovie
import com.iptvnetworking.tvapp.prefs.Prefs
import com.iptvnetworking.tvapp.util.CacheUtils
import com.iptvnetworking.tvapp.util.DeviceOrientationHelper
import com.iptvnetworking.tvapp.util.SubscriptionGuard
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Movie detail page (poster + details + server dropdown + Play Now).
 *
 * This mirrors the TV show detail flow so users can switch servers and retry playback
 * without backing out to the Movies grid.
 */
class MovieDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMovieDetailBinding
    private lateinit var recommendedAdapter: RecommendedMovieAdapter

    private var movieId: Int = 0
    private var movieTitle: String = ""
    private var overview: String = ""
    private var posterPath: String = ""
    private var releaseDate: String = ""


    private var launchingWebPlayback: Boolean = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Mirror the main section behaviour: clear app cache whenever entering this screen.
        CacheUtils.clearAppCache(this)

        // Phone UX: Movie details should remain in landscape while browsing movies.
        DeviceOrientationHelper.applyPhonePostLoginLandscape(this)
        binding = ActivityMovieDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        movieId = intent.getIntExtra(EXTRA_MOVIE_ID, 0)
        movieTitle = intent.getStringExtra(EXTRA_MOVIE_TITLE) ?: ""
        overview = intent.getStringExtra(EXTRA_MOVIE_OVERVIEW) ?: ""
        posterPath = intent.getStringExtra(EXTRA_POSTER_PATH).orEmpty()
        releaseDate = intent.getStringExtra(EXTRA_RELEASE_DATE).orEmpty()

        binding.btnBack.setOnClickListener { finish() }

        // Basic binding
        binding.movieTitle.text = movieTitle.ifBlank { "Movie" }
        binding.movieDetails.text = overview

        val year = releaseDate.take(4).takeIf { it.length == 4 } ?: ""
        binding.movieMeta.text = year

        if (posterPath.isNotBlank()) {
            val sizePath = if (DeviceOrientationHelper.isTv(this)) "w500" else "w342"
            val url = "https://image.tmdb.org/t/p/$sizePath$posterPath"
            Glide.with(this)
                .load(url)
                .centerCrop()
                .into(binding.imgPoster)
        } else {
            binding.imgPoster.setImageDrawable(null)
        }

        setupServerSpinner()
        setupRecommendedRow()

        if (movieId <= 0) {
            Toast.makeText(this, "Missing movie ID.", Toast.LENGTH_SHORT).show()
            binding.serverSpinner.isEnabled = false
            binding.btnPlay.isEnabled = false
            hideRecommendedRow()
            return
        }

        // Enforce subscription before allowing playback + load recommendations.
        lifecycleScope.launch {
            val ok = SubscriptionGuard.checkAndEnforce(this@MovieDetailActivity)
            if (ok) {
                loadRecommendations()
            } else {
                hideRecommendedRow()
            }
        }

        binding.btnPlay.setOnClickListener {
            val url = MovieConfig.buildMovieUrl(this, movieId)
            if (url.isBlank()) {
                Toast.makeText(this, "Please change server to watch.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }


            launchingWebPlayback = true
            val intent = Intent(this, MovieWebViewActivity::class.java).apply {
                putExtra(MovieWebViewActivity.EXTRA_TITLE, movieTitle)
                putExtra(MovieWebViewActivity.EXTRA_URL, url)
            }
            startActivity(intent)
            // Keep this detail screen in the back stack so BACK returns here.
        }
    }

    override fun onResume() {
        super.onResume()

        launchingWebPlayback = false
        // Keep cache/cookies from accumulating between launches.
        CacheUtils.clearAppCache(this)

        lifecycleScope.launch {
            SubscriptionGuard.checkAndEnforce(this@MovieDetailActivity, showMessage = false)
        }
        refreshServerSelection()
    }

    override fun onStop() {
        // Don't nuke cache when opening the GeckoView player; it can break the return-to-detail flow.
        if (!launchingWebPlayback) {
            lifecycleScope.launch(Dispatchers.IO) {
                CacheUtils.clearAppCache(this@MovieDetailActivity)
            }
        }
        super.onStop()
    }

    private fun setupServerSpinner() {
        val names = resources.getStringArray(R.array.movie_server_names).toList()
        val adapter = ArrayAdapter(this, R.layout.item_spinner_tv, names)
        adapter.setDropDownViewResource(getPhoneAwareDropDownLayout())
        binding.serverSpinner.adapter = adapter

        refreshServerSelection()

        binding.serverSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                Prefs.setMovieServerIndex(this@MovieDetailActivity, position + 1)
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun refreshServerSelection() {
        val names = resources.getStringArray(R.array.movie_server_names)
        val savedIndex = (Prefs.getMovieServerIndex(this) - 1).coerceIn(0, names.lastIndex)
        // false => don't animate/trigger focus jumps
        binding.serverSpinner.setSelection(savedIndex, false)
    }

    private fun setupRecommendedRow() {
        recommendedAdapter = RecommendedMovieAdapter(emptyList()) { movie ->
            openMovieDetail(movie)
        }
        binding.recommendedRecycler.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        binding.recommendedRecycler.adapter = recommendedAdapter

        hideRecommendedRow()
    }

    private fun openMovieDetail(movie: TmdbMovie) {
        val intent = Intent(this, MovieDetailActivity::class.java).apply {
            putExtra(EXTRA_MOVIE_ID, movie.id)
            putExtra(EXTRA_MOVIE_TITLE, movie.title ?: "")
            putExtra(EXTRA_MOVIE_OVERVIEW, movie.overview ?: "")
            putExtra(EXTRA_POSTER_PATH, movie.poster_path ?: "")
            putExtra(EXTRA_RELEASE_DATE, movie.release_date ?: "")
        }
        startActivity(intent)
        finish()
    }

    private fun showRecommendedLoading() {
        binding.recommendedLabel.visibility = View.VISIBLE
        binding.recommendedProgress.visibility = View.VISIBLE
        binding.recommendedRecycler.visibility = View.GONE
    }

    private fun hideRecommendedRow() {
        binding.recommendedLabel.visibility = View.GONE
        binding.recommendedProgress.visibility = View.GONE
        binding.recommendedRecycler.visibility = View.GONE
    }

    private fun showRecommendations(items: List<TmdbMovie>) {
        if (items.isEmpty()) {
            hideRecommendedRow()
            return
        }
        binding.recommendedLabel.visibility = View.VISIBLE
        binding.recommendedProgress.visibility = View.GONE
        binding.recommendedRecycler.visibility = View.VISIBLE
        recommendedAdapter.submitList(items)
    }

    private fun loadRecommendations() {
        val apiKey = MovieConfig.TMDB_API_KEY
        if (apiKey.isBlank()) {
            hideRecommendedRow()
            return
        }

        showRecommendedLoading()

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val response = TmdbClient.api.getMovieRecommendations(movieId, apiKey, page = 1)

                val recs = response.results
                    .filter { it.id != movieId }
                    .filter { it.original_language == null || it.original_language == "en" }
                    .distinctBy { it.id }
                    .take(12)

                withContext(Dispatchers.Main) {
                    showRecommendations(recs)
                }
            } catch (e: Exception) {
                e.printStackTrace()
                withContext(Dispatchers.Main) {
                    hideRecommendedRow()
                }
            }
        }
    }

    private fun getPhoneAwareDropDownLayout(): Int {
        return if (DeviceOrientationHelper.isTv(this)) {
            R.layout.item_spinner_tv_dropdown
        } else {
            R.layout.item_spinner_phone_dropdown
        }
    }

    companion object {
        const val EXTRA_MOVIE_ID = "extra_movie_id"
        const val EXTRA_MOVIE_TITLE = "extra_movie_title"
        const val EXTRA_MOVIE_OVERVIEW = "extra_movie_overview"
        const val EXTRA_POSTER_PATH = "extra_poster_path"
        const val EXTRA_RELEASE_DATE = "extra_release_date"
    }
}
