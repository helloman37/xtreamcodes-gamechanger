package com.iptvnetworking.tvapp.util

import android.app.Activity
import android.app.UiModeManager
import android.content.Context
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration

object DeviceOrientationHelper {

    fun isTv(context: Context): Boolean {
        val uiModeManager = context.getSystemService(Context.UI_MODE_SERVICE) as? UiModeManager
        if (uiModeManager != null) {
            if (uiModeManager.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION) {
                return true
            }
        }

        val pm = context.packageManager
        return pm.hasSystemFeature(PackageManager.FEATURE_LEANBACK) ||
            pm.hasSystemFeature("android.software.leanback")
    }

    /**
     * Treat devices with smallestScreenWidthDp >= 600 as tablets.
     * This keeps phone-specific orientation flows intact while allowing
     * us to enforce a consistent landscape experience on tablets.
     */
    fun isTablet(context: Context): Boolean {
        return context.resources.configuration.smallestScreenWidthDp >= 600
    }

    fun applyPhoneLoginPortrait(activity: Activity) {
        if (isTv(activity)) return

        activity.requestedOrientation = if (isTablet(activity)) {
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        } else {
            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        }
    }

    fun applyPhonePostLoginPortrait(activity: Activity) {
        if (isTv(activity)) return

        activity.requestedOrientation = if (isTablet(activity)) {
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        } else {
            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        }
    }

    fun applyPhonePostLoginLandscape(activity: Activity) {
        if (isTv(activity)) return

        activity.requestedOrientation = if (isTablet(activity)) {
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        } else {
            ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        }
    }
}
