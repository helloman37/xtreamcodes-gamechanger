package com.iptvnetworking.tvapp.epgdb

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction

@Dao
interface EpgDao {

    @Query("SELECT * FROM epg_programs ORDER BY channelName ASC, startMillis ASC")
    suspend fun getAllPrograms(): List<EpgProgramEntity>

    @Query("SELECT * FROM epg_programs WHERE channelName = :channelName ORDER BY startMillis ASC")
    suspend fun getProgramsForChannel(channelName: String): List<EpgProgramEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPrograms(programs: List<EpgProgramEntity>)

    @Query("DELETE FROM epg_programs")
    suspend fun clearPrograms()

    @Query("SELECT * FROM epg_meta WHERE `key` = :key LIMIT 1")
    suspend fun getMeta(key: String = "epg"): EpgMetaEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMeta(meta: EpgMetaEntity)

    @Query("DELETE FROM epg_meta WHERE `key` = :key")
    suspend fun clearMeta(key: String = "epg")

    @Transaction
    suspend fun replaceAll(programs: List<EpgProgramEntity>, updatedMillis: Long) {
        clearPrograms()
        insertPrograms(programs)
        clearMeta("epg")
        upsertMeta(EpgMetaEntity(key = "epg", lastUpdatedMillis = updatedMillis))
    }
}
