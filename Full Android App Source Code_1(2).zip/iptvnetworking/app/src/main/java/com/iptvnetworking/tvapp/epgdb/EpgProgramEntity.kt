package com.iptvnetworking.tvapp.epgdb

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Stores EPG programmes mapped to the M3U channel name.
 * We keep channelId for reference/debug, but channelName is the display key used by the APK.
 */
@Entity(
    tableName = "epg_programs",
    indices = [
        Index(value = ["channelName"]),
        Index(value = ["startMillis"]),
        Index(value = ["channelName", "startMillis"])
    ]
)
data class EpgProgramEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val channelName: String,
    val channelId: String,
    val title: String,
    val description: String?,
    val startMillis: Long,
    val endMillis: Long?
)
