package com.iptvnetworking.tvapp.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.iptvnetworking.tvapp.R
import com.iptvnetworking.tvapp.databinding.ItemEpgRowBinding
import com.iptvnetworking.tvapp.model.Channel
import com.iptvnetworking.tvapp.model.EpgProgram
import java.time.Duration
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

class EpgRowAdapter(
    private var channels: List<Channel>,
    private val onClick: (Channel) -> Unit,
    private val onFocused: (Channel) -> Unit
) : RecyclerView.Adapter<EpgRowAdapter.EpgViewHolder>() {

    private var epgByChannel: Map<String, List<EpgProgram>> = emptyMap()
    private val timeFormatter: DateTimeFormatter = DateTimeFormatter.ofPattern("h:mm a")

    class EpgViewHolder(val binding: ItemEpgRowBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EpgViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = ItemEpgRowBinding.inflate(inflater, parent, false)
        return EpgViewHolder(binding)
    }

    override fun onBindViewHolder(holder: EpgViewHolder, position: Int) {
        val channel = channels[position]

        // Channel name
        holder.binding.epgChannelName.text = channel.name

        // Channel logo (small, inline)
        val logoView = holder.binding.epgLogo
        val logoUrl = channel.logoUrl
        if (logoUrl.isNullOrBlank()) {
            logoView.visibility = View.GONE
        } else {
            logoView.visibility = View.VISIBLE
            Glide.with(logoView.context)
                .load(logoUrl)
                .centerInside()
                .into(logoView)
        }

        // EPG cells (current + next 3 programmes where available)
        val programmesForChannel = epgByChannel[channel.name].orEmpty()
        val window = selectProgrammeWindow(programmesForChannel)
        val now = ZonedDateTime.now()

        val cells = listOf(
            holder.binding.epgCell1,
            holder.binding.epgCell2,
            holder.binding.epgCell3,
            holder.binding.epgCell4
        )

        for (i in cells.indices) {
            val programme = window.getOrNull(i)
            val cellView = cells[i]

            if (programme == null) {
                cellView.text = ""
                cellView.setBackgroundResource(R.drawable.bg_epg_cell_default)
                continue
            }

            val isCurrent = isCurrentProgramme(programme, now)
            cellView.text = formatProgrammeCell(programme, isCurrent)

            when {
                isCurrent -> cellView.setBackgroundResource(R.drawable.bg_epg_cell_now)
                else -> cellView.setBackgroundResource(R.drawable.bg_epg_cell_next)
            }
        }

        // Progress bar on the first (current) cell only
        val firstProgramme = window.getOrNull(0)
        val progressBar = holder.binding.epgCell1Progress
        if (firstProgramme != null && isCurrentProgramme(firstProgramme, now)) {
            val pct = progressPercent(firstProgramme, now)
            if (pct != null) {
                progressBar.visibility = View.VISIBLE
                progressBar.progress = pct
            } else {
                progressBar.visibility = View.GONE
            }
        } else {
            progressBar.visibility = View.GONE
        }

        // Hide favorite icon on EPG rows (no star in guide)
        holder.binding.favoriteIcon.visibility = View.GONE

        holder.binding.root.setOnClickListener {
            onClick(channel)
        }

        holder.binding.root.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                onFocused(channel)
            }
        }
    }

    private fun selectProgrammeWindow(programmes: List<EpgProgram>): List<EpgProgram> {
        if (programmes.isEmpty()) return emptyList()
        val sorted = programmes.sortedBy { it.start }
        val now = ZonedDateTime.now()
        val currentIndex = sorted.indexOfLast { it.start.isBefore(now) || it.start.isEqual(now) }
        return if (currentIndex == -1) {
            sorted.take(4)
        } else {
            sorted.drop(currentIndex).take(4)
        }
    }

    private fun isCurrentProgramme(programme: EpgProgram, now: ZonedDateTime): Boolean {
        val end = programme.end ?: return false
        return (programme.start.isBefore(now) || programme.start.isEqual(now)) && end.isAfter(now)
    }

    private fun progressPercent(programme: EpgProgram, now: ZonedDateTime): Int? {
        val end = programme.end ?: return null
        val total = Duration.between(programme.start, end).toMillis()
        if (total <= 0) return null
        val elapsed = Duration.between(programme.start, now).toMillis().coerceAtLeast(0)
        val pct = ((elapsed.toDouble() / total.toDouble()) * 100.0).toInt()
        return pct.coerceIn(0, 100)
    }

    private fun formatProgrammeCell(programme: EpgProgram, isCurrent: Boolean): String {
        val startTime = programme.start.toLocalTime().format(timeFormatter)
        val endTime = programme.end?.toLocalTime()?.format(timeFormatter)

        val timePart = if (!endTime.isNullOrBlank()) {
            "$startTime–$endTime"
        } else {
            startTime
        }

        return if (isCurrent) {
            "NOW  $timePart\n${programme.title}"
        } else {
            "$timePart\n${programme.title}"
        }
    }

    override fun getItemCount(): Int = channels.size

    fun updateData(newList: List<Channel>) {
        channels = newList
        notifyDataSetChanged()
    }

    fun updateEpg(epg: Map<String, List<EpgProgram>>) {
        epgByChannel = epg
        notifyDataSetChanged()
    }
}
