package com.iptvnetworking.tvapp.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.iptvnetworking.tvapp.databinding.ItemRecommendedTvShowBinding
import com.iptvnetworking.tvapp.movies.TmdbTvShow
import com.iptvnetworking.tvapp.util.DeviceOrientationHelper

class RecommendedTvShowAdapter(
    private var items: List<TmdbTvShow>,
    private val onClick: (TmdbTvShow) -> Unit
) : RecyclerView.Adapter<RecommendedTvShowAdapter.RecommendedTvShowViewHolder>() {

    inner class RecommendedTvShowViewHolder(val binding: ItemRecommendedTvShowBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecommendedTvShowViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = ItemRecommendedTvShowBinding.inflate(inflater, parent, false)
        return RecommendedTvShowViewHolder(binding)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: RecommendedTvShowViewHolder, position: Int) {
        val show = items[position]
        val ctx = holder.binding.root.context

        holder.binding.recTitle.text = show.name ?: ""

        val posterPath = show.poster_path
        if (!posterPath.isNullOrBlank()) {
            val sizePath = if (DeviceOrientationHelper.isTv(ctx)) "w342" else "w185"
            val url = "https://image.tmdb.org/t/p/$sizePath$posterPath"
            Glide.with(ctx)
                .load(url)
                .centerCrop()
                .into(holder.binding.recPoster)
        } else {
            holder.binding.recPoster.setImageDrawable(null)
        }

        val isTv = DeviceOrientationHelper.isTv(ctx)
        holder.binding.root.isFocusable = isTv
        holder.binding.root.isFocusableInTouchMode = isTv

        holder.binding.root.setOnClickListener {
            onClick(show)
        }
    }

    fun submitList(newItems: List<TmdbTvShow>) {
        items = newItems
        notifyDataSetChanged()
    }
}
