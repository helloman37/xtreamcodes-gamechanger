package com.iptvnetworking.tvapp.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.iptvnetworking.tvapp.util.DeviceOrientationHelper
import com.iptvnetworking.tvapp.databinding.ActivitySettingsBinding
import com.iptvnetworking.tvapp.prefs.Prefs

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        DeviceOrientationHelper.applyPhonePostLoginLandscape(this)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val existing = Prefs.getEpgUrl(this) ?: ""
        binding.epgUrlInput.setText(existing)

        binding.saveButton.setOnClickListener {
            val url = binding.epgUrlInput.text.toString().trim()
            Prefs.saveEpgUrl(this, url.ifBlank { null })
            Toast.makeText(this, "EPG URL saved", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
