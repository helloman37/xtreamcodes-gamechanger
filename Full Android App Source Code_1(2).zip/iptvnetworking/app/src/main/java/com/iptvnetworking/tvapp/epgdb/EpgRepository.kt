package com.iptvnetworking.tvapp.epgdb

import com.iptvnetworking.tvapp.model.EpgProgram
import java.time.Instant
import java.time.ZoneId
import java.util.concurrent.TimeUnit

class EpgRepository(private val dao: EpgDao) {

    private val zone: ZoneId = ZoneId.systemDefault()

    suspend fun isStale(ttlMinutes: Long): Boolean {
        val meta = dao.getMeta("epg") ?: return true
        val ageMillis = System.currentTimeMillis() - meta.lastUpdatedMillis
        val ttlMillis = TimeUnit.MINUTES.toMillis(ttlMinutes)
        return ageMillis < 0 || ageMillis > ttlMillis
    }

    suspend fun getEpgByChannelName(): Map<String, List<EpgProgram>> {
        val entities = dao.getAllPrograms()
        if (entities.isEmpty()) return emptyMap()

        return entities
            .groupBy { it.channelName }
            .mapValues { (_, list) ->
                list
                    .sortedBy { it.startMillis }
                    .map { it.toModel(zone) }
            }
    }

    suspend fun replaceAll(epgMap: Map<String, List<EpgProgram>>) {
        if (epgMap.isEmpty()) return

        val flattened = epgMap.flatMap { (channelName, programs) ->
            programs.map { p ->
                EpgProgramEntity(
                    channelName = channelName,
                    channelId = p.channelId,
                    title = p.title,
                    description = p.description,
                    startMillis = p.start.toInstant().toEpochMilli(),
                    endMillis = p.end?.toInstant()?.toEpochMilli()
                )
            }
        }

        dao.replaceAll(flattened, System.currentTimeMillis())
    }
}

private fun EpgProgramEntity.toModel(zone: ZoneId): EpgProgram {
    val start = Instant.ofEpochMilli(startMillis).atZone(zone)
    val end = endMillis?.let { Instant.ofEpochMilli(it).atZone(zone) }

    return EpgProgram(
        channelId = channelId,
        title = title,
        start = start,
        end = end,
        description = description
    )
}
