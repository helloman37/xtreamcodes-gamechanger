package com.iptvnetworking.tvapp.model

import com.google.gson.annotations.SerializedName

data class AccountInfoResponse(
    @SerializedName("user_info") val userInfo: UserInfo?
)

data class UserInfo(
    @SerializedName("username") val username: String?,
    @SerializedName("status") val status: String?,
    @SerializedName("exp_date") val expDate: String?
)
