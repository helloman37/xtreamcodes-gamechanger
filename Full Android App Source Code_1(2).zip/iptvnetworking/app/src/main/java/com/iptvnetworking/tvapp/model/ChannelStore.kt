package com.iptvnetworking.tvapp.model

object ChannelStore {
    var channels: List<Channel> = emptyList()
    var currentIndex: Int = 0
}
