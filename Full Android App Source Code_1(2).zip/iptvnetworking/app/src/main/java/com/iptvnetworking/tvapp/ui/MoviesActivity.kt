package com.iptvnetworking.tvapp.ui

import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import android.view.inputmethod.EditorInfo
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.iptvnetworking.tvapp.util.DeviceOrientationHelper
import com.iptvnetworking.tvapp.util.CacheUtils
import com.iptvnetworking.tvapp.util.SubscriptionGuard
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.iptvnetworking.tvapp.databinding.ActivityMoviesBinding
import com.iptvnetworking.tvapp.movies.MovieConfig
import com.iptvnetworking.tvapp.movies.TmdbClient
import com.iptvnetworking.tvapp.movies.TmdbMovie
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
// Main Movies screen no longer needs a server selector (server is chosen on the detail page).

class MoviesActivity : AppCompatActivity() {

    // Mirror the TV Shows screen behaviour
    // Keep discover light; search can dig a little deeper.
    private val maxTrendingPages = 2
    private val maxSearchPages = 5
    private val recommendedMaxItems = 40

    private lateinit var binding: ActivityMoviesBinding
    private lateinit var adapter: MovieAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Clear cache every time Movies is entered.
        CacheUtils.clearAppCache(this)

        // Phone UX: Movies should be locked to landscape for better viewing.
        DeviceOrientationHelper.applyPhonePostLoginLandscape(this)
        binding = ActivityMoviesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = MovieAdapter(emptyList()) { movie ->
            openMovie(movie)
        }
        val spanCount = if (DeviceOrientationHelper.isTv(this)) 5 else 2
        binding.moviesRecyclerView.layoutManager = GridLayoutManager(this, spanCount)
        binding.moviesRecyclerView.adapter = adapter

        binding.titleText.text = "Movies"

        // Validate subscription when entering Movies.
        lifecycleScope.launch {
            val ok = SubscriptionGuard.checkAndEnforce(this@MoviesActivity)
            if (ok) {
                loadTrendingMovies()
            }
        }

        // DPAD / keyboard friendly search
        binding.searchButton.setOnClickListener {
            performSearch()
        }

        binding.searchInput.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH ||
                actionId == EditorInfo.IME_ACTION_DONE ||
                (event?.keyCode == KeyEvent.KEYCODE_DPAD_CENTER && event.action == KeyEvent.ACTION_DOWN)
            ) {
                performSearch()
                true
            } else {
                false
            }
        }

        // Initial load: show TMDB trending movies (up to 40 mixed years).
    }
    override fun onResume() {
        super.onResume()
        CacheUtils.clearAppCache(this)

        // Re-validate account on returning to this screen.
        lifecycleScope.launch {
            SubscriptionGuard.checkAndEnforce(this@MoviesActivity, showMessage = false)
        }
    }

    override fun onStop() {
        // Clear cache whenever leaving Movies for another section.
        CacheUtils.clearAppCache(this)
        super.onStop()
    }


    private fun performSearch() {
    val query = binding.searchInput.text?.toString()?.trim().orEmpty()
    hideKeyboard()

    if (query.isEmpty()) {
        // No query: show trending grid (mixed from current year backwards)
        binding.errorText.visibility = View.GONE
        binding.errorText.text = ""
        loadTrendingMovies()
    } else {
        binding.errorText.visibility = View.GONE
        binding.errorText.text = ""
        searchMovies(query)
    }
}

    private fun loadTrendingMovies() {
        val apiKey = MovieConfig.TMDB_API_KEY
        if (apiKey.isBlank()) {
            binding.errorText.visibility = View.VISIBLE
            binding.errorText.text = "Edit MovieConfig.TMDB_API_KEY with your TMDB key."
            Toast.makeText(this, "Set TMDB_API_KEY in MovieConfig first.", Toast.LENGTH_LONG).show()
            return
        }

        binding.errorText.visibility = View.GONE
        binding.errorText.text = ""
        binding.progressBar.visibility = View.VISIBLE

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val allMovies = mutableListOf<TmdbMovie>()
                var page = 1
                val maxPages = maxTrendingPages

                while (page <= maxPages) {
                    val response = TmdbClient.api.trendingMovies(
                        timeWindow = "day",
                        apiKey = apiKey,
                        page = page
                    )
                    val results = response.results
                    if (results.isEmpty()) break
                    allMovies.addAll(results)
                    page++
                }

                val movies = allMovies
                    .filter { it.original_language == null || it.original_language == "en" }
                    .filter { movie ->
                        val year = movie.release_date?.take(4)?.toIntOrNull() ?: 0
                        year in 1900..2025
                    }
                    .distinctBy { it.id }
                    .take(recommendedMaxItems)

                withContext(Dispatchers.Main) {
                    binding.progressBar.visibility = View.GONE
                    if (movies.isEmpty()) {
                        binding.errorText.visibility = View.VISIBLE
                        binding.errorText.text = "TMDB returned no trending movies. Check API key."
                    } else {
                        binding.errorText.visibility = View.GONE
                        binding.errorText.text = ""
                        adapter.submitList(movies)
                        binding.moviesRecyclerView.post {
                            val first = binding.moviesRecyclerView.getChildAt(0)
                            if (DeviceOrientationHelper.isTv(this@MoviesActivity)) {
                                first?.requestFocus()
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                withContext(Dispatchers.Main) {
                    binding.progressBar.visibility = View.GONE
                    binding.errorText.visibility = View.VISIBLE
                    binding.errorText.text =
                        "Failed to load trending movies: ${e.localizedMessage ?: "Unknown error"}"
                    Toast.makeText(
                        this@MoviesActivity,
                        "Failed to load trending movies: ${e.localizedMessage ?: "Unknown error"}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }
    private fun searchMovies(query: String) {
        val apiKey = MovieConfig.TMDB_API_KEY
        if (apiKey.isBlank()) {
            binding.errorText.visibility = View.VISIBLE
            binding.errorText.text = "Edit MovieConfig.TMDB_API_KEY with your TMDB key."
            Toast.makeText(this, "Set TMDB_API_KEY in MovieConfig first.", Toast.LENGTH_LONG).show()
            return
        }

        binding.errorText.visibility = View.GONE
        binding.errorText.text = ""
        binding.progressBar.visibility = View.VISIBLE

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val allMovies = mutableListOf<TmdbMovie>()
                var page = 1
                val maxPages = maxSearchPages

                while (page <= maxPages) {
                    val response = TmdbClient.api.searchMovies(
                        apiKey = apiKey,
                        query = query,
                        year = null,
                        region = MovieConfig.DEFAULT_REGION,
                        originCountry = "US",
                        includeAdult = false,
                        originalLanguage = "en",
                        page = page
                    )
                    val results = response.results
                    if (results.isEmpty()) break
                    allMovies.addAll(results)
                    page++
                }

                
val movies = allMovies
    .filter { it.original_language == null || it.original_language == "en" }
    .sortedWith(
        compareByDescending<TmdbMovie> {
            it.release_date?.take(4)?.toIntOrNull() ?: 0
        }.thenByDescending {
            it.title ?: ""
        }
    )

                withContext(Dispatchers.Main) {
                    binding.progressBar.visibility = View.GONE
                    if (movies.isEmpty()) {
                        binding.errorText.visibility = View.VISIBLE
                        binding.errorText.text = "No movies found for \"$query\"."
                    } else {
                        binding.errorText.visibility = View.GONE
                        binding.errorText.text = ""
                        adapter.submitList(movies)
                        binding.moviesRecyclerView.post {
                            val first = binding.moviesRecyclerView.getChildAt(0)
                            if (DeviceOrientationHelper.isTv(this@MoviesActivity)) {
                            first?.requestFocus()
                        }
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                withContext(Dispatchers.Main) {
                    binding.progressBar.visibility = View.GONE
                    binding.errorText.visibility = View.VISIBLE
                    binding.errorText.text =
                        "Failed to search movies: ${e.localizedMessage ?: "Unknown error"}"
                    Toast.makeText(
                        this@MoviesActivity,
                        "Failed to search movies: ${e.localizedMessage ?: "Unknown error"}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    private fun openMovie(movie: TmdbMovie) {
        // Open a dedicated detail screen (poster + details + server dropdown + Play Now)
        // so users can switch servers without backing out to the Movies grid.
        val intent = Intent(this, MovieDetailActivity::class.java).apply {
            putExtra(MovieDetailActivity.EXTRA_MOVIE_ID, movie.id)
            putExtra(MovieDetailActivity.EXTRA_MOVIE_TITLE, movie.title ?: "")
            putExtra(MovieDetailActivity.EXTRA_MOVIE_OVERVIEW, movie.overview ?: "")
            putExtra(MovieDetailActivity.EXTRA_POSTER_PATH, movie.poster_path ?: "")
            putExtra(MovieDetailActivity.EXTRA_RELEASE_DATE, movie.release_date ?: "")
        }
        startActivity(intent)
    }


    

    private fun hideKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as? android.view.inputmethod.InputMethodManager
        currentFocus?.windowToken?.let { token ->
            imm?.hideSoftInputFromWindow(token, 0)
        }
    }
}
// SENTINEL_TEST
