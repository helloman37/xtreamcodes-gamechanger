package com.iptvnetworking.tvapp.channeldb

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction

@Dao
interface ChannelsDao {

    @Query("SELECT * FROM channels ORDER BY orderIndex ASC")
    suspend fun getAllChannels(): List<ChannelEntity>

    @Query("DELETE FROM channels")
    suspend fun clearChannels()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChannels(channels: List<ChannelEntity>)

    @Query("SELECT * FROM channels_meta WHERE `key` = :key LIMIT 1")
    suspend fun getMeta(key: String = "channels"): ChannelsMetaEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMeta(meta: ChannelsMetaEntity)

    @Query("DELETE FROM channels_meta WHERE `key` = :key")
    suspend fun clearMeta(key: String = "channels")

    @Transaction
    suspend fun replaceAll(channels: List<ChannelEntity>, updatedMillis: Long) {
        clearChannels()
        insertChannels(channels)
        clearMeta("channels")
        upsertMeta(ChannelsMetaEntity(key = "channels", lastUpdatedMillis = updatedMillis))
    }
}
