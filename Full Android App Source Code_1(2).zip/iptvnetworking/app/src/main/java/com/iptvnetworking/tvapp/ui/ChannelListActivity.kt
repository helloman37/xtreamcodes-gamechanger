package com.iptvnetworking.tvapp.ui

import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import android.view.inputmethod.EditorInfo
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.iptvnetworking.tvapp.util.DeviceOrientationHelper
import com.iptvnetworking.tvapp.util.CacheUtils
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.iptvnetworking.tvapp.databinding.ActivityChannelListBinding
import com.iptvnetworking.tvapp.model.Channel
import com.iptvnetworking.tvapp.model.ChannelStore
import com.iptvnetworking.tvapp.network.ApiClient
import com.iptvnetworking.tvapp.prefs.Prefs
import com.iptvnetworking.tvapp.util.StreamUrlUtils
import com.iptvnetworking.tvapp.util.UserAgentUtils
import com.iptvnetworking.tvapp.util.M3UParser
import com.iptvnetworking.tvapp.util.SubscriptionGuard
import kotlinx.coroutines.Dispatchers
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import android.net.Uri
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.iptvnetworking.tvapp.channeldb.ChannelsRepository
import android.view.View
import androidx.media3.common.Player
import androidx.media3.common.PlaybackException
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout

class ChannelListActivity : AppCompatActivity() {

    private lateinit var binding: ActivityChannelListBinding

    private val allChannels = mutableListOf<Channel>()
    private var filteredChannels: List<Channel> = emptyList()
    private var currentCategory: String = "All"
    private var favoritesOnly: Boolean = false
    private var currentChannelSearch: String = ""

    private lateinit var categoryAdapter: CategoryAdapter
    private var previewPlayer: ExoPlayer? = null
    // LibVLC-based fallback for the small hero preview
    private var previewLibVlc: LibVLC? = null
    private var previewVlcPlayer: MediaPlayer? = null
    private var currentPreviewUrl: String? = null
    private var launchingPlayer: Boolean = false
    private lateinit var previewHttpFactory: DefaultHttpDataSource.Factory
    private lateinit var channelAdapter: ChannelAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        DeviceOrientationHelper.applyPhonePostLoginLandscape(this)
        binding = ActivityChannelListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Lightweight cache cleanup in background (won't block UI)
        lifecycleScope.launch(Dispatchers.IO) {
            CacheUtils.clearAppCache(this@ChannelListActivity)
        }


binding.channelSearchButton.setOnClickListener {
    performChannelSearch()
}

binding.channelSearchInput.setOnEditorActionListener { _, actionId, event ->
    if (actionId == EditorInfo.IME_ACTION_SEARCH ||
        actionId == EditorInfo.IME_ACTION_DONE ||
        (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
    ) {
        performChannelSearch()
        true
    } else {
        false
    }
}

        favoritesOnly = false

        previewHttpFactory = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)

        val previewMediaSourceFactory = DefaultMediaSourceFactory(this)
            .setDataSourceFactory(previewHttpFactory)

        previewPlayer = ExoPlayer.Builder(this)
            .setMediaSourceFactory(previewMediaSourceFactory)
            .build().also { player ->
                binding.previewPlayerView.useController = false
                binding.previewPlayerView.player = player

                // If Exo fails for preview, fall back to LibVLC on the same URL.
                player.addListener(object : Player.Listener {
                    override fun onPlayerError(error: PlaybackException) {
                        val url = currentPreviewUrl
                        if (url != null) {
                            startPreviewVlc(url)
                        }
                    }
                })
            }

        // Left nav buttons removed from Live TV layout.
        // Search and Settings will be accessed from the Home screen instead.
        // Channel grid: HBO-style cards in rows
        val channelSpanCount = if (DeviceOrientationHelper.isTv(this)) 5 else 4
        binding.epgRecycler.layoutManager =
            GridLayoutManager(this, channelSpanCount, GridLayoutManager.VERTICAL, false)
        channelAdapter = ChannelAdapter(
            emptyList(),
            onClick = { channel -> openChannel(channel) },
            onFocused = { channel -> updateProgramInfo(channel) }
        )
        binding.epgRecycler.adapter = channelAdapter

        // Category / group list
        binding.categoryRecycler.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)

        val username = Prefs.getUsername(this)
        val password = Prefs.getPassword(this)

        // If credentials/playlist changed since the last time we built the channel cache, force refresh.
        val currentFingerprint = "${Prefs.getUsername(this)}|${Prefs.getPassword(this)}"
        val cachedFingerprint = Prefs.getChannelsCacheFingerprint(this) ?: ""
        val forceRefresh = cachedFingerprint.isEmpty() || cachedFingerprint != currentFingerprint


        if (username.isNullOrEmpty() || password.isNullOrEmpty()) {
            finish()
            return
        }

        val user: String = username
        val pass: String = password

        // Preload from in-memory store if available (instant fallback)
        if (ChannelStore.channels.isNotEmpty()) {
            allChannels.clear()
            allChannels.addAll(ChannelStore.channels)
            setupCategories()
            applyFilters()
            updateProgramInfoFromFirst()
        }


        val channelsRepo = ChannelsRepository(this@ChannelListActivity)

        lifecycleScope.launch {
            try {
                val cached = withContext(Dispatchers.IO) { channelsRepo.getCachedChannels() }
                val stale = withContext(Dispatchers.IO) { channelsRepo.isStale(12) }

                if (forceRefresh) {
                    withContext(Dispatchers.IO) { channelsRepo.clearAll() }
                }
                // If we have fresh cache, show it immediately (fast UI), but still check the server
                // so playlists update automatically without waiting on TTL.
                if (cached.isNotEmpty() && !stale && !forceRefresh) {
                ChannelStore.channels = cached
                                    allChannels.clear()
                                    allChannels.addAll(cached)
                                    setupCategories()
                                    applyFilters()
                                    updateProgramInfoFromFirst()
                }
// Otherwise hit the server (first install, empty cache, or stale)
                val username = Prefs.getUsername(this@ChannelListActivity)
                val password = Prefs.getPassword(this@ChannelListActivity)

                if (username.isNullOrEmpty() || password.isNullOrEmpty()) {
                    Toast.makeText(this@ChannelListActivity, "Please log in again", Toast.LENGTH_LONG).show()
                    val intent = Intent(this@ChannelListActivity, LoginActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    startActivity(intent)
                    return@launch
                }

                val channels = withContext(Dispatchers.IO) {
                    val deviceId = Prefs.getOrCreateDeviceId(this@ChannelListActivity)
                    val body = ApiClient.api.getChannels(username, password, deviceId, type = "m3u")
                    val text = body.string()
                    M3UParser.parse(text)
                }


                // If the server playlist differs from what we were showing, replace cache + refresh UI.
                val cachedSig = cached.joinToString("|") { it.url }.hashCode()
                val newSig = channels.joinToString("|") { it.url }.hashCode()

                if (channels.isNotEmpty() && (forceRefresh || cachedSig != newSig)) {
                    withContext(Dispatchers.IO) { channelsRepo.saveChannels(channels) }
                    Prefs.setChannelsCacheFingerprint(this@ChannelListActivity, currentFingerprint)

                    ChannelStore.channels = channels
                    allChannels.clear()
                    allChannels.addAll(channels)
                    setupCategories()
                    applyFilters()
                    updateProgramInfoFromFirst()
                }

                // If server returns empty but we had some cache, fall back to cache
                if (channels.isEmpty() && cached.isNotEmpty()) {
                    ChannelStore.channels = cached
                    allChannels.clear()
                    allChannels.addAll(cached)
                    setupCategories()
                    applyFilters()
                    updateProgramInfoFromFirst()
                    return@launch
                }

                if (channels.isEmpty()) {
                    // IMPORTANT: don't wipe saved creds just because the playlist came back empty.
                    // get.php can return text errors, HTML, or even redirect to a "fail video" depending
                    // on panel config. Confirm the account state via player_api.php first.
                    val check = SubscriptionGuard.checkAccount(
                        this@ChannelListActivity,
                        username,
                        password
                    )

                    if (!check.isValid && check.shouldClear) {
                        Prefs.clear(this@ChannelListActivity)

                        val msg = when {
                            check.isExpired -> "Subscription expired. Please log in again."
                            check.isInactive -> "Account inactive. Please contact support."
                            else -> "Account not active. Please log in again."
                        }

                        Toast.makeText(this@ChannelListActivity, msg, Toast.LENGTH_LONG).show()

                        val intent = Intent(this@ChannelListActivity, LoginActivity::class.java)
                        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                        startActivity(intent)
                        return@launch
                    }

                    // Not expired/inactive: treat as transient fetch/parse issue and keep user logged in.
                    Toast.makeText(
                        this@ChannelListActivity,
                        "Couldn't load your playlist right now. Try again.",
                        Toast.LENGTH_LONG
                    ).show()
                    return@launch
                }

                withContext(Dispatchers.IO) { channelsRepo.saveChannels(channels) }

                ChannelStore.channels = channels
                allChannels.clear()
                allChannels.addAll(channels)
                setupCategories()
                applyFilters()
                updateProgramInfoFromFirst()

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
private fun setupCategories() {
        val groups = allChannels.mapNotNull { it.group?.trim() }
            .filter { it.isNotEmpty() }
            .distinct()

        val list = mutableListOf<String>()
        list.add("All")
        list.addAll(groups)

        categoryAdapter = CategoryAdapter(list) { selected ->
            currentCategory = selected
            applyFilters()
        }
        binding.categoryRecycler.adapter = categoryAdapter

        // Ensure search field does not steal initial focus
        binding.channelSearchInput.clearFocus()

        // Default focus on the first category ("All") for DPAD users
        binding.categoryRecycler.post {
            binding.categoryRecycler.scrollToPosition(0)
            val first = binding.categoryRecycler.getChildAt(0)
            if (first != null) {
                if (DeviceOrientationHelper.isTv(this@ChannelListActivity)) {
                first.requestFocus()
            }
            } else {
                if (DeviceOrientationHelper.isTv(this@ChannelListActivity)) {
                binding.categoryRecycler.requestFocus()
            }
            }
        }
    }


private fun performChannelSearch() {
    val query = binding.channelSearchInput.text?.toString()?.trim().orEmpty()
    currentChannelSearch = query
    hideKeyboard()
    applyFilters()
}

private fun hideKeyboard() {
    val imm = getSystemService(INPUT_METHOD_SERVICE) as? android.view.inputmethod.InputMethodManager
    currentFocus?.windowToken?.let { token ->
        imm?.hideSoftInputFromWindow(token, 0)
    }
}

    private fun applyFilters() {
        val base = if (currentCategory == "All") {
            allChannels
        } else {
            allChannels.filter { it.group.equals(currentCategory, ignoreCase = true) }
        }

        var result = if (favoritesOnly) {
            val favs = Prefs.getFavoriteUrls(this)
            base.filter { favs.contains(it.url) }
        } else {
            base
        }

        val searchQuery = currentChannelSearch.trim()
        if (searchQuery.isNotEmpty()) {
            val q = searchQuery.lowercase()
            result = result.filter { it.name.contains(q, ignoreCase = true) }
        }

        filteredChannels = result

        channelAdapter.updateData(filteredChannels)
        updateProgramInfoFromFirst()
    }

    private fun updateProgramInfoFromFirst() {
        val first = filteredChannels.firstOrNull() ?: allChannels.firstOrNull()
        if (first != null) {
            updateProgramInfo(first)
        } else {
            binding.currentProgramTitle.text = "Live TV"
            binding.currentProgramTime.text = ""
            binding.currentProgramDescription.text = "No channels available"
        }
    }

    private fun updateProgramInfo(channel: Channel) {
        binding.currentProgramTitle.text = channel.name
        binding.currentProgramTime.text = "Live"
        binding.currentProgramDescription.text = channel.group ?: ""
        playPreview(channel)
    }

    
    private fun stopPreviewPlayback() {
        // Stop Exo preview
        try {
            previewPlayer?.playWhenReady = false
            previewPlayer?.stop()
            previewPlayer?.clearMediaItems()
        } catch (_: Throwable) {
        }

        // Stop VLC preview if it was active
        try {
            previewVlcPlayer?.stop()
            previewVlcPlayer?.detachViews()
        } catch (_: Throwable) {
        }

        // Reset preview UI to Exo surface by default
        try {
            binding.previewVlcLayout.visibility = View.GONE
            binding.previewPlayerView.visibility = View.VISIBLE
        } catch (_: Throwable) {
        }
    }

private fun playPreview(channel: Channel) {
        val deviceId = Prefs.getOrCreateDeviceId(applicationContext)
        val rawUrl = StreamUrlUtils.withDeviceId(channel.url, deviceId)
        if (rawUrl.isEmpty()) return

        // Stop any existing preview playback before switching channels
        stopPreviewPlayback()

        currentPreviewUrl = rawUrl

        val player = previewPlayer ?: return

        val parts = StreamUrlUtils.splitUrlAndHeaders(rawUrl)
        val headers = parts.headers

        // Default to Exo preview surface; hide VLC layout, show Exo surface
        binding.previewPlayerView.visibility = View.VISIBLE
        try {
            binding.previewVlcLayout.visibility = View.GONE
        } catch (_: Throwable) {
        }

        // Align preview HTTP fingerprint + headers with main playback.
        val uaFromPlaylist = headers.entries.firstOrNull { it.key.equals("User-Agent", ignoreCase = true) }?.value
        val ua = uaFromPlaylist ?: UserAgentUtils.build(this)
        val requestProps = headers.filterKeys { !it.equals("User-Agent", ignoreCase = true) }

        try {
            previewHttpFactory
                .setUserAgent(ua)
                .setAllowCrossProtocolRedirects(true)

            if (requestProps.isNotEmpty()) {
                previewHttpFactory.setDefaultRequestProperties(requestProps)
            } else {
                previewHttpFactory.setDefaultRequestProperties(emptyMap())
            }

            val mediaItem = MediaItem.fromUri(Uri.parse(parts.url))
            player.setMediaItem(mediaItem)
            player.prepare()
            player.playWhenReady = true
        } catch (e: Exception) {
            e.printStackTrace()
            // If Exo throws synchronously, fallback to VLC immediately
            startPreviewVlc(rawUrl)
        }
    }

    
    
    private fun startPreviewVlc(rawUrl: String) {
        // Stop Exo preview if it's running
        try {
            previewPlayer?.playWhenReady = false
            previewPlayer?.stop()
        } catch (_: Throwable) {
        }

        // Show VLC layout, hide Exo surface
        binding.previewPlayerView.visibility = View.GONE
        binding.previewVlcLayout.visibility = View.VISIBLE

        // Lazily create LibVLC for preview
        if (previewLibVlc == null) {
            val options = arrayListOf(
                "--network-caching=1500",
                "--clock-jitter=0",
                "--clock-synchro=0"
            )
            previewLibVlc = LibVLC(this, options)
        }

        // Tear down any previous VLC instance
        try {
            previewVlcPlayer?.stop()
            previewVlcPlayer?.detachViews()
            previewVlcPlayer?.release()
        } catch (_: Throwable) {
        }
        previewVlcPlayer = null

        val vlc = previewLibVlc ?: return
        val mp = MediaPlayer(vlc)
        previewVlcPlayer = mp

        // Attach VLC video output into the hero preview area.
        mp.attachViews(binding.previewVlcLayout, null, false, false)

        val parts = StreamUrlUtils.splitUrlAndHeaders(rawUrl)
        val url = parts.url
        val headers = parts.headers

        val media = Media(vlc, Uri.parse(url))

        val uaFromPlaylist = headers.entries.firstOrNull { it.key.equals("User-Agent", ignoreCase = true) }?.value
        val ua = uaFromPlaylist ?: UserAgentUtils.build(this)
        runCatching { media.addOption(":http-user-agent=$ua") }

        val referer = headers.entries.firstOrNull {
            it.key.equals("Referer", ignoreCase = true) || it.key.equals("Referrer", ignoreCase = true)
        }?.value
        if (!referer.isNullOrBlank()) {
            runCatching { media.addOption(":http-referrer=$referer") }
        }

        // Pass through any extra headers as generic http-header options.
        headers.forEach { (k, v) ->
            val lk = k.lowercase()
            if (lk == "user-agent" || lk == "referer" || lk == "referrer") return@forEach
            runCatching { media.addOption(":http-header=${k}: ${v}") }
        }

        media.setHWDecoderEnabled(true, false)
        mp.media = media
        media.release()

        try {
            mp.play()
        } catch (_: Throwable) {
        }
    }


    override fun onStart() {
        super.onStart()
        // Returned back to the list UI.
        launchingPlayer = false
        if (allChannels.isNotEmpty()) {
            updateProgramInfoFromFirst()
        }
    }

    override fun onResume() {
        super.onResume()
        // Reset whenever we return to the list.
        launchingPlayer = false
    }

    override fun onStop() {
        // Clear cache when leaving Live TV, but NOT when launching playback.
        try {
            previewPlayer?.playWhenReady = false
            previewPlayer?.pause()
        } catch (_: Throwable) {
        }

        try {
            previewVlcPlayer?.stop()
        } catch (_: Throwable) {
        }

        val shouldClear = !launchingPlayer
        super.onStop()

        if (shouldClear) {
            lifecycleScope.launch(Dispatchers.IO) {
                CacheUtils.clearAppCache(this@ChannelListActivity)
            }
        }
    }
override fun onDestroy() {
        super.onDestroy()
        try {
            previewPlayer?.release()
        } catch (_: Throwable) {
        }
        previewPlayer = null

        try {
            previewVlcPlayer?.stop()
            previewVlcPlayer?.detachViews()
            previewVlcPlayer?.release()
        } catch (_: Throwable) {
        }
        previewVlcPlayer = null

        try {
            previewLibVlc?.release()
        } catch (_: Throwable) {
        }
        previewLibVlc = null
    }


    private fun openChannel(channel: Channel) {
        // Stop preview immediately when user selects a channel to watch
        stopPreviewPlayback()

        val index = filteredChannels.indexOf(channel).coerceAtLeast(0)
        ChannelStore.channels = filteredChannels
        ChannelStore.currentIndex = index

        // Mark this transition so onStop() doesn't wipe cache mid-launch.
        launchingPlayer = true

        val deviceId = Prefs.getOrCreateDeviceId(applicationContext)
        val urlWithId = StreamUrlUtils.withDeviceId(channel.url, deviceId)

        val intent = Intent(this, PlayerActivity::class.java).apply {
            putExtra("name", channel.name)
            putExtra("url", urlWithId)
        }
        startActivity(intent)
    }
}