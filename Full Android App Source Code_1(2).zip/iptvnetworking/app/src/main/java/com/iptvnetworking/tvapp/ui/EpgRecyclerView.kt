package com.iptvnetworking.tvapp.ui

import android.content.Context
import android.util.AttributeSet
import android.view.View
import androidx.recyclerview.widget.RecyclerView

/**
 * Custom RecyclerView to make TV-remote focus behavior feel natural inside the EPG grid.
 *
 * Goals:
 *  - Keep DOWN navigation locked inside the grid so users don't accidentally jump out.
 *  - Allow UP navigation to leave the grid ONLY when the user is already on the first row,
 *    so they can reach the category/search controls again.
 */
class EpgRecyclerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : RecyclerView(context, attrs, defStyleAttr) {

    override fun focusSearch(focused: View, direction: Int): View? {
        val result = super.focusSearch(focused, direction)

        if (result == null) return null

        // Keep DOWN navigation inside this RecyclerView
        if (direction == View.FOCUS_DOWN) {
            if (!isChildOfThis(result) && result !== this) {
                return focused
            }
        }

        // Allow UP navigation to leave ONLY from the very first adapter row
        if (direction == View.FOCUS_UP) {
            if (!isChildOfThis(result) && result !== this) {
                val vh = findContainingViewHolder(focused)
                val pos = vh?.bindingAdapterPosition ?: RecyclerView.NO_POSITION
                return if (pos == 0) result else focused
            }
        }

        return result
    }

    private fun isChildOfThis(view: View): Boolean {
        var current: View? = view
        while (current != null) {
            if (current === this) return true
            val parent = current.parent
            current = if (parent is View) parent else null
        }
        return false
    }
}
